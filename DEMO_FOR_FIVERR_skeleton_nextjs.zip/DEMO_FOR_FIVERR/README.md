# DEMO_FOR_FIVERR – TryOnYou unified demo (skeleton)

Generated skeleton on 2025-12-07T13:54:06.869668Z.

This is a Next.js 14 skeleton. Your developer must now plug in the real modules
(avatar, wardrobe, demo, look) from the existing TryOnYou repos / ZIPs.

## Usage

```bash
npm install
npm run dev
npm run build
```
