import Layout from "@/components/Layout";

export default function AvatarPage() {
  return (
    <Layout title="Avatar / Photo Builder">
      <h1>Avatar / Photo Builder</h1>
      <p>Aquí Danish integra el módulo Avatar / Photo Builder desde TRYONYOU_APP_COMPLETE.</p>
      <p>
        Este archivo es un placeholder. El desarrollador debe importar aquí el
        componente real desde el código existente (repos/ZIPs actuales de TryOnYou).
      </p>
    </Layout>
  );
}
