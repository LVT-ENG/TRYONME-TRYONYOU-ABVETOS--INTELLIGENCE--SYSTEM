import Layout from "@/components/Layout";
import Link from "next/link";

export default function Home() {
  return (
    <Layout title="Landing">
      <section className="hero">
        <div className="hero-left">
          <h1>La nouvelle façon d’essayer des vêtements, sans cabine.</h1>
          <p>
            TryOnYou transforme votre vitrine en un miroir magique interactif.
            Offrez une expérience d’achat premium et réduisez vos retours.
          </p>
          <div className="cta-row">
            <Link href="/demo" className="btn primary">
              Essayer la démo live
            </Link>
            <Link href="/look" className="btn ghost">
              Voir un Look Sheet
            </Link>
          </div>
          <p className="langs">Disponible pour pilotes FR / EN / ES.</p>
        </div>
        <div className="hero-right">
          <div className="mirror-frame">
            <img
              src="/assets/hero-placeholder.jpg"
              alt="Magic Mirror"
              className="hero-img"
            />
            <div className="pau-tag">
              <img src="/assets/pau.png" alt="Pau" />
              <span>Tap to change outfit</span>
            </div>
          </div>
        </div>
      </section>

      <section className="grid">
        <div>
          <h2>Avatar & Try-On</h2>
          <p>
            Module avatar / photo builder connecté à votre miroir ou à votre
            e-commerce.
          </p>
          <Link href="/avatar">Ouvrir le module Avatar →</Link>
        </div>
        <div>
          <h2>Smart Wardrobe</h2>
          <p>
            Recommandations intelligentes basées sur la morphologie et le style.
          </p>
          <Link href="/wardrobe">Ouvrir Smart Wardrobe →</Link>
        </div>
        <div>
          <h2>Holo Demo</h2>
          <p>Démo temps réel du “holo try-on” pour présentations et pilotes.</p>
          <Link href="/demo">Voir la démo →</Link>
        </div>
        <div>
          <h2>Look Sheet Export</h2>
          <p>
            Générer un récapitulatif de looks pour le client ou l’enseigne.
          </p>
          <Link href="/look">Générer un Look Sheet →</Link>
        </div>
      </section>
    </Layout>
  );
}
