import Layout from "@/components/Layout";

export default function WardrobePage() {
  return (
    <Layout title="Smart Wardrobe">
      <h1>Smart Wardrobe</h1>
      <p>Aquí se integra el módulo Smart Wardrobe (producción/unificado).</p>
      <p>
        Este archivo es un placeholder. El desarrollador debe importar aquí el
        componente real desde el código existente (repos/ZIPs actuales de TryOnYou).
      </p>
    </Layout>
  );
}
