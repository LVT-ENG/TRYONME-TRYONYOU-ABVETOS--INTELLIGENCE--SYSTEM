import Layout from "@/components/Layout";

export default function DemoPage() {
  return (
    <Layout title="Holo Try-On Demo">
      <h1>Holo Try-On Demo</h1>
      <p>Aquí Danish debe integrar la demo React existente (holo try-on unificada).</p>
      <p>
        Este archivo es un placeholder. El desarrollador debe importar aquí el
        componente real desde el código existente (repos/ZIPs actuales de TryOnYou).
      </p>
    </Layout>
  );
}
