# ACCESOS PARA MANUS IA / PARTNERS
1. DRIVE: Compartir carpeta 'TRYONYOU_CORE' con permisos de Editor.
2. VERCEL: Invitar via Settings > Members.
3. GOOGLE AI STUDIO: Exportar API_KEY en archivo .env.
4. ICLOUD: Mover logs de 'Punto Rojo' a DRIVE_EXTRACTS.