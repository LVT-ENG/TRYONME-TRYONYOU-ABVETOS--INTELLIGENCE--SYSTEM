# Especificación del Módulo: 120 - Captura y Calibración

## 1. Propósito

El módulo de Captura y Calibración es el punto de entrada para la personalización del avatar. Su función principal es obtener las medidas corporales del usuario de la manera más precisa y sencilla posible, utilizando métodos accesibles como cámaras de smartphone o entrada manual de datos.

## 2. Especificaciones Técnicas

### 2.1. Métodos de Entrada

El módulo debe soportar múltiples métodos de entrada de datos:

- **Escaneo con Cámara de Smartphone**: 
  - Utiliza la cámara del dispositivo para capturar una serie de imágenes o un video corto del usuario.
  - Requiere que el usuario se coloque a una distancia específica y realice giros lentos.
  - **[DESARROLLADOR: Implementar un algoritmo de fotogrametría para reconstruir una nube de puntos del cuerpo del usuario. Se pueden investigar librerías como OpenMVG o COLMAP como punto de partida.]**

- **Entrada Manual de Medidas**: 
  - Un formulario guiado donde el usuario puede introducir sus medidas clave (altura, peso, contorno de pecho, cintura, cadera, etc.).
  - Debe incluir ilustraciones y videos explicativos para asegurar que el usuario tome las medidas correctamente.

- **Integración con Escáneres 3D Externos**: 
  - API para recibir datos de escáneres corporales 3D profesionales.

### 2.2. Proceso de Calibración

Para asegurar la precisión, especialmente en el método de captura por cámara, el sistema debe realizar una calibración. Esto se puede lograr utilizando un objeto de referencia con dimensiones conocidas (ej. una tarjeta de crédito, una hoja de papel A4) que el usuario sostenga durante la captura.

### 2.3. Salida de Datos

La salida de este módulo es un archivo en formato JSON que contiene un listado de las medidas corporales del usuario. Este archivo servirá como entrada para el módulo `130_AVATAR_3D`.

**Ejemplo de Salida JSON:**

```json
{
  "userId": "user-12345",
  "units": "cm",
  "height": 175,
  "weight": 72,
  "measurements": {
    "chest": 98,
    "waist": 82,
    "hips": 95,
    "inseam": 80,
    "shoulder_width": 45
    // ... más medidas
  },
  "source": "camera_scan",
  "calibration_object": "credit_card",
  "timestamp": "2025-12-09T12:30:00Z"
}
```

## 3. API

**[DESARROLLADOR: Definir los endpoints de la API para este módulo. Por ejemplo:]**

- `POST /api/v1/capture/upload_scan`: Para subir las imágenes/video del escaneo.
- `POST /api/v1/capture/manual_entry`: Para enviar las medidas introducidas manualmente.
- `GET /api/v1/measurements/{userId}`: Para obtener las medidas procesadas de un usuario.


## 4. Implementación Frontend (React)

La interfaz de usuario para la captura de medidas se implementará como un componente de React.

- **`<MeasurementView />`**: Un componente de React que renderizará el avatar 3D del usuario junto con las medidas superpuestas. Permitirá al usuario rotar el avatar y hacer clic en diferentes partes del cuerpo para ver la medida correspondiente.
- **Visualización en Tiempo Real**: A medida que el usuario introduce sus medidas manualmente, el avatar se actualizará en tiempo real para reflejar los cambios, proporcionando feedback visual inmediato.
- **Guía Interactiva**: El componente guiará al usuario a través del proceso de escaneo con cámara, mostrando instrucciones en pantalla y feedback sobre la calidad de la captura.
