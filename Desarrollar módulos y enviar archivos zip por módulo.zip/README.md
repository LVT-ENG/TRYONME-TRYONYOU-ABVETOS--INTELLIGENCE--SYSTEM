# CAP (Creative Auto-Production) Module

## Overview

The **CAP (Creative Auto-Production)** module is a fully operational garment generation system within the TRYONYOU–ABVETOS–ULTRA–PLUS–ULTIMATUM project. It automatically generates production-ready garment designs when no existing garment meets the minimum fit-score threshold.

## Features

- **Automatic Pattern Generation**: Creates DXF pattern files based on anthropometric data and style preferences
- **Seam Specification**: Generates detailed seam specifications with margins and tolerances
- **Fabric Mapping**: Maps fabric properties including elasticity and physical modules
- **Photorealistic Rendering**: Produces high-quality mockup images
- **Comprehensive Metadata**: Builds detailed metadata for production and traceability
- **Multi-System Integration**: Connects with PAU, FTT, Smart Wardrobe, and JIT Factory
- **REST API**: Provides external API for production exports

## Architecture

```
CAP/
├── index.js                    # Main CAP orchestrator
├── generators/
│   ├── PatternGenerator.js     # DXF pattern generation
│   ├── SeamGenerator.js        # Seam specifications
│   └── FabricMapper.js         # Fabric property mapping
├── render/
│   └── RenderEngine.js         # Photorealistic rendering
├── metadata/
│   └── MetadataBuilder.js      # Metadata generation
├── api/
│   ├── PAUConnector.js         # Emotional state integration
│   ├── FTTConnector.js         # Trend tracking integration
│   ├── SmartWardrobeConnector.js # Wardrobe archiving
│   ├── JITConnector.js         # Production orchestration
│   └── CAPServer.js            # REST API server
└── utils/
    ├── validators.js           # Input validation
    └── logger.js               # Logging system
```

## Installation

```bash
cd TRYONYOU-ABVETOS-ULTRA-PLUS-ULTIMATUM
npm install
```

## Usage

### Programmatic API

```javascript
import { CAP } from './src/modules/CAP/index.js';

const cap = new CAP({
  minFitScore: 0.85,
  outputDir: './output/cap',
  enableRealTimeSync: true
});

// Generate garment
const result = await cap.generate({
  fitScore: 0.75,
  anthropometricData: {
    height: 175,
    bust: 92,
    waist: 72,
    hip: 98
  },
  style: 'casual',
  occasion: 'work',
  userId: 'user-123'
});

console.log('Generated garment:', result.garmentId);
```

### REST API

Start the API server:

```bash
node src/modules/CAP/api/CAPServer.js
```

#### Endpoints

**Health Check**
```
GET /health
```

**Generate Garment**
```
POST /api/cap/generate
Content-Type: application/json

{
  "fitScore": 0.75,
  "anthropometricData": {
    "height": 175,
    "bust": 92,
    "waist": 72,
    "hip": 98
  },
  "style": "casual",
  "occasion": "work",
  "userId": "user-123"
}
```

**Export for Production**
```
POST /api/cap/export
Content-Type: application/json

{
  "garmentId": "uuid-here",
  "priority": "high"
}
```

**Get Status**
```
GET /api/cap/status
```

## Configuration

Environment variables:

```bash
# API URLs
PAU_API_URL=http://localhost:4001/api/pau
FTT_API_URL=http://localhost:4002/api/ftt
SMART_WARDROBE_API_URL=http://localhost:4003/api/wardrobe
JIT_API_URL=http://localhost:4004/api/jit

# CAP Server
CAP_PORT=5000

# Logging
LOG_LEVEL=info
```

## Input Parameters

### Required Parameters

- **fitScore** (number): Current fit score (0-1)
- **anthropometricData** (object): User measurements
  - height (cm)
  - bust (cm)
  - waist (cm)
  - hip (cm)
- **style** (string): Style preference
  - Options: `casual`, `formal`, `sport`, `fitted`, `regular`, `loose`, `oversized`

### Optional Parameters

- **occasion** (string): Occasion type
  - Options: `casual`, `work`, `formal`, `sport`, `party`, `outdoor`, `home`
- **fabricType** (string): Fabric type
  - Options: `cotton-blend`, `pure-cotton`, `stretch-denim`, `athletic-knit`, `silk-blend`, `wool-blend`
- **elasticity** (string): Fabric elasticity
  - Options: `low`, `medium`, `high`, `extra-high`
- **priority** (string): Production priority
  - Options: `low`, `normal`, `high`, `urgent`
- **quantity** (number): Number of units to produce
- **userId** (string): User identifier

## Output Files

For each generated garment, CAP produces:

1. **pattern.dxf** - Vector pattern file for cutting
2. **seams.json** - Seam specifications with tolerances
3. **fabric-map.json** - Fabric properties and modules
4. **render.png** - Photorealistic mockup image
5. **metadata.yml** - Comprehensive metadata

## Integration Points

### PAU (Personalized Aesthetic Understanding)
- Retrieves emotional state and aesthetic preferences
- Influences color and style choices

### FTT (Fashion Trend Tracker)
- Fetches current fashion trends
- Adjusts designs based on trending silhouettes and colors

### Smart Wardrobe
- Archives generated garments
- Manages versioning and file storage

### JIT Factory
- Creates production orders
- Uploads production-ready files
- Tracks manufacturing status

## Quality Assurance

CAP includes comprehensive quality checkpoints:

- **Pre-production**: Pattern accuracy, fabric inspection
- **Cutting**: Grain alignment, piece accuracy
- **Sewing**: Seam straightness, stitch tension
- **Finishing**: Hem quality, pressing
- **Final inspection**: Overall fit, defect check

## Error Handling

CAP implements robust error handling:

- Input validation with detailed error messages
- Fallback modes for unavailable external services
- Comprehensive logging for debugging
- Graceful degradation

## Performance

- **Generation Time**: ~2-5 seconds per garment
- **File Sizes**:
  - DXF pattern: ~50-200 KB
  - Render (high-res): ~2-5 MB
  - Metadata: ~10-20 KB

## Logging

Logs are written to:
- `./logs/cap.log` - All log levels
- `./logs/cap-error.log` - Errors only

Log levels: `error`, `warn`, `info`, `debug`

## Testing

```bash
npm test
```

## Production Deployment

1. Set environment variables
2. Configure external service URLs
3. Start CAP server
4. Monitor logs for errors
5. Set up health check monitoring

## Troubleshooting

**Issue**: Generation fails with validation error
- **Solution**: Check input parameters match required format

**Issue**: External service connection fails
- **Solution**: CAP will use fallback mode automatically

**Issue**: Render quality is poor
- **Solution**: Increase resolution parameter to `ultra`

## Version History

- **1.0.0** (2024-11-28): Initial release
  - Complete pattern generation
  - Full integration suite
  - Production-ready API

## License

Proprietary - TRYONYOU Project

## Support

For issues or questions, contact the TRYONYOU development team.

---

**Status**: ✅ Fully Operational  
**Last Updated**: 2024-11-28  
**Module Version**: 1.0.0
