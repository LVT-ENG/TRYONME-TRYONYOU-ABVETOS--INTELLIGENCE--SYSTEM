/**
 * Metadata Builder
 * Builds comprehensive metadata for generated garments
 */

import yaml from 'js-yaml';
import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger.js';

export class MetadataBuilder {
  constructor() {
    this.outputDir = './output/cap/metadata';
    this.ensureOutputDir();
  }

  async ensureOutputDir() {
    try {
      await fs.mkdir(this.outputDir, { recursive: true });
    } catch (error) {
      logger.error('Failed to create metadata output directory', { error });
    }
  }

  /**
   * Build comprehensive metadata
   * @param {Object} params - Metadata parameters
   * @returns {Promise<Object>} Metadata result
   */
  async build(params) {
    const {
      pattern,
      seams,
      fabricMap,
      sizing,
      timestamp,
      userId,
      trends,
      emotionalContext
    } = params;

    logger.info('Building garment metadata', { 
      patternId: pattern.patternId 
    });

    // Generate garment ID
    const garmentId = uuidv4();

    // Build metadata structure
    const metadata = {
      // Basic Information
      garment: {
        id: garmentId,
        name: this.generateGarmentName(pattern, trends),
        type: this.determineGarmentType(pattern),
        category: 'top',
        status: 'generated',
        version: '1.0.0'
      },

      // Generation Information
      generation: {
        timestamp,
        userId,
        method: 'CAP',
        engine: 'Creative Auto-Production v1.0.0',
        patternId: pattern.patternId,
        seamId: seams.seamId,
        fabricMapId: fabricMap.fabricMapId
      },

      // Design Specifications
      design: {
        style: pattern.style,
        occasion: pattern.occasion,
        silhouette: trends?.silhouette || 'regular',
        fit: 'custom',
        neckline: 'crew',
        sleeves: this.determineSleeveType(pattern),
        length: 'standard',
        closure: 'none',
        pockets: []
      },

      // Sizing Information
      sizing: {
        system: 'custom',
        measurements: {
          bust: sizing.bust,
          waist: sizing.waist,
          hip: sizing.hip,
          shoulderWidth: sizing.shoulderWidth,
          armLength: sizing.armLength,
          height: sizing.height
        },
        units: 'cm',
        fitScore: 1.0,
        tolerance: '±2cm'
      },

      // Fabric Information
      fabric: {
        type: fabricMap.fabricType,
        composition: fabricMap.properties.composition,
        weight: fabricMap.properties.weight,
        weightUnit: 'g/m²',
        elasticity: fabricMap.properties.elasticity,
        breathability: fabricMap.properties.breathability,
        durability: fabricMap.properties.durability,
        careInstructions: fabricMap.careInstructions,
        sustainability: fabricMap.sustainability
      },

      // Color Information
      colors: {
        primary: this.getPrimaryColor(trends),
        secondary: [],
        palette: trends?.colors || ['neutral'],
        finish: 'matte'
      },

      // Pattern Information
      pattern: {
        id: pattern.patternId,
        pieces: pattern.pieces.length,
        pieceDetails: pattern.pieces.map(p => ({
          name: p.name,
          type: p.type,
          dimensions: p.dimensions
        })),
        format: 'DXF',
        scale: '1:1',
        units: 'cm'
      },

      // Seam Information
      seams: {
        id: seams.seamId,
        total: seams.totalSeams,
        types: this.extractSeamTypes(seams.data),
        standards: seams.data.standards,
        qualityControl: seams.data.qualityControl
      },

      // Production Information
      production: {
        method: 'JIT',
        priority: 'normal',
        estimatedTime: '24-48 hours',
        complexity: this.calculateComplexity(pattern, seams),
        requirements: this.generateProductionRequirements(pattern, fabricMap, seams)
      },

      // Trend Context
      trends: trends ? {
        season: trends.season,
        popularity: trends.popularity,
        influences: trends.details || [],
        timestamp: trends.timestamp
      } : null,

      // Emotional Context
      emotionalContext: emotionalContext ? {
        confidence: emotionalContext.confidence,
        comfort: emotionalContext.comfort,
        expressiveness: emotionalContext.expressiveness,
        mood: emotionalContext.mood
      } : null,

      // Quality Assurance
      quality: {
        checkpoints: this.generateQualityCheckpoints(),
        standards: ['ISO 9001', 'OEKO-TEX Standard 100'],
        inspectionRequired: true
      },

      // Traceability
      traceability: {
        generationTimestamp: timestamp,
        userId,
        systemVersion: '1.0.0',
        dataIntegrity: this.calculateChecksum(garmentId, timestamp),
        auditTrail: [
          {
            action: 'generated',
            timestamp,
            actor: 'CAP',
            details: 'Initial garment generation'
          }
        ]
      },

      // Metadata
      meta: {
        createdAt: timestamp,
        updatedAt: timestamp,
        version: '1.0.0',
        schema: 'CAP-Metadata-v1',
        format: 'YAML'
      }
    };

    // Export to YAML
    const filename = `metadata_${garmentId}.yml`;
    const filepath = path.join(this.outputDir, filename);
    const yamlContent = yaml.dump(metadata, {
      indent: 2,
      lineWidth: 120,
      noRefs: true
    });
    await fs.writeFile(filepath, yamlContent, 'utf8');

    // Also export as JSON for programmatic access
    const jsonPath = filepath.replace('.yml', '.json');
    await fs.writeFile(jsonPath, JSON.stringify(metadata, null, 2), 'utf8');

    logger.info('Garment metadata built', { 
      garmentId,
      filepath 
    });

    return {
      garmentId,
      ymlPath: filepath,
      jsonPath,
      data: metadata,
      name: metadata.garment.name,
      type: metadata.garment.type,
      size: metadata.sizing.system,
      fabricType: metadata.fabric.type
    };
  }

  /**
   * Generate garment name
   */
  generateGarmentName(pattern, trends) {
    const style = pattern.style || 'casual';
    const season = trends?.season || 'all-season';
    const timestamp = new Date().toISOString().slice(0, 10);
    
    const styleNames = {
      casual: 'Casual',
      formal: 'Formal',
      sport: 'Athletic',
      fitted: 'Fitted',
      regular: 'Regular',
      loose: 'Relaxed',
      oversized: 'Oversized'
    };

    return `${styleNames[style] || 'Custom'} ${season.charAt(0).toUpperCase() + season.slice(1)} Top - ${timestamp}`;
  }

  /**
   * Determine garment type
   */
  determineGarmentType(pattern) {
    const hasSleeves = pattern.pieces.some(p => p.name.includes('sleeve'));
    
    if (!hasSleeves) return 'tank-top';
    
    const sleeveLength = this.calculateSleeveLength(pattern);
    
    if (sleeveLength < 20) return 'short-sleeve-top';
    if (sleeveLength < 40) return 'three-quarter-sleeve-top';
    return 'long-sleeve-top';
  }

  /**
   * Determine sleeve type
   */
  determineSleeveType(pattern) {
    const sleevePieces = pattern.pieces.filter(p => p.name.includes('sleeve'));
    
    if (sleevePieces.length === 0) return 'sleeveless';
    
    const sleeveLength = this.calculateSleeveLength(pattern);
    
    if (sleeveLength < 20) return 'short';
    if (sleeveLength < 40) return 'three-quarter';
    return 'long';
  }

  /**
   * Calculate sleeve length
   */
  calculateSleeveLength(pattern) {
    const sleevePieces = pattern.pieces.filter(p => p.name.includes('sleeve'));
    
    if (sleevePieces.length === 0) return 0;
    
    return sleevePieces[0].dimensions.length || 60;
  }

  /**
   * Get primary color
   */
  getPrimaryColor(trends) {
    if (trends && trends.colors && trends.colors.length > 0) {
      return trends.colors[0];
    }
    return 'neutral';
  }

  /**
   * Extract seam types
   */
  extractSeamTypes(seamData) {
    const types = new Set();
    
    seamData.seams.forEach(seam => {
      types.add(seam.seamType || seam.type);
    });
    
    return Array.from(types);
  }

  /**
   * Calculate production complexity
   */
  calculateComplexity(pattern, seams) {
    const pieceCount = pattern.pieces.length;
    const seamCount = seams.totalSeams;
    
    let score = 0;
    
    // Base on piece count
    score += pieceCount * 10;
    
    // Base on seam count
    score += seamCount * 5;
    
    // Determine complexity level
    if (score < 50) return 'simple';
    if (score < 100) return 'moderate';
    if (score < 150) return 'complex';
    return 'very-complex';
  }

  /**
   * Generate production requirements
   */
  generateProductionRequirements(pattern, fabricMap, seams) {
    return {
      machinery: [
        'Industrial sewing machine',
        'Overlock machine',
        'Pressing equipment'
      ],
      skills: [
        'Pattern cutting',
        'Industrial sewing',
        'Quality inspection'
      ],
      materials: [
        {
          type: 'fabric',
          specification: fabricMap.fabricType,
          quantity: this.calculateFabricRequirement(pattern),
          unit: 'meters'
        },
        {
          type: 'thread',
          specification: seams.data.standards.threadType,
          quantity: this.calculateThreadRequirement(seams),
          unit: 'meters'
        },
        {
          type: 'needles',
          specification: seams.data.standards.needleSize,
          quantity: 5,
          unit: 'pieces'
        }
      ],
      time: {
        cutting: '15 minutes',
        sewing: '45 minutes',
        finishing: '20 minutes',
        inspection: '10 minutes',
        total: '90 minutes'
      }
    };
  }

  /**
   * Calculate fabric requirement
   */
  calculateFabricRequirement(pattern) {
    let totalArea = 0;
    
    pattern.pieces.forEach(piece => {
      totalArea += piece.dimensions.width * piece.dimensions.length;
    });
    
    // Add 20% for waste and seam allowances
    const requiredArea = totalArea * 1.2;
    
    // Convert to meters (assuming 150cm fabric width)
    const meters = requiredArea / 150;
    
    return Math.ceil(meters * 10) / 10; // Round to 1 decimal
  }

  /**
   * Calculate thread requirement
   */
  calculateThreadRequirement(seams) {
    // Estimate 10 meters per seam
    return seams.totalSeams * 10;
  }

  /**
   * Generate quality checkpoints
   */
  generateQualityCheckpoints() {
    return [
      {
        stage: 'pre-production',
        checks: ['Pattern accuracy', 'Fabric inspection', 'Color verification']
      },
      {
        stage: 'cutting',
        checks: ['Grain alignment', 'Piece accuracy', 'Marking verification']
      },
      {
        stage: 'sewing',
        checks: ['Seam straightness', 'Stitch tension', 'Seam allowance']
      },
      {
        stage: 'finishing',
        checks: ['Hem quality', 'Thread trimming', 'Pressing']
      },
      {
        stage: 'final-inspection',
        checks: ['Overall fit', 'Defect check', 'Measurement verification']
      }
    ];
  }

  /**
   * Calculate checksum for data integrity
   */
  calculateChecksum(garmentId, timestamp) {
    const data = `${garmentId}${timestamp}`;
    let hash = 0;
    
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    
    return Math.abs(hash).toString(16);
  }
}
