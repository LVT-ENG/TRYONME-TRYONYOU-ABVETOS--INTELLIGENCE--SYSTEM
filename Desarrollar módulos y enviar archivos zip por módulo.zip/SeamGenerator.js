/**
 * Seam Generator
 * Generates seam specifications with margins and tolerances
 */

import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger.js';

export class SeamGenerator {
  constructor() {
    this.outputDir = './output/cap/seams';
    this.ensureOutputDir();
    
    // Standard seam allowances (in cm)
    this.seamAllowances = {
      standard: 1.5,
      french: 1.0,
      flat: 0.6,
      overlock: 1.2
    };
  }

  async ensureOutputDir() {
    try {
      await fs.mkdir(this.outputDir, { recursive: true });
    } catch (error) {
      logger.error('Failed to create seams output directory', { error });
    }
  }

  /**
   * Generate seam specifications from pattern
   * @param {Object} pattern - Pattern data
   * @returns {Promise<Object>} Seam specifications
   */
  async generate(pattern) {
    logger.info('Generating seam specifications', { patternId: pattern.patternId });

    const seams = [];

    // Generate seams for each pattern piece
    pattern.pieces.forEach((piece, index) => {
      const pieceSeams = this.generatePieceSeams(piece, index, pattern.style);
      seams.push(...pieceSeams);
    });

    // Generate joining seams between pieces
    const joiningSeams = this.generateJoiningSeams(pattern.pieces, pattern.style);
    seams.push(...joiningSeams);

    // Add finishing seams (hems, necklines, etc.)
    const finishingSeams = this.generateFinishingSeams(pattern.pieces, pattern.style);
    seams.push(...finishingSeams);

    // Build seam data structure
    const seamData = {
      seamId: uuidv4(),
      patternId: pattern.patternId,
      totalSeams: seams.length,
      seams: seams,
      standards: {
        stitchType: this.getStitchType(pattern.style),
        threadType: this.getThreadType(pattern.style),
        needleSize: this.getNeedleSize(pattern.style)
      },
      qualityControl: {
        tolerances: {
          length: '±2mm',
          width: '±1mm',
          alignment: '±0.5mm'
        },
        checkpoints: this.generateCheckpoints(seams)
      }
    };

    // Export to JSON
    const filename = `seams_${seamData.seamId}.json`;
    const filepath = path.join(this.outputDir, filename);
    await fs.writeFile(filepath, JSON.stringify(seamData, null, 2), 'utf8');

    logger.info('Seam specifications generated', { 
      seamId: seamData.seamId, 
      totalSeams: seams.length,
      filepath 
    });

    return {
      seamId: seamData.seamId,
      jsonPath: filepath,
      totalSeams: seams.length,
      data: seamData
    };
  }

  /**
   * Generate seams for individual pattern piece
   */
  generatePieceSeams(piece, index, style) {
    const seams = [];
    const seamType = this.determineSeamType(piece.type, style);
    const allowance = this.seamAllowances[seamType];

    // Generate seam for each edge
    for (let i = 0; i < piece.vertices; i++) {
      seams.push({
        id: `seam_${index}_edge_${i}`,
        pieceId: piece.name,
        type: seamType,
        edgeIndex: i,
        allowance: allowance,
        allowanceUnit: 'cm',
        stitchLength: this.getStitchLength(seamType),
        tension: this.getTension(seamType),
        priority: this.getSeamPriority(piece.type, i)
      });
    }

    return seams;
  }

  /**
   * Generate joining seams between pieces
   */
  generateJoiningSeams(pieces, style) {
    const joiningSeams = [];

    // Front-to-back shoulder seams
    joiningSeams.push({
      id: 'join_shoulder_left',
      type: 'joining',
      connects: ['front', 'back'],
      location: 'shoulder_left',
      seamType: 'standard',
      allowance: this.seamAllowances.standard,
      allowanceUnit: 'cm',
      stitchLength: 2.5,
      tension: 'medium',
      priority: 'high',
      reinforcement: true
    });

    joiningSeams.push({
      id: 'join_shoulder_right',
      type: 'joining',
      connects: ['front', 'back'],
      location: 'shoulder_right',
      seamType: 'standard',
      allowance: this.seamAllowances.standard,
      allowanceUnit: 'cm',
      stitchLength: 2.5,
      tension: 'medium',
      priority: 'high',
      reinforcement: true
    });

    // Side seams
    joiningSeams.push({
      id: 'join_side_left',
      type: 'joining',
      connects: ['front', 'back'],
      location: 'side_left',
      seamType: 'overlock',
      allowance: this.seamAllowances.overlock,
      allowanceUnit: 'cm',
      stitchLength: 2.5,
      tension: 'medium',
      priority: 'high'
    });

    joiningSeams.push({
      id: 'join_side_right',
      type: 'joining',
      connects: ['front', 'back'],
      location: 'side_right',
      seamType: 'overlock',
      allowance: this.seamAllowances.overlock,
      allowanceUnit: 'cm',
      stitchLength: 2.5,
      tension: 'medium',
      priority: 'high'
    });

    // Sleeve attachment seams (if sleeves exist)
    const hasSleeves = pieces.some(p => p.name.includes('sleeve'));
    if (hasSleeves) {
      joiningSeams.push({
        id: 'join_sleeve_left',
        type: 'joining',
        connects: ['front', 'back', 'sleeve_left'],
        location: 'armhole_left',
        seamType: 'standard',
        allowance: this.seamAllowances.standard,
        allowanceUnit: 'cm',
        stitchLength: 2.0,
        tension: 'medium-high',
        priority: 'critical',
        reinforcement: true,
        easeAmount: 1.5
      });

      joiningSeams.push({
        id: 'join_sleeve_right',
        type: 'joining',
        connects: ['front', 'back', 'sleeve_right'],
        location: 'armhole_right',
        seamType: 'standard',
        allowance: this.seamAllowances.standard,
        allowanceUnit: 'cm',
        stitchLength: 2.0,
        tension: 'medium-high',
        priority: 'critical',
        reinforcement: true,
        easeAmount: 1.5
      });
    }

    return joiningSeams;
  }

  /**
   * Generate finishing seams (hems, edges)
   */
  generateFinishingSeams(pieces, style) {
    const finishingSeams = [];

    // Neckline finishing
    finishingSeams.push({
      id: 'finish_neckline',
      type: 'finishing',
      location: 'neckline',
      seamType: 'flat',
      allowance: this.seamAllowances.flat,
      allowanceUnit: 'cm',
      stitchLength: 2.0,
      tension: 'low',
      priority: 'high',
      finishType: 'binding',
      topstitch: true
    });

    // Bottom hem
    finishingSeams.push({
      id: 'finish_hem_bottom',
      type: 'finishing',
      location: 'bottom_hem',
      seamType: 'standard',
      allowance: 2.5,
      allowanceUnit: 'cm',
      stitchLength: 3.0,
      tension: 'low',
      priority: 'medium',
      finishType: 'double_fold',
      topstitch: true
    });

    // Sleeve hems (if applicable)
    const hasSleeves = pieces.some(p => p.name.includes('sleeve'));
    if (hasSleeves) {
      finishingSeams.push({
        id: 'finish_sleeve_left',
        type: 'finishing',
        location: 'sleeve_left_hem',
        seamType: 'standard',
        allowance: 2.0,
        allowanceUnit: 'cm',
        stitchLength: 2.5,
        tension: 'low',
        priority: 'medium',
        finishType: 'single_fold',
        topstitch: true
      });

      finishingSeams.push({
        id: 'finish_sleeve_right',
        type: 'finishing',
        location: 'sleeve_right_hem',
        seamType: 'standard',
        allowance: 2.0,
        allowanceUnit: 'cm',
        stitchLength: 2.5,
        tension: 'low',
        priority: 'medium',
        finishType: 'single_fold',
        topstitch: true
      });
    }

    return finishingSeams;
  }

  /**
   * Determine seam type based on piece and style
   */
  determineSeamType(pieceType, style) {
    if (style === 'formal') return 'french';
    if (style === 'sport') return 'overlock';
    return 'standard';
  }

  /**
   * Get stitch length for seam type
   */
  getStitchLength(seamType) {
    const lengths = {
      standard: 2.5,
      french: 2.0,
      flat: 2.0,
      overlock: 2.5
    };
    return lengths[seamType] || 2.5;
  }

  /**
   * Get tension for seam type
   */
  getTension(seamType) {
    const tensions = {
      standard: 'medium',
      french: 'medium-high',
      flat: 'low',
      overlock: 'medium'
    };
    return tensions[seamType] || 'medium';
  }

  /**
   * Get seam priority
   */
  getSeamPriority(pieceType, edgeIndex) {
    if (pieceType === 'body' && edgeIndex < 2) return 'high';
    return 'medium';
  }

  /**
   * Get stitch type for style
   */
  getStitchType(style) {
    const types = {
      formal: 'lockstitch',
      casual: 'lockstitch',
      sport: 'overlock',
      loose: 'lockstitch'
    };
    return types[style] || 'lockstitch';
  }

  /**
   * Get thread type for style
   */
  getThreadType(style) {
    const types = {
      formal: 'polyester-core',
      casual: 'cotton-polyester',
      sport: 'polyester-stretch',
      loose: 'cotton-polyester'
    };
    return types[style] || 'cotton-polyester';
  }

  /**
   * Get needle size for style
   */
  getNeedleSize(style) {
    const sizes = {
      formal: '80/12',
      casual: '90/14',
      sport: '75/11',
      loose: '90/14'
    };
    return sizes[style] || '90/14';
  }

  /**
   * Generate quality control checkpoints
   */
  generateCheckpoints(seams) {
    const checkpoints = [];
    
    // Critical seams get checkpoints
    const criticalSeams = seams.filter(s => s.priority === 'critical' || s.priority === 'high');
    
    criticalSeams.forEach(seam => {
      checkpoints.push({
        seamId: seam.id,
        checkpoint: 'pre-stitch',
        checks: ['alignment', 'pinning', 'marking']
      });
      
      checkpoints.push({
        seamId: seam.id,
        checkpoint: 'post-stitch',
        checks: ['straightness', 'tension', 'length']
      });
    });

    return checkpoints;
  }
}
