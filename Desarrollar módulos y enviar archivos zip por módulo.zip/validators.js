/**
 * Input Validators
 * Validates and sanitizes input parameters for CAP
 */

import { logger } from './logger.js';

/**
 * Validate generation inputs
 * @param {Object} params - Input parameters
 * @returns {Object} Validated parameters
 * @throws {Error} If validation fails
 */
export function validateInputs(params) {
  const errors = [];

  // Validate fit score
  if (typeof params.fitScore !== 'number') {
    errors.push('fitScore must be a number');
  } else if (params.fitScore < 0 || params.fitScore > 1) {
    errors.push('fitScore must be between 0 and 1');
  }

  // Validate anthropometric data
  if (!params.anthropometricData) {
    errors.push('anthropometricData is required');
  } else {
    const anthroErrors = validateAnthropometricData(params.anthropometricData);
    errors.push(...anthroErrors);
  }

  // Validate style
  if (!params.style) {
    errors.push('style is required');
  } else if (!isValidStyle(params.style)) {
    errors.push(`Invalid style: ${params.style}`);
  }

  // Validate occasion (optional)
  if (params.occasion && !isValidOccasion(params.occasion)) {
    errors.push(`Invalid occasion: ${params.occasion}`);
  }

  // Validate fabric type (optional)
  if (params.fabricType && !isValidFabricType(params.fabricType)) {
    errors.push(`Invalid fabricType: ${params.fabricType}`);
  }

  // Validate elasticity (optional)
  if (params.elasticity && !isValidElasticity(params.elasticity)) {
    errors.push(`Invalid elasticity: ${params.elasticity}`);
  }

  // Validate priority (optional)
  if (params.priority && !isValidPriority(params.priority)) {
    errors.push(`Invalid priority: ${params.priority}`);
  }

  // Validate quantity (optional)
  if (params.quantity !== undefined) {
    if (typeof params.quantity !== 'number' || params.quantity < 1) {
      errors.push('quantity must be a positive number');
    }
  }

  // If there are errors, throw
  if (errors.length > 0) {
    const errorMessage = `Validation failed: ${errors.join(', ')}`;
    logger.error('Input validation failed', { errors });
    throw new Error(errorMessage);
  }

  // Return validated and normalized parameters
  return {
    fitScore: params.fitScore,
    anthropometricData: normalizeAnthropometricData(params.anthropometricData),
    style: params.style,
    occasion: params.occasion || 'casual',
    preferences: params.preferences || {},
    fabricType: params.fabricType || 'cotton-blend',
    elasticity: params.elasticity || 'medium',
    priority: params.priority || 'normal',
    quantity: params.quantity || 1,
    userId: params.userId || 'anonymous'
  };
}

/**
 * Validate anthropometric data
 */
function validateAnthropometricData(data) {
  const errors = [];
  const required = ['height', 'bust', 'waist', 'hip'];

  required.forEach(field => {
    if (!data[field]) {
      errors.push(`anthropometricData.${field} is required`);
    } else if (typeof data[field] !== 'number' || data[field] <= 0) {
      errors.push(`anthropometricData.${field} must be a positive number`);
    }
  });

  // Validate ranges
  if (data.height && (data.height < 140 || data.height > 220)) {
    errors.push('height must be between 140 and 220 cm');
  }

  if (data.bust && (data.bust < 60 || data.bust > 150)) {
    errors.push('bust must be between 60 and 150 cm');
  }

  if (data.waist && (data.waist < 50 || data.waist > 130)) {
    errors.push('waist must be between 50 and 130 cm');
  }

  if (data.hip && (data.hip < 60 || data.hip > 150)) {
    errors.push('hip must be between 60 and 150 cm');
  }

  return errors;
}

/**
 * Normalize anthropometric data
 */
function normalizeAnthropometricData(data) {
  return {
    height: data.height,
    bust: data.bust,
    waist: data.waist,
    hip: data.hip,
    shoulderWidth: data.shoulderWidth || data.bust * 0.44,
    armLength: data.armLength || data.height * 0.35,
    inseam: data.inseam || data.height * 0.47,
    neckCircumference: data.neckCircumference || 36
  };
}

/**
 * Check if style is valid
 */
function isValidStyle(style) {
  const validStyles = [
    'casual',
    'formal',
    'sport',
    'fitted',
    'regular',
    'loose',
    'oversized'
  ];
  return validStyles.includes(style);
}

/**
 * Check if occasion is valid
 */
function isValidOccasion(occasion) {
  const validOccasions = [
    'casual',
    'work',
    'formal',
    'sport',
    'party',
    'outdoor',
    'home'
  ];
  return validOccasions.includes(occasion);
}

/**
 * Check if fabric type is valid
 */
function isValidFabricType(fabricType) {
  const validTypes = [
    'cotton-blend',
    'pure-cotton',
    'stretch-denim',
    'athletic-knit',
    'silk-blend',
    'wool-blend'
  ];
  return validTypes.includes(fabricType);
}

/**
 * Check if elasticity is valid
 */
function isValidElasticity(elasticity) {
  const validElasticities = [
    'low',
    'medium',
    'high',
    'extra-high'
  ];
  return validElasticities.includes(elasticity);
}

/**
 * Check if priority is valid
 */
function isValidPriority(priority) {
  const validPriorities = [
    'low',
    'normal',
    'high',
    'urgent'
  ];
  return validPriorities.includes(priority);
}

/**
 * Sanitize string input
 */
export function sanitizeString(str, maxLength = 255) {
  if (typeof str !== 'string') return '';
  
  return str
    .trim()
    .slice(0, maxLength)
    .replace(/[<>]/g, ''); // Remove potential HTML tags
}

/**
 * Validate UUID format
 */
export function isValidUUID(uuid) {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
}

/**
 * Validate email format
 */
export function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}
