/**
 * CAP (Creative Auto-Production) Module
 * Main entry point for garment generation system
 * 
 * @module CAP
 * @version 1.0.0
 */

import { PatternGenerator } from './generators/PatternGenerator.js';
import { SeamGenerator } from './generators/SeamGenerator.js';
import { FabricMapper } from './generators/FabricMapper.js';
import { RenderEngine } from './render/RenderEngine.js';
import { MetadataBuilder } from './metadata/MetadataBuilder.js';
import { PAUConnector } from './api/PAUConnector.js';
import { FTTConnector } from './api/FTTConnector.js';
import { SmartWardrobeConnector } from './api/SmartWardrobeConnector.js';
import { JITConnector } from './api/JITConnector.js';
import { validateInputs } from './utils/validators.js';
import { logger } from './utils/logger.js';

/**
 * CAP Main Class
 * Orchestrates the entire garment generation pipeline
 */
export class CAP {
  constructor(config = {}) {
    this.config = {
      minFitScore: config.minFitScore || 0.85,
      outputDir: config.outputDir || './output/cap',
      enableRealTimeSync: config.enableRealTimeSync !== false,
      ...config
    };

    // Initialize generators
    this.patternGenerator = new PatternGenerator();
    this.seamGenerator = new SeamGenerator();
    this.fabricMapper = new FabricMapper();
    this.renderEngine = new RenderEngine();
    this.metadataBuilder = new MetadataBuilder();

    // Initialize connectors
    this.pau = new PAUConnector();
    this.ftt = new FTTConnector();
    this.smartWardrobe = new SmartWardrobeConnector();
    this.jit = new JITConnector();

    logger.info('CAP Module initialized successfully');
  }

  /**
   * Main generation method
   * @param {Object} params - Generation parameters
   * @returns {Promise<Object>} Generated garment data and files
   */
  async generate(params) {
    try {
      logger.info('Starting CAP generation process', { params });

      // Step 1: Validate inputs
      const validatedParams = validateInputs(params);
      
      // Step 2: Check fit score threshold
      if (validatedParams.fitScore >= this.config.minFitScore) {
        logger.info('Fit score acceptable, skipping generation');
        return { 
          status: 'skipped', 
          reason: 'Existing garment meets fit score threshold',
          fitScore: validatedParams.fitScore 
        };
      }

      // Step 3: Gather contextual data
      const emotionalState = await this.pau.getEmotionalState(validatedParams.userId);
      const currentTrends = await this.ftt.getCurrentTrends(validatedParams.style);
      
      // Step 4: Generate pattern
      logger.info('Generating garment pattern');
      const pattern = await this.patternGenerator.generate({
        anthropometricData: validatedParams.anthropometricData,
        style: validatedParams.style,
        occasion: validatedParams.occasion,
        preferences: validatedParams.preferences,
        emotionalState,
        trends: currentTrends
      });

      // Step 5: Generate seams
      logger.info('Generating seam specifications');
      const seams = await this.seamGenerator.generate(pattern);

      // Step 6: Map fabric properties
      logger.info('Mapping fabric properties');
      const fabricMap = await this.fabricMapper.generate({
        pattern,
        fabricType: validatedParams.fabricType || 'cotton-blend',
        elasticity: validatedParams.elasticity || 'medium'
      });

      // Step 7: Render photorealistic mockup
      logger.info('Rendering photorealistic mockup');
      const render = await this.renderEngine.render({
        pattern,
        fabricMap,
        avatar: validatedParams.anthropometricData,
        lighting: 'studio',
        resolution: 'high'
      });

      // Step 8: Build metadata
      logger.info('Building metadata');
      const metadata = await this.metadataBuilder.build({
        pattern,
        seams,
        fabricMap,
        sizing: validatedParams.anthropometricData,
        timestamp: new Date().toISOString(),
        userId: validatedParams.userId,
        trends: currentTrends,
        emotionalContext: emotionalState
      });

      // Step 9: Package output files
      const outputFiles = {
        pattern: pattern.dxfPath,
        seams: seams.jsonPath,
        fabricMap: fabricMap.jsonPath,
        render: render.pngPath,
        metadata: metadata.ymlPath
      };

      // Step 10: Archive to Smart Wardrobe
      if (this.config.enableRealTimeSync) {
        logger.info('Syncing to Smart Wardrobe');
        await this.smartWardrobe.archive({
          garmentId: metadata.garmentId,
          files: outputFiles,
          metadata
        });
      }

      // Step 11: Send to JIT Factory
      logger.info('Sending to JIT Factory');
      const productionOrder = await this.jit.createOrder({
        garmentId: metadata.garmentId,
        files: outputFiles,
        priority: validatedParams.priority || 'normal',
        quantity: validatedParams.quantity || 1
      });

      logger.info('CAP generation completed successfully', { 
        garmentId: metadata.garmentId,
        productionOrderId: productionOrder.orderId 
      });

      return {
        status: 'success',
        garmentId: metadata.garmentId,
        files: outputFiles,
        metadata,
        productionOrder,
        fitScore: 1.0 // New garment has perfect fit
      };

    } catch (error) {
      logger.error('CAP generation failed', { error: error.message, stack: error.stack });
      throw error;
    }
  }

  /**
   * Export method for external API
   * @param {Object} params - Export parameters
   * @returns {Promise<Object>} Export result
   */
  async export(params) {
    const result = await this.generate(params);
    return {
      ...result,
      exportedAt: new Date().toISOString(),
      format: 'production-ready'
    };
  }

  /**
   * Get module status
   * @returns {Object} Status information
   */
  getStatus() {
    return {
      module: 'CAP',
      version: '1.0.0',
      status: 'operational',
      config: this.config,
      connectors: {
        pau: this.pau.isConnected(),
        ftt: this.ftt.isConnected(),
        smartWardrobe: this.smartWardrobe.isConnected(),
        jit: this.jit.isConnected()
      }
    };
  }
}

// Export singleton instance
export default new CAP();
