/**
 * Logger
 * Centralized logging system for CAP module
 */

import fs from 'fs';
import path from 'path';

class Logger {
  constructor() {
    this.logDir = './logs';
    this.logFile = path.join(this.logDir, 'cap.log');
    this.errorFile = path.join(this.logDir, 'cap-error.log');
    this.level = process.env.LOG_LEVEL || 'info';
    
    this.levels = {
      error: 0,
      warn: 1,
      info: 2,
      debug: 3
    };

    this.ensureLogDir();
  }

  /**
   * Ensure log directory exists
   */
  ensureLogDir() {
    if (!fs.existsSync(this.logDir)) {
      fs.mkdirSync(this.logDir, { recursive: true });
    }
  }

  /**
   * Format log message
   */
  formatMessage(level, message, meta = {}) {
    const timestamp = new Date().toISOString();
    const metaStr = Object.keys(meta).length > 0 ? ` ${JSON.stringify(meta)}` : '';
    return `[${timestamp}] [${level.toUpperCase()}] ${message}${metaStr}\n`;
  }

  /**
   * Write to log file
   */
  writeToFile(filename, message) {
    try {
      fs.appendFileSync(filename, message);
    } catch (error) {
      console.error('Failed to write to log file:', error);
    }
  }

  /**
   * Check if level should be logged
   */
  shouldLog(level) {
    return this.levels[level] <= this.levels[this.level];
  }

  /**
   * Log error message
   */
  error(message, meta = {}) {
    if (!this.shouldLog('error')) return;

    const formatted = this.formatMessage('error', message, meta);
    console.error(formatted.trim());
    this.writeToFile(this.logFile, formatted);
    this.writeToFile(this.errorFile, formatted);
  }

  /**
   * Log warning message
   */
  warn(message, meta = {}) {
    if (!this.shouldLog('warn')) return;

    const formatted = this.formatMessage('warn', message, meta);
    console.warn(formatted.trim());
    this.writeToFile(this.logFile, formatted);
  }

  /**
   * Log info message
   */
  info(message, meta = {}) {
    if (!this.shouldLog('info')) return;

    const formatted = this.formatMessage('info', message, meta);
    console.log(formatted.trim());
    this.writeToFile(this.logFile, formatted);
  }

  /**
   * Log debug message
   */
  debug(message, meta = {}) {
    if (!this.shouldLog('debug')) return;

    const formatted = this.formatMessage('debug', message, meta);
    console.log(formatted.trim());
    this.writeToFile(this.logFile, formatted);
  }

  /**
   * Set log level
   */
  setLevel(level) {
    if (this.levels[level] !== undefined) {
      this.level = level;
      this.info(`Log level set to ${level}`);
    }
  }

  /**
   * Clear log files
   */
  clearLogs() {
    try {
      if (fs.existsSync(this.logFile)) {
        fs.unlinkSync(this.logFile);
      }
      if (fs.existsSync(this.errorFile)) {
        fs.unlinkSync(this.errorFile);
      }
      this.info('Log files cleared');
    } catch (error) {
      console.error('Failed to clear log files:', error);
    }
  }
}

// Export singleton instance
export const logger = new Logger();
export default logger;
