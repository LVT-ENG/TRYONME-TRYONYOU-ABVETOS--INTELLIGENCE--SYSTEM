/**
 * Smart Wardrobe Connector
 * Connects to Smart Wardrobe for garment archiving and versioning
 */

import axios from 'axios';
import fs from 'fs/promises';
import FormData from 'form-data';
import { logger } from '../utils/logger.js';

export class SmartWardrobeConnector {
  constructor(config = {}) {
    this.baseURL = config.baseURL || process.env.SMART_WARDROBE_API_URL || 'http://localhost:4003/api/wardrobe';
    this.timeout = config.timeout || 10000;
    this.connected = false;
    
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: this.timeout,
      headers: {
        'Content-Type': 'application/json'
      }
    });

    this.initConnection();
  }

  /**
   * Initialize connection to Smart Wardrobe
   */
  async initConnection() {
    try {
      const response = await this.client.get('/health');
      this.connected = response.status === 200;
      logger.info('Smart Wardrobe connector initialized', { connected: this.connected });
    } catch (error) {
      logger.warn('Smart Wardrobe connection failed, using fallback mode', { error: error.message });
      this.connected = false;
    }
  }

  /**
   * Check if connected to Smart Wardrobe
   */
  isConnected() {
    return this.connected;
  }

  /**
   * Archive garment to Smart Wardrobe
   * @param {Object} params - Archive parameters
   * @returns {Promise<Object>} Archive result
   */
  async archive(params) {
    const { garmentId, files, metadata } = params;

    try {
      if (!this.connected) {
        logger.warn('Smart Wardrobe not connected, skipping archive');
        return { success: false, reason: 'not_connected' };
      }

      // Create garment entry
      const garmentData = {
        garmentId,
        name: metadata.name || `CAP Generated Garment ${garmentId.slice(0, 8)}`,
        type: metadata.type || 'top',
        style: metadata.style || 'casual',
        occasion: metadata.occasion || 'casual',
        season: metadata.season || 'all-season',
        colors: metadata.colors || ['neutral'],
        size: metadata.size || 'M',
        brand: 'TRYONYOU CAP',
        status: 'generated',
        createdAt: metadata.timestamp || new Date().toISOString(),
        metadata: {
          patternId: metadata.patternId,
          fabricType: metadata.fabricType,
          measurements: metadata.measurements,
          trends: metadata.trends
        }
      };

      const response = await this.client.post('/garments', garmentData);
      const wardrobeGarmentId = response.data.id;

      logger.info('Garment archived to Smart Wardrobe', { 
        garmentId, 
        wardrobeGarmentId 
      });

      // Upload associated files
      const uploadResults = await this.uploadFiles(wardrobeGarmentId, files);

      return {
        success: true,
        garmentId,
        wardrobeGarmentId,
        files: uploadResults,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to archive garment to Smart Wardrobe', { 
        error: error.message, 
        garmentId 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Upload files for garment
   * @param {string} wardrobeGarmentId - Wardrobe garment ID
   * @param {Object} files - Files to upload
   * @returns {Promise<Object>} Upload results
   */
  async uploadFiles(wardrobeGarmentId, files) {
    const uploadResults = {};

    for (const [fileType, filePath] of Object.entries(files)) {
      try {
        const formData = new FormData();
        const fileBuffer = await fs.readFile(filePath);
        formData.append('file', fileBuffer, {
          filename: filePath.split('/').pop(),
          contentType: this.getContentType(fileType)
        });
        formData.append('type', fileType);

        const response = await this.client.post(
          `/garments/${wardrobeGarmentId}/files`,
          formData,
          {
            headers: formData.getHeaders()
          }
        );

        uploadResults[fileType] = {
          success: true,
          url: response.data.url,
          fileId: response.data.fileId
        };

        logger.info('File uploaded to Smart Wardrobe', { 
          wardrobeGarmentId, 
          fileType 
        });
      } catch (error) {
        logger.error('Failed to upload file to Smart Wardrobe', { 
          error: error.message, 
          wardrobeGarmentId, 
          fileType 
        });
        uploadResults[fileType] = {
          success: false,
          error: error.message
        };
      }
    }

    return uploadResults;
  }

  /**
   * Get content type for file type
   */
  getContentType(fileType) {
    const contentTypes = {
      pattern: 'application/dxf',
      seams: 'application/json',
      fabricMap: 'application/json',
      render: 'image/png',
      metadata: 'application/x-yaml'
    };

    return contentTypes[fileType] || 'application/octet-stream';
  }

  /**
   * Get garment from wardrobe
   * @param {string} garmentId - Garment ID
   * @returns {Promise<Object>} Garment data
   */
  async getGarment(garmentId) {
    try {
      if (!this.connected) {
        return { success: false, reason: 'not_connected' };
      }

      const response = await this.client.get(`/garments/${garmentId}`);
      
      logger.info('Retrieved garment from Smart Wardrobe', { garmentId });
      
      return {
        success: true,
        garment: response.data
      };
    } catch (error) {
      logger.error('Failed to get garment from Smart Wardrobe', { 
        error: error.message, 
        garmentId 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Update garment status
   * @param {string} garmentId - Garment ID
   * @param {string} status - New status
   * @returns {Promise<Object>} Update result
   */
  async updateStatus(garmentId, status) {
    try {
      if (!this.connected) {
        return { success: false, reason: 'not_connected' };
      }

      const response = await this.client.patch(`/garments/${garmentId}/status`, {
        status
      });
      
      logger.info('Updated garment status in Smart Wardrobe', { 
        garmentId, 
        status 
      });
      
      return {
        success: true,
        garmentId,
        status,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to update garment status in Smart Wardrobe', { 
        error: error.message, 
        garmentId 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Create garment version
   * @param {string} garmentId - Garment ID
   * @param {Object} versionData - Version data
   * @returns {Promise<Object>} Version result
   */
  async createVersion(garmentId, versionData) {
    try {
      if (!this.connected) {
        return { success: false, reason: 'not_connected' };
      }

      const response = await this.client.post(`/garments/${garmentId}/versions`, {
        ...versionData,
        timestamp: new Date().toISOString()
      });
      
      logger.info('Created garment version in Smart Wardrobe', { 
        garmentId, 
        versionId: response.data.versionId 
      });
      
      return {
        success: true,
        garmentId,
        versionId: response.data.versionId,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to create garment version in Smart Wardrobe', { 
        error: error.message, 
        garmentId 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Search garments in wardrobe
   * @param {Object} criteria - Search criteria
   * @returns {Promise<Object>} Search results
   */
  async search(criteria) {
    try {
      if (!this.connected) {
        return { success: false, reason: 'not_connected' };
      }

      const response = await this.client.get('/garments/search', {
        params: criteria
      });
      
      logger.info('Searched garments in Smart Wardrobe', { 
        resultsCount: response.data.results.length 
      });
      
      return {
        success: true,
        results: response.data.results,
        total: response.data.total
      };
    } catch (error) {
      logger.error('Failed to search garments in Smart Wardrobe', { 
        error: error.message 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Delete garment from wardrobe
   * @param {string} garmentId - Garment ID
   * @returns {Promise<Object>} Delete result
   */
  async deleteGarment(garmentId) {
    try {
      if (!this.connected) {
        return { success: false, reason: 'not_connected' };
      }

      await this.client.delete(`/garments/${garmentId}`);
      
      logger.info('Deleted garment from Smart Wardrobe', { garmentId });
      
      return {
        success: true,
        garmentId,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to delete garment from Smart Wardrobe', { 
        error: error.message, 
        garmentId 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Reconnect to Smart Wardrobe
   */
  async reconnect() {
    logger.info('Attempting to reconnect to Smart Wardrobe');
    await this.initConnection();
    return this.connected;
  }
}
