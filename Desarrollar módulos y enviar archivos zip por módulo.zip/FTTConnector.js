/**
 * FTT Connector
 * Connects to FTT (Fashion Trend Tracker) for real-time trend data
 */

import axios from 'axios';
import { logger } from '../utils/logger.js';

export class FTTConnector {
  constructor(config = {}) {
    this.baseURL = config.baseURL || process.env.FTT_API_URL || 'http://localhost:4002/api/ftt';
    this.timeout = config.timeout || 5000;
    this.connected = false;
    this.cacheEnabled = config.cacheEnabled !== false;
    this.cache = new Map();
    this.cacheTTL = config.cacheTTL || 3600000; // 1 hour default
    
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: this.timeout,
      headers: {
        'Content-Type': 'application/json'
      }
    });

    this.initConnection();
  }

  /**
   * Initialize connection to FTT
   */
  async initConnection() {
    try {
      const response = await this.client.get('/health');
      this.connected = response.status === 200;
      logger.info('FTT connector initialized', { connected: this.connected });
    } catch (error) {
      logger.warn('FTT connection failed, using fallback mode', { error: error.message });
      this.connected = false;
    }
  }

  /**
   * Check if connected to FTT
   */
  isConnected() {
    return this.connected;
  }

  /**
   * Get current trends for style category
   * @param {string} style - Style category
   * @returns {Promise<Object>} Trend data
   */
  async getCurrentTrends(style = 'casual') {
    const cacheKey = `trends_${style}`;
    
    // Check cache first
    if (this.cacheEnabled && this.cache.has(cacheKey)) {
      const cached = this.cache.get(cacheKey);
      if (Date.now() - cached.timestamp < this.cacheTTL) {
        logger.info('Retrieved trends from cache', { style });
        return cached.data;
      }
    }

    try {
      if (!this.connected) {
        return this.getFallbackTrends(style);
      }

      const response = await this.client.get(`/trends/current`, {
        params: { style, limit: 10 }
      });
      
      const trends = {
        style,
        silhouette: response.data.silhouette || 'regular',
        colors: response.data.colors || ['neutral'],
        patterns: response.data.patterns || ['solid'],
        fabrics: response.data.fabrics || ['cotton-blend'],
        details: response.data.details || [],
        popularity: response.data.popularity || 0.5,
        season: response.data.season || this.getCurrentSeason(),
        timestamp: response.data.timestamp || new Date().toISOString()
      };

      // Cache the result
      if (this.cacheEnabled) {
        this.cache.set(cacheKey, {
          data: trends,
          timestamp: Date.now()
        });
      }

      logger.info('Retrieved current trends from FTT', { style });
      
      return trends;
    } catch (error) {
      logger.error('Failed to get trends from FTT', { error: error.message, style });
      return this.getFallbackTrends(style);
    }
  }

  /**
   * Get trending colors
   * @param {string} season - Season (spring, summer, fall, winter)
   * @returns {Promise<Array>} Trending colors
   */
  async getTrendingColors(season = null) {
    const currentSeason = season || this.getCurrentSeason();
    const cacheKey = `colors_${currentSeason}`;
    
    if (this.cacheEnabled && this.cache.has(cacheKey)) {
      const cached = this.cache.get(cacheKey);
      if (Date.now() - cached.timestamp < this.cacheTTL) {
        return cached.data;
      }
    }

    try {
      if (!this.connected) {
        return this.getFallbackColors(currentSeason);
      }

      const response = await this.client.get(`/colors/trending`, {
        params: { season: currentSeason }
      });
      
      const colors = response.data.colors || this.getFallbackColors(currentSeason);

      if (this.cacheEnabled) {
        this.cache.set(cacheKey, {
          data: colors,
          timestamp: Date.now()
        });
      }

      logger.info('Retrieved trending colors from FTT', { season: currentSeason });
      
      return colors;
    } catch (error) {
      logger.error('Failed to get trending colors from FTT', { error: error.message });
      return this.getFallbackColors(currentSeason);
    }
  }

  /**
   * Get trending patterns
   * @param {string} style - Style category
   * @returns {Promise<Array>} Trending patterns
   */
  async getTrendingPatterns(style = 'casual') {
    try {
      if (!this.connected) {
        return this.getFallbackPatterns(style);
      }

      const response = await this.client.get(`/patterns/trending`, {
        params: { style }
      });
      
      logger.info('Retrieved trending patterns from FTT', { style });
      
      return response.data.patterns || this.getFallbackPatterns(style);
    } catch (error) {
      logger.error('Failed to get trending patterns from FTT', { error: error.message });
      return this.getFallbackPatterns(style);
    }
  }

  /**
   * Get silhouette trends
   * @param {string} category - Garment category
   * @returns {Promise<Object>} Silhouette trend data
   */
  async getSilhouetteTrends(category = 'top') {
    try {
      if (!this.connected) {
        return this.getFallbackSilhouette(category);
      }

      const response = await this.client.get(`/silhouette/trending`, {
        params: { category }
      });
      
      logger.info('Retrieved silhouette trends from FTT', { category });
      
      return {
        primary: response.data.primary || 'regular',
        secondary: response.data.secondary || 'fitted',
        emerging: response.data.emerging || 'oversized',
        declining: response.data.declining || 'tight'
      };
    } catch (error) {
      logger.error('Failed to get silhouette trends from FTT', { error: error.message });
      return this.getFallbackSilhouette(category);
    }
  }

  /**
   * Submit trend observation
   * @param {Object} observation - Trend observation data
   * @returns {Promise<Object>} Submission result
   */
  async submitTrendObservation(observation) {
    try {
      if (!this.connected) {
        logger.warn('FTT not connected, skipping trend observation submission');
        return { success: false, reason: 'not_connected' };
      }

      const response = await this.client.post('/observations', observation);
      
      logger.info('Submitted trend observation to FTT');
      
      return {
        success: true,
        observationId: response.data.id,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to submit trend observation to FTT', { error: error.message });
      return { success: false, error: error.message };
    }
  }

  /**
   * Get current season
   */
  getCurrentSeason() {
    const month = new Date().getMonth();
    
    if (month >= 2 && month <= 4) return 'spring';
    if (month >= 5 && month <= 7) return 'summer';
    if (month >= 8 && month <= 10) return 'fall';
    return 'winter';
  }

  /**
   * Fallback trends (when FTT unavailable)
   */
  getFallbackTrends(style) {
    const season = this.getCurrentSeason();
    
    const baseTrends = {
      casual: {
        silhouette: 'regular',
        colors: ['navy', 'white', 'olive', 'burgundy'],
        patterns: ['solid', 'stripes'],
        fabrics: ['cotton-blend', 'denim'],
        details: ['minimal', 'functional']
      },
      formal: {
        silhouette: 'fitted',
        colors: ['navy', 'charcoal', 'white', 'light-blue'],
        patterns: ['solid', 'pinstripe'],
        fabrics: ['wool-blend', 'cotton-blend'],
        details: ['structured', 'tailored']
      },
      sport: {
        silhouette: 'athletic',
        colors: ['black', 'navy', 'neon-accents'],
        patterns: ['solid', 'color-block'],
        fabrics: ['athletic-knit', 'stretch'],
        details: ['performance', 'breathable']
      }
    };

    const trend = baseTrends[style] || baseTrends.casual;

    return {
      style,
      ...trend,
      popularity: 0.6,
      season,
      timestamp: new Date().toISOString(),
      source: 'fallback'
    };
  }

  /**
   * Fallback colors by season
   */
  getFallbackColors(season) {
    const seasonalColors = {
      spring: ['pastel-pink', 'mint-green', 'sky-blue', 'lavender', 'coral'],
      summer: ['white', 'navy', 'yellow', 'turquoise', 'coral'],
      fall: ['burgundy', 'olive', 'mustard', 'rust', 'chocolate'],
      winter: ['black', 'charcoal', 'burgundy', 'forest-green', 'navy']
    };

    return seasonalColors[season] || seasonalColors.fall;
  }

  /**
   * Fallback patterns
   */
  getFallbackPatterns(style) {
    const patterns = {
      casual: ['solid', 'stripes', 'checks'],
      formal: ['solid', 'pinstripe', 'subtle-texture'],
      sport: ['solid', 'color-block', 'geometric']
    };

    return patterns[style] || patterns.casual;
  }

  /**
   * Fallback silhouette
   */
  getFallbackSilhouette(category) {
    return {
      primary: 'regular',
      secondary: 'fitted',
      emerging: 'oversized',
      declining: 'tight'
    };
  }

  /**
   * Clear cache
   */
  clearCache() {
    this.cache.clear();
    logger.info('FTT cache cleared');
  }

  /**
   * Reconnect to FTT
   */
  async reconnect() {
    logger.info('Attempting to reconnect to FTT');
    await this.initConnection();
    return this.connected;
  }
}
