/**
 * CAP Server
 * REST API server for external CAP access
 */

import express from 'express';
import cors from 'cors';
import { CAP } from '../index.js';
import { logger } from '../utils/logger.js';

export class CAPServer {
  constructor(config = {}) {
    this.port = config.port || process.env.CAP_PORT || 5000;
    this.app = express();
    this.cap = new CAP(config.capConfig);
    
    this.setupMiddleware();
    this.setupRoutes();
  }

  /**
   * Setup Express middleware
   */
  setupMiddleware() {
    this.app.use(cors());
    this.app.use(express.json({ limit: '50mb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '50mb' }));
    
    // Request logging
    this.app.use((req, res, next) => {
      logger.info('API Request', { 
        method: req.method, 
        path: req.path,
        ip: req.ip 
      });
      next();
    });
  }

  /**
   * Setup API routes
   */
  setupRoutes() {
    // Health check
    this.app.get('/health', (req, res) => {
      res.json({
        status: 'healthy',
        module: 'CAP',
        version: '1.0.0',
        timestamp: new Date().toISOString()
      });
    });

    // Get CAP status
    this.app.get('/api/cap/status', (req, res) => {
      try {
        const status = this.cap.getStatus();
        res.json(status);
      } catch (error) {
        logger.error('Failed to get CAP status', { error: error.message });
        res.status(500).json({ error: 'Failed to get status' });
      }
    });

    // Generate garment
    this.app.post('/api/cap/generate', async (req, res) => {
      try {
        const params = req.body;
        
        logger.info('Received generation request', { 
          userId: params.userId,
          style: params.style 
        });

        const result = await this.cap.generate(params);
        
        res.json(result);
      } catch (error) {
        logger.error('Generation failed', { error: error.message });
        res.status(500).json({ 
          error: 'Generation failed', 
          message: error.message 
        });
      }
    });

    // Export garment for production
    this.app.post('/api/cap/export', async (req, res) => {
      try {
        const params = req.body;
        
        logger.info('Received export request', { 
          userId: params.userId,
          garmentId: params.garmentId 
        });

        const result = await this.cap.export(params);
        
        res.json(result);
      } catch (error) {
        logger.error('Export failed', { error: error.message });
        res.status(500).json({ 
          error: 'Export failed', 
          message: error.message 
        });
      }
    });

    // Get generation history
    this.app.get('/api/cap/history/:userId', async (req, res) => {
      try {
        const { userId } = req.params;
        const { limit = 10, offset = 0 } = req.query;
        
        // This would typically query a database
        // For now, return mock data
        res.json({
          userId,
          history: [],
          total: 0,
          limit: parseInt(limit),
          offset: parseInt(offset)
        });
      } catch (error) {
        logger.error('Failed to get history', { error: error.message });
        res.status(500).json({ 
          error: 'Failed to get history', 
          message: error.message 
        });
      }
    });

    // Batch generation
    this.app.post('/api/cap/batch', async (req, res) => {
      try {
        const { requests } = req.body;
        
        if (!Array.isArray(requests)) {
          return res.status(400).json({ 
            error: 'Invalid request format',
            message: 'Expected array of generation requests' 
          });
        }

        logger.info('Received batch generation request', { 
          count: requests.length 
        });

        const results = [];
        
        for (const request of requests) {
          try {
            const result = await this.cap.generate(request);
            results.push({ success: true, ...result });
          } catch (error) {
            results.push({ 
              success: false, 
              error: error.message,
              request 
            });
          }
        }
        
        res.json({
          total: requests.length,
          successful: results.filter(r => r.success).length,
          failed: results.filter(r => !r.success).length,
          results
        });
      } catch (error) {
        logger.error('Batch generation failed', { error: error.message });
        res.status(500).json({ 
          error: 'Batch generation failed', 
          message: error.message 
        });
      }
    });

    // Get file by ID
    this.app.get('/api/cap/files/:fileId', async (req, res) => {
      try {
        const { fileId } = req.params;
        
        // This would typically retrieve file from storage
        // For now, return 404
        res.status(404).json({ 
          error: 'File not found',
          fileId 
        });
      } catch (error) {
        logger.error('Failed to get file', { error: error.message });
        res.status(500).json({ 
          error: 'Failed to get file', 
          message: error.message 
        });
      }
    });

    // Validate generation parameters
    this.app.post('/api/cap/validate', (req, res) => {
      try {
        const params = req.body;
        
        // Basic validation
        const required = ['fitScore', 'anthropometricData', 'style'];
        const missing = required.filter(field => !params[field]);
        
        if (missing.length > 0) {
          return res.status(400).json({
            valid: false,
            errors: missing.map(field => `Missing required field: ${field}`)
          });
        }

        res.json({
          valid: true,
          params
        });
      } catch (error) {
        logger.error('Validation failed', { error: error.message });
        res.status(500).json({ 
          error: 'Validation failed', 
          message: error.message 
        });
      }
    });

    // Error handler
    this.app.use((err, req, res, next) => {
      logger.error('Unhandled error', { 
        error: err.message, 
        stack: err.stack 
      });
      
      res.status(500).json({
        error: 'Internal server error',
        message: err.message
      });
    });

    // 404 handler
    this.app.use((req, res) => {
      res.status(404).json({
        error: 'Not found',
        path: req.path
      });
    });
  }

  /**
   * Start server
   */
  start() {
    return new Promise((resolve, reject) => {
      try {
        this.server = this.app.listen(this.port, () => {
          logger.info(`CAP Server started on port ${this.port}`);
          resolve(this.server);
        });
      } catch (error) {
        logger.error('Failed to start CAP Server', { error: error.message });
        reject(error);
      }
    });
  }

  /**
   * Stop server
   */
  stop() {
    return new Promise((resolve, reject) => {
      if (this.server) {
        this.server.close((err) => {
          if (err) {
            logger.error('Failed to stop CAP Server', { error: err.message });
            reject(err);
          } else {
            logger.info('CAP Server stopped');
            resolve();
          }
        });
      } else {
        resolve();
      }
    });
  }
}

// Export factory function
export function createCAPServer(config) {
  return new CAPServer(config);
}

// CLI entry point
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new CAPServer();
  
  server.start().then(() => {
    logger.info('CAP Server is running');
  }).catch((error) => {
    logger.error('Failed to start server', { error: error.message });
    process.exit(1);
  });

  // Graceful shutdown
  process.on('SIGTERM', async () => {
    logger.info('SIGTERM received, shutting down gracefully');
    await server.stop();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    logger.info('SIGINT received, shutting down gracefully');
    await server.stop();
    process.exit(0);
  });
}
