/**
 * Fabric Mapper
 * Maps fabric properties including elasticity and physical modules
 */

import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger.js';

export class FabricMapper {
  constructor() {
    this.outputDir = './output/cap/fabrics';
    this.ensureOutputDir();
    
    // Fabric property database
    this.fabricDatabase = {
      'cotton-blend': {
        composition: { cotton: 60, polyester: 40 },
        weight: 180,
        elasticity: { horizontal: 5, vertical: 3 },
        breathability: 8,
        durability: 7
      },
      'pure-cotton': {
        composition: { cotton: 100 },
        weight: 160,
        elasticity: { horizontal: 2, vertical: 1 },
        breathability: 10,
        durability: 6
      },
      'stretch-denim': {
        composition: { cotton: 75, polyester: 23, elastane: 2 },
        weight: 320,
        elasticity: { horizontal: 15, vertical: 8 },
        breathability: 5,
        durability: 9
      },
      'athletic-knit': {
        composition: { polyester: 85, elastane: 15 },
        weight: 200,
        elasticity: { horizontal: 40, vertical: 35 },
        breathability: 9,
        durability: 8
      },
      'silk-blend': {
        composition: { silk: 70, polyester: 30 },
        weight: 120,
        elasticity: { horizontal: 3, vertical: 2 },
        breathability: 9,
        durability: 5
      },
      'wool-blend': {
        composition: { wool: 80, polyester: 20 },
        weight: 280,
        elasticity: { horizontal: 8, vertical: 5 },
        breathability: 7,
        durability: 8
      }
    };
  }

  async ensureOutputDir() {
    try {
      await fs.mkdir(this.outputDir, { recursive: true });
    } catch (error) {
      logger.error('Failed to create fabrics output directory', { error });
    }
  }

  /**
   * Generate fabric map for pattern
   * @param {Object} params - Fabric mapping parameters
   * @returns {Promise<Object>} Fabric map data
   */
  async generate(params) {
    const { pattern, fabricType, elasticity } = params;

    logger.info('Generating fabric map', { 
      patternId: pattern.patternId, 
      fabricType 
    });

    // Get fabric properties
    const fabricProps = this.fabricDatabase[fabricType] || this.fabricDatabase['cotton-blend'];

    // Adjust elasticity if specified
    if (elasticity) {
      fabricProps.elasticity = this.adjustElasticity(fabricProps.elasticity, elasticity);
    }

    // Generate fabric zones for each pattern piece
    const fabricZones = this.generateFabricZones(pattern.pieces, fabricProps);

    // Calculate physical modules
    const physicalModules = this.calculatePhysicalModules(fabricProps, pattern.measurements);

    // Generate stretch map
    const stretchMap = this.generateStretchMap(pattern.pieces, fabricProps);

    // Build fabric map data
    const fabricMapData = {
      fabricMapId: uuidv4(),
      patternId: pattern.patternId,
      fabricType,
      properties: fabricProps,
      zones: fabricZones,
      physicalModules,
      stretchMap,
      careInstructions: this.getCareInstructions(fabricType),
      sustainability: this.getSustainabilityInfo(fabricType)
    };

    // Export to JSON
    const filename = `fabric-map_${fabricMapData.fabricMapId}.json`;
    const filepath = path.join(this.outputDir, filename);
    await fs.writeFile(filepath, JSON.stringify(fabricMapData, null, 2), 'utf8');

    logger.info('Fabric map generated', { 
      fabricMapId: fabricMapData.fabricMapId,
      filepath 
    });

    return {
      fabricMapId: fabricMapData.fabricMapId,
      jsonPath: filepath,
      data: fabricMapData
    };
  }

  /**
   * Adjust elasticity based on user preference
   */
  adjustElasticity(baseElasticity, preference) {
    const factors = {
      'low': 0.7,
      'medium': 1.0,
      'high': 1.3,
      'extra-high': 1.6
    };

    const factor = factors[preference] || 1.0;

    return {
      horizontal: Math.round(baseElasticity.horizontal * factor),
      vertical: Math.round(baseElasticity.vertical * factor)
    };
  }

  /**
   * Generate fabric zones for pattern pieces
   */
  generateFabricZones(pieces, fabricProps) {
    return pieces.map(piece => {
      // Determine stress zones
      const stressZones = this.identifyStressZones(piece);

      return {
        pieceName: piece.name,
        primaryFabric: {
          type: 'main',
          coverage: 85,
          properties: fabricProps
        },
        reinforcementZones: stressZones.map(zone => ({
          location: zone.location,
          type: 'reinforcement',
          coverage: zone.coverage,
          additionalLayers: zone.layers,
          elasticityModifier: zone.elasticityModifier
        })),
        grainDirection: this.determineGrainDirection(piece),
        cutInstructions: {
          orientation: this.getCutOrientation(piece),
          mirroring: piece.name.includes('left') || piece.name.includes('right'),
          specialNotes: this.getCutNotes(piece, fabricProps)
        }
      };
    });
  }

  /**
   * Identify stress zones in pattern piece
   */
  identifyStressZones(piece) {
    const zones = [];

    if (piece.type === 'body') {
      zones.push({
        location: 'shoulder',
        coverage: 10,
        layers: 1,
        elasticityModifier: 0.8
      });
      zones.push({
        location: 'armhole',
        coverage: 15,
        layers: 1,
        elasticityModifier: 0.9
      });
    }

    if (piece.type === 'sleeve') {
      zones.push({
        location: 'elbow',
        coverage: 12,
        layers: 1,
        elasticityModifier: 1.2
      });
    }

    return zones;
  }

  /**
   * Determine grain direction for piece
   */
  determineGrainDirection(piece) {
    if (piece.type === 'body') {
      return 'lengthwise';
    }
    if (piece.type === 'sleeve') {
      return 'lengthwise';
    }
    return 'crosswise';
  }

  /**
   * Get cut orientation
   */
  getCutOrientation(piece) {
    if (piece.name.includes('front') || piece.name.includes('back')) {
      return 'on-fold';
    }
    return 'single-layer';
  }

  /**
   * Get cutting notes
   */
  getCutNotes(piece, fabricProps) {
    const notes = [];

    if (fabricProps.elasticity.horizontal > 20) {
      notes.push('Use ballpoint needles');
      notes.push('Allow fabric to relax before cutting');
    }

    if (fabricProps.weight > 250) {
      notes.push('Use sharp shears or rotary cutter');
      notes.push('Consider pattern weights instead of pins');
    }

    return notes;
  }

  /**
   * Calculate physical modules (Young's modulus, Poisson's ratio, etc.)
   */
  calculatePhysicalModules(fabricProps, measurements) {
    // Simplified physical modeling
    const density = fabricProps.weight / 1000; // g/cm² to kg/m²
    
    // Young's modulus (tensile stiffness) in MPa
    const youngsModulus = {
      warp: this.calculateYoungsModulus(fabricProps, 'warp'),
      weft: this.calculateYoungsModulus(fabricProps, 'weft')
    };

    // Poisson's ratio (lateral strain)
    const poissonsRatio = {
      warp: 0.3 + (fabricProps.elasticity.horizontal / 100),
      weft: 0.3 + (fabricProps.elasticity.vertical / 100)
    };

    // Shear modulus
    const shearModulus = (youngsModulus.warp + youngsModulus.weft) / (2 * (1 + (poissonsRatio.warp + poissonsRatio.weft) / 2));

    // Bending rigidity
    const bendingRigidity = {
      warp: youngsModulus.warp * Math.pow(fabricProps.weight / 1000, 3) / 12,
      weft: youngsModulus.weft * Math.pow(fabricProps.weight / 1000, 3) / 12
    };

    return {
      density,
      youngsModulus,
      poissonsRatio,
      shearModulus,
      bendingRigidity,
      units: {
        density: 'kg/m²',
        youngsModulus: 'MPa',
        poissonsRatio: 'dimensionless',
        shearModulus: 'MPa',
        bendingRigidity: 'N·mm²'
      }
    };
  }

  /**
   * Calculate Young's modulus for fabric direction
   */
  calculateYoungsModulus(fabricProps, direction) {
    const baseModulus = 100; // Base MPa for cotton
    const elasticityFactor = direction === 'warp' 
      ? fabricProps.elasticity.vertical 
      : fabricProps.elasticity.horizontal;

    // Higher elasticity = lower modulus (more flexible)
    return baseModulus * (1 - elasticityFactor / 100);
  }

  /**
   * Generate stretch map
   */
  generateStretchMap(pieces, fabricProps) {
    return {
      global: {
        horizontal: fabricProps.elasticity.horizontal,
        vertical: fabricProps.elasticity.vertical,
        diagonal: Math.sqrt(
          Math.pow(fabricProps.elasticity.horizontal, 2) + 
          Math.pow(fabricProps.elasticity.vertical, 2)
        ) / 2
      },
      zones: pieces.map(piece => ({
        pieceName: piece.name,
        stretchProfile: this.generateStretchProfile(piece, fabricProps)
      }))
    };
  }

  /**
   * Generate stretch profile for piece
   */
  generateStretchProfile(piece, fabricProps) {
    return {
      primary: fabricProps.elasticity.horizontal,
      secondary: fabricProps.elasticity.vertical,
      recovery: this.calculateRecovery(fabricProps),
      growthPotential: this.calculateGrowthPotential(fabricProps)
    };
  }

  /**
   * Calculate fabric recovery percentage
   */
  calculateRecovery(fabricProps) {
    const avgElasticity = (fabricProps.elasticity.horizontal + fabricProps.elasticity.vertical) / 2;
    
    if (avgElasticity < 5) return 70;
    if (avgElasticity < 15) return 85;
    if (avgElasticity < 30) return 95;
    return 98;
  }

  /**
   * Calculate growth potential
   */
  calculateGrowthPotential(fabricProps) {
    const avgElasticity = (fabricProps.elasticity.horizontal + fabricProps.elasticity.vertical) / 2;
    return Math.min(avgElasticity * 0.3, 10);
  }

  /**
   * Get care instructions for fabric type
   */
  getCareInstructions(fabricType) {
    const instructions = {
      'cotton-blend': {
        washing: 'Machine wash warm, tumble dry low',
        ironing: 'Medium heat',
        bleaching: 'Non-chlorine bleach only',
        dryClean: 'Not required'
      },
      'pure-cotton': {
        washing: 'Machine wash warm, tumble dry medium',
        ironing: 'High heat',
        bleaching: 'Chlorine bleach acceptable',
        dryClean: 'Not required'
      },
      'stretch-denim': {
        washing: 'Machine wash cold, tumble dry low',
        ironing: 'Medium heat',
        bleaching: 'Do not bleach',
        dryClean: 'Not required'
      },
      'athletic-knit': {
        washing: 'Machine wash cold, hang dry',
        ironing: 'Low heat or steam',
        bleaching: 'Do not bleach',
        dryClean: 'Not required'
      },
      'silk-blend': {
        washing: 'Hand wash cold or dry clean',
        ironing: 'Low heat with press cloth',
        bleaching: 'Do not bleach',
        dryClean: 'Recommended'
      },
      'wool-blend': {
        washing: 'Hand wash cold or dry clean',
        ironing: 'Medium heat with steam',
        bleaching: 'Do not bleach',
        dryClean: 'Recommended'
      }
    };

    return instructions[fabricType] || instructions['cotton-blend'];
  }

  /**
   * Get sustainability information
   */
  getSustainabilityInfo(fabricType) {
    const info = {
      'cotton-blend': {
        recyclability: 'Moderate',
        biodegradability: 'Partial',
        waterUsage: 'High',
        carbonFootprint: 'Medium',
        certifications: ['OEKO-TEX']
      },
      'pure-cotton': {
        recyclability: 'High',
        biodegradability: 'Full',
        waterUsage: 'Very High',
        carbonFootprint: 'Medium',
        certifications: ['GOTS', 'OEKO-TEX', 'Organic']
      },
      'stretch-denim': {
        recyclability: 'Low',
        biodegradability: 'Partial',
        waterUsage: 'Very High',
        carbonFootprint: 'High',
        certifications: ['OEKO-TEX']
      },
      'athletic-knit': {
        recyclability: 'Moderate',
        biodegradability: 'Low',
        waterUsage: 'Low',
        carbonFootprint: 'Medium',
        certifications: ['Bluesign', 'OEKO-TEX']
      },
      'silk-blend': {
        recyclability: 'Low',
        biodegradability: 'Partial',
        waterUsage: 'Medium',
        carbonFootprint: 'Low',
        certifications: ['OEKO-TEX']
      },
      'wool-blend': {
        recyclability: 'Moderate',
        biodegradability: 'Partial',
        waterUsage: 'Medium',
        carbonFootprint: 'Medium',
        certifications: ['RWS', 'OEKO-TEX']
      }
    };

    return info[fabricType] || info['cotton-blend'];
  }
}
