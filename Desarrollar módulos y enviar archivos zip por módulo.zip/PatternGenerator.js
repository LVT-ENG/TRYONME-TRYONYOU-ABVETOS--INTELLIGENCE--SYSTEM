/**
 * Pattern Generator
 * Generates DXF pattern files for garment production
 */

import makerjs from 'makerjs';
import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger.js';

export class PatternGenerator {
  constructor() {
    this.outputDir = './output/cap/patterns';
    this.ensureOutputDir();
  }

  async ensureOutputDir() {
    try {
      await fs.mkdir(this.outputDir, { recursive: true });
    } catch (error) {
      logger.error('Failed to create output directory', { error });
    }
  }

  /**
   * Generate garment pattern based on parameters
   * @param {Object} params - Generation parameters
   * @returns {Promise<Object>} Pattern data with file path
   */
  async generate(params) {
    const {
      anthropometricData,
      style,
      occasion,
      preferences,
      emotionalState,
      trends
    } = params;

    logger.info('Generating pattern', { style, occasion });

    // Extract measurements
    const measurements = this.extractMeasurements(anthropometricData);
    
    // Apply style adjustments
    const adjustedMeasurements = this.applyStyleAdjustments(
      measurements,
      style,
      occasion,
      trends
    );

    // Apply emotional context
    const emotionalAdjustments = this.applyEmotionalAdjustments(
      adjustedMeasurements,
      emotionalState
    );

    // Generate pattern pieces
    const patternPieces = this.generatePatternPieces(
      emotionalAdjustments,
      style
    );

    // Create DXF model
    const dxfModel = this.createDXFModel(patternPieces);

    // Generate unique ID
    const patternId = uuidv4();
    const filename = `pattern_${patternId}.dxf`;
    const filepath = path.join(this.outputDir, filename);

    // Export to DXF
    await this.exportDXF(dxfModel, filepath);

    // Generate SVG for preview
    const svgPath = filepath.replace('.dxf', '.svg');
    await this.exportSVG(dxfModel, svgPath);

    return {
      patternId,
      dxfPath: filepath,
      svgPath,
      pieces: patternPieces.map(p => ({
        name: p.name,
        dimensions: p.dimensions,
        vertices: p.vertices.length
      })),
      measurements: emotionalAdjustments,
      style,
      occasion
    };
  }

  /**
   * Extract and normalize measurements
   */
  extractMeasurements(anthropometricData) {
    return {
      height: anthropometricData.height || 170,
      bust: anthropometricData.bust || 90,
      waist: anthropometricData.waist || 70,
      hip: anthropometricData.hip || 95,
      shoulderWidth: anthropometricData.shoulderWidth || 40,
      armLength: anthropometricData.armLength || 60,
      inseam: anthropometricData.inseam || 80,
      neckCircumference: anthropometricData.neckCircumference || 36
    };
  }

  /**
   * Apply style-specific adjustments
   */
  applyStyleAdjustments(measurements, style, occasion, trends) {
    const adjusted = { ...measurements };

    // Style adjustments
    const styleFactors = {
      'fitted': { bust: 0.98, waist: 0.95, hip: 0.98 },
      'regular': { bust: 1.02, waist: 1.05, hip: 1.02 },
      'loose': { bust: 1.08, waist: 1.15, hip: 1.08 },
      'oversized': { bust: 1.15, waist: 1.25, hip: 1.15 }
    };

    const factor = styleFactors[style] || styleFactors['regular'];
    
    adjusted.bust *= factor.bust;
    adjusted.waist *= factor.waist;
    adjusted.hip *= factor.hip;

    // Occasion adjustments
    if (occasion === 'formal') {
      adjusted.shoulderWidth *= 1.02;
      adjusted.armLength *= 0.98;
    } else if (occasion === 'sport') {
      adjusted.bust *= 1.05;
      adjusted.waist *= 1.08;
    }

    // Trend adjustments
    if (trends && trends.silhouette === 'boxy') {
      adjusted.bust *= 1.05;
      adjusted.waist *= 1.10;
    }

    return adjusted;
  }

  /**
   * Apply emotional state adjustments
   */
  applyEmotionalAdjustments(measurements, emotionalState) {
    if (!emotionalState) return measurements;

    const adjusted = { ...measurements };

    // Confidence boost: slightly more fitted
    if (emotionalState.confidence > 0.7) {
      adjusted.waist *= 0.98;
    }

    // Comfort seeking: slightly looser
    if (emotionalState.comfort > 0.7) {
      adjusted.bust *= 1.03;
      adjusted.waist *= 1.05;
    }

    return adjusted;
  }

  /**
   * Generate pattern pieces
   */
  generatePatternPieces(measurements, style) {
    const pieces = [];

    // Front piece
    pieces.push(this.generateFrontPiece(measurements, style));

    // Back piece
    pieces.push(this.generateBackPiece(measurements, style));

    // Sleeve pieces (if applicable)
    if (style !== 'sleeveless') {
      pieces.push(this.generateSleevePiece(measurements, style, 'left'));
      pieces.push(this.generateSleevePiece(measurements, style, 'right'));
    }

    return pieces;
  }

  /**
   * Generate front piece
   */
  generateFrontPiece(measurements, style) {
    const width = measurements.bust / 2;
    const length = measurements.height * 0.4;

    const vertices = [
      { x: 0, y: 0 },
      { x: width, y: 0 },
      { x: width, y: length },
      { x: 0, y: length }
    ];

    return {
      name: 'front',
      type: 'body',
      dimensions: { width, length },
      vertices
    };
  }

  /**
   * Generate back piece
   */
  generateBackPiece(measurements, style) {
    const width = measurements.bust / 2;
    const length = measurements.height * 0.4;

    const vertices = [
      { x: 0, y: 0 },
      { x: width, y: 0 },
      { x: width, y: length },
      { x: 0, y: length }
    ];

    return {
      name: 'back',
      type: 'body',
      dimensions: { width, length },
      vertices
    };
  }

  /**
   * Generate sleeve piece
   */
  generateSleevePiece(measurements, style, side) {
    const width = measurements.armLength * 0.4;
    const length = measurements.armLength;

    const vertices = [
      { x: 0, y: 0 },
      { x: width, y: 0 },
      { x: width * 0.8, y: length },
      { x: width * 0.2, y: length }
    ];

    return {
      name: `sleeve_${side}`,
      type: 'sleeve',
      dimensions: { width, length },
      vertices
    };
  }

  /**
   * Create DXF model from pattern pieces
   */
  createDXFModel(pieces) {
    const model = {};

    pieces.forEach((piece, index) => {
      const lines = [];
      
      for (let i = 0; i < piece.vertices.length; i++) {
        const start = piece.vertices[i];
        const end = piece.vertices[(i + 1) % piece.vertices.length];
        
        lines.push(new makerjs.paths.Line(
          [start.x, start.y],
          [end.x, end.y]
        ));
      }

      model[`piece_${index}_${piece.name}`] = {
        paths: lines.reduce((acc, line, idx) => {
          acc[`line_${idx}`] = line;
          return acc;
        }, {})
      };
    });

    return model;
  }

  /**
   * Export to DXF format
   */
  async exportDXF(model, filepath) {
    try {
      const dxf = makerjs.exporter.toDXF(model);
      await fs.writeFile(filepath, dxf, 'utf8');
      logger.info('DXF pattern exported', { filepath });
    } catch (error) {
      logger.error('Failed to export DXF', { error, filepath });
      throw error;
    }
  }

  /**
   * Export to SVG format for preview
   */
  async exportSVG(model, filepath) {
    try {
      const svg = makerjs.exporter.toSVG(model);
      await fs.writeFile(filepath, svg, 'utf8');
      logger.info('SVG preview exported', { filepath });
    } catch (error) {
      logger.error('Failed to export SVG', { error, filepath });
    }
  }
}
