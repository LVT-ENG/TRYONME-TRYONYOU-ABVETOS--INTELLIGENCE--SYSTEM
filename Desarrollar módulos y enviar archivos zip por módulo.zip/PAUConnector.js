/**
 * PAU Connector
 * Connects to PAU (Personalized Aesthetic Understanding) module
 * for emotional state and aesthetic preferences
 */

import axios from 'axios';
import { logger } from '../utils/logger.js';

export class PAUConnector {
  constructor(config = {}) {
    this.baseURL = config.baseURL || process.env.PAU_API_URL || 'http://localhost:4001/api/pau';
    this.timeout = config.timeout || 5000;
    this.connected = false;
    
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: this.timeout,
      headers: {
        'Content-Type': 'application/json'
      }
    });

    this.initConnection();
  }

  /**
   * Initialize connection to PAU
   */
  async initConnection() {
    try {
      const response = await this.client.get('/health');
      this.connected = response.status === 200;
      logger.info('PAU connector initialized', { connected: this.connected });
    } catch (error) {
      logger.warn('PAU connection failed, using fallback mode', { error: error.message });
      this.connected = false;
    }
  }

  /**
   * Check if connected to PAU
   */
  isConnected() {
    return this.connected;
  }

  /**
   * Get emotional state for user
   * @param {string} userId - User ID
   * @returns {Promise<Object>} Emotional state data
   */
  async getEmotionalState(userId) {
    try {
      if (!this.connected) {
        return this.getFallbackEmotionalState();
      }

      const response = await this.client.get(`/emotion/${userId}`);
      
      logger.info('Retrieved emotional state from PAU', { userId });
      
      return {
        userId,
        confidence: response.data.confidence || 0.5,
        comfort: response.data.comfort || 0.5,
        expressiveness: response.data.expressiveness || 0.5,
        formality: response.data.formality || 0.5,
        energy: response.data.energy || 0.5,
        mood: response.data.mood || 'neutral',
        timestamp: response.data.timestamp || new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to get emotional state from PAU', { error: error.message, userId });
      return this.getFallbackEmotionalState();
    }
  }

  /**
   * Get aesthetic preferences for user
   * @param {string} userId - User ID
   * @returns {Promise<Object>} Aesthetic preferences
   */
  async getAestheticPreferences(userId) {
    try {
      if (!this.connected) {
        return this.getFallbackAestheticPreferences();
      }

      const response = await this.client.get(`/aesthetics/${userId}`);
      
      logger.info('Retrieved aesthetic preferences from PAU', { userId });
      
      return {
        userId,
        colorPalette: response.data.colorPalette || ['neutral'],
        stylePreference: response.data.stylePreference || 'casual',
        patternPreference: response.data.patternPreference || 'solid',
        fitPreference: response.data.fitPreference || 'regular',
        occasionHistory: response.data.occasionHistory || [],
        timestamp: response.data.timestamp || new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to get aesthetic preferences from PAU', { error: error.message, userId });
      return this.getFallbackAestheticPreferences();
    }
  }

  /**
   * Update emotional state
   * @param {string} userId - User ID
   * @param {Object} emotionalData - Emotional state data
   * @returns {Promise<Object>} Update result
   */
  async updateEmotionalState(userId, emotionalData) {
    try {
      if (!this.connected) {
        logger.warn('PAU not connected, skipping emotional state update');
        return { success: false, reason: 'not_connected' };
      }

      const response = await this.client.post(`/emotion/${userId}`, emotionalData);
      
      logger.info('Updated emotional state in PAU', { userId });
      
      return {
        success: true,
        userId,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to update emotional state in PAU', { error: error.message, userId });
      return { success: false, error: error.message };
    }
  }

  /**
   * Get color recommendations based on emotional state
   * @param {Object} emotionalState - Emotional state data
   * @returns {Promise<Array>} Color recommendations
   */
  async getColorRecommendations(emotionalState) {
    try {
      if (!this.connected) {
        return this.getFallbackColorRecommendations(emotionalState);
      }

      const response = await this.client.post('/colors/recommend', emotionalState);
      
      logger.info('Retrieved color recommendations from PAU');
      
      return response.data.colors || this.getFallbackColorRecommendations(emotionalState);
    } catch (error) {
      logger.error('Failed to get color recommendations from PAU', { error: error.message });
      return this.getFallbackColorRecommendations(emotionalState);
    }
  }

  /**
   * Fallback emotional state (when PAU unavailable)
   */
  getFallbackEmotionalState() {
    return {
      confidence: 0.6,
      comfort: 0.7,
      expressiveness: 0.5,
      formality: 0.5,
      energy: 0.6,
      mood: 'neutral',
      timestamp: new Date().toISOString(),
      source: 'fallback'
    };
  }

  /**
   * Fallback aesthetic preferences (when PAU unavailable)
   */
  getFallbackAestheticPreferences() {
    return {
      colorPalette: ['navy', 'white', 'gray', 'black'],
      stylePreference: 'casual',
      patternPreference: 'solid',
      fitPreference: 'regular',
      occasionHistory: ['casual', 'work'],
      timestamp: new Date().toISOString(),
      source: 'fallback'
    };
  }

  /**
   * Fallback color recommendations
   */
  getFallbackColorRecommendations(emotionalState) {
    const baseColors = ['navy', 'white', 'gray', 'black'];
    
    // Add colors based on emotional state
    if (emotionalState && emotionalState.energy > 0.7) {
      baseColors.push('red', 'orange');
    }
    
    if (emotionalState && emotionalState.confidence > 0.7) {
      baseColors.push('burgundy', 'forest-green');
    }
    
    if (emotionalState && emotionalState.comfort > 0.7) {
      baseColors.push('beige', 'soft-blue');
    }

    return baseColors.slice(0, 5);
  }

  /**
   * Reconnect to PAU
   */
  async reconnect() {
    logger.info('Attempting to reconnect to PAU');
    await this.initConnection();
    return this.connected;
  }
}
