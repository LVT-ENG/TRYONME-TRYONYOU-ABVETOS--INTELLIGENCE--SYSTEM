/**
 * Render Engine
 * Generates photorealistic mockups of garments
 */

import { createCanvas, loadImage } from 'canvas';
import sharp from 'sharp';
import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger.js';

export class RenderEngine {
  constructor() {
    this.outputDir = './output/cap/renders';
    this.ensureOutputDir();
    
    this.resolutions = {
      low: { width: 800, height: 1200 },
      medium: { width: 1600, height: 2400 },
      high: { width: 2400, height: 3600 },
      ultra: { width: 4000, height: 6000 }
    };

    this.lightingPresets = {
      studio: {
        ambient: 0.4,
        key: 0.8,
        fill: 0.3,
        rim: 0.5
      },
      natural: {
        ambient: 0.6,
        key: 0.7,
        fill: 0.4,
        rim: 0.3
      },
      dramatic: {
        ambient: 0.2,
        key: 1.0,
        fill: 0.2,
        rim: 0.7
      }
    };
  }

  async ensureOutputDir() {
    try {
      await fs.mkdir(this.outputDir, { recursive: true });
    } catch (error) {
      logger.error('Failed to create renders output directory', { error });
    }
  }

  /**
   * Render garment mockup
   * @param {Object} params - Render parameters
   * @returns {Promise<Object>} Render result
   */
  async render(params) {
    const {
      pattern,
      fabricMap,
      avatar,
      lighting = 'studio',
      resolution = 'high'
    } = params;

    logger.info('Starting garment render', { 
      patternId: pattern.patternId,
      resolution,
      lighting 
    });

    // Get resolution settings
    const res = this.resolutions[resolution] || this.resolutions.high;

    // Create canvas
    const canvas = createCanvas(res.width, res.height);
    const ctx = canvas.getContext('2d');

    // Set background
    ctx.fillStyle = '#f5f5f5';
    ctx.fillRect(0, 0, res.width, res.height);

    // Apply lighting
    const lightingSettings = this.lightingPresets[lighting] || this.lightingPresets.studio;

    // Render avatar silhouette
    await this.renderAvatar(ctx, avatar, res);

    // Render garment on avatar
    await this.renderGarment(ctx, pattern, fabricMap, avatar, res, lightingSettings);

    // Apply post-processing
    await this.applyPostProcessing(ctx, res, lightingSettings);

    // Generate unique ID
    const renderId = uuidv4();
    const filename = `render_${renderId}.png`;
    const filepath = path.join(this.outputDir, filename);

    // Save render
    const buffer = canvas.toBuffer('image/png');
    await fs.writeFile(filepath, buffer);

    // Generate thumbnail
    const thumbnailPath = await this.generateThumbnail(filepath, renderId);

    logger.info('Garment render completed', { 
      renderId,
      filepath,
      resolution: `${res.width}x${res.height}` 
    });

    return {
      renderId,
      pngPath: filepath,
      thumbnailPath,
      resolution: res,
      lighting,
      fileSize: buffer.length,
      dimensions: {
        width: res.width,
        height: res.height
      }
    };
  }

  /**
   * Render avatar silhouette
   */
  async renderAvatar(ctx, avatar, res) {
    const centerX = res.width / 2;
    const scale = res.height / 200; // Scale based on height

    // Extract measurements
    const bust = (avatar.bust || 90) * scale * 0.4;
    const waist = (avatar.waist || 70) * scale * 0.4;
    const hip = (avatar.hip || 95) * scale * 0.4;
    const shoulderWidth = (avatar.shoulderWidth || 40) * scale * 0.5;

    // Draw body silhouette
    ctx.save();
    ctx.fillStyle = '#e0e0e0';
    ctx.strokeStyle = '#bdbdbd';
    ctx.lineWidth = 2;

    // Head
    const headRadius = 40 * scale;
    const headY = 80 * scale;
    ctx.beginPath();
    ctx.arc(centerX, headY, headRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Torso
    const torsoTop = headY + headRadius + 10 * scale;
    const torsoHeight = res.height * 0.5;

    ctx.beginPath();
    ctx.moveTo(centerX - shoulderWidth, torsoTop);
    ctx.lineTo(centerX + shoulderWidth, torsoTop);
    ctx.quadraticCurveTo(centerX + bust, torsoTop + torsoHeight * 0.2, centerX + waist, torsoTop + torsoHeight * 0.4);
    ctx.quadraticCurveTo(centerX + hip, torsoTop + torsoHeight * 0.6, centerX + waist * 0.8, torsoTop + torsoHeight);
    ctx.lineTo(centerX - waist * 0.8, torsoTop + torsoHeight);
    ctx.quadraticCurveTo(centerX - hip, torsoTop + torsoHeight * 0.6, centerX - waist, torsoTop + torsoHeight * 0.4);
    ctx.quadraticCurveTo(centerX - bust, torsoTop + torsoHeight * 0.2, centerX - shoulderWidth, torsoTop);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.restore();
  }

  /**
   * Render garment on avatar
   */
  async renderGarment(ctx, pattern, fabricMap, avatar, res, lightingSettings) {
    const centerX = res.width / 2;
    const scale = res.height / 200;

    // Get fabric color
    const fabricColor = this.getFabricColor(fabricMap);

    // Apply lighting to fabric color
    const litColor = this.applyLighting(fabricColor, lightingSettings);

    ctx.save();
    ctx.fillStyle = litColor;
    ctx.strokeStyle = this.darkenColor(litColor, 0.3);
    ctx.lineWidth = 3;

    // Render each pattern piece
    pattern.pieces.forEach((piece, index) => {
      this.renderPatternPiece(ctx, piece, index, centerX, scale, litColor);
    });

    // Add fabric texture
    await this.applyFabricTexture(ctx, fabricMap, res);

    // Add seam lines
    this.renderSeamLines(ctx, pattern, centerX, scale);

    ctx.restore();
  }

  /**
   * Render individual pattern piece
   */
  renderPatternPiece(ctx, piece, index, centerX, scale, color) {
    const offsetY = 150 * scale;
    const pieceScale = scale * 2;

    ctx.save();
    ctx.fillStyle = color;

    ctx.beginPath();
    
    piece.vertices.forEach((vertex, i) => {
      const x = centerX + (vertex.x - piece.dimensions.width / 2) * pieceScale;
      const y = offsetY + vertex.y * pieceScale;
      
      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });

    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.restore();
  }

  /**
   * Get fabric color from fabric map
   */
  getFabricColor(fabricMap) {
    // Default colors based on fabric type
    const colorMap = {
      'cotton-blend': '#4a5568',
      'pure-cotton': '#e8e8e8',
      'stretch-denim': '#2d3748',
      'athletic-knit': '#1a202c',
      'silk-blend': '#f7fafc',
      'wool-blend': '#2c3e50'
    };

    return colorMap[fabricMap.fabricType] || '#4a5568';
  }

  /**
   * Apply lighting to color
   */
  applyLighting(color, lightingSettings) {
    // Parse hex color
    const r = parseInt(color.slice(1, 3), 16);
    const g = parseInt(color.slice(3, 5), 16);
    const b = parseInt(color.slice(5, 7), 16);

    // Apply key light intensity
    const intensity = lightingSettings.key;
    const litR = Math.min(255, Math.floor(r * (0.5 + intensity * 0.5)));
    const litG = Math.min(255, Math.floor(g * (0.5 + intensity * 0.5)));
    const litB = Math.min(255, Math.floor(b * (0.5 + intensity * 0.5)));

    return `rgb(${litR}, ${litG}, ${litB})`;
  }

  /**
   * Darken color
   */
  darkenColor(color, factor) {
    if (color.startsWith('rgb')) {
      const match = color.match(/\d+/g);
      const r = Math.floor(parseInt(match[0]) * (1 - factor));
      const g = Math.floor(parseInt(match[1]) * (1 - factor));
      const b = Math.floor(parseInt(match[2]) * (1 - factor));
      return `rgb(${r}, ${g}, ${b})`;
    }
    return color;
  }

  /**
   * Apply fabric texture
   */
  async applyFabricTexture(ctx, fabricMap, res) {
    // Create subtle texture overlay
    const imageData = ctx.getImageData(0, 0, res.width, res.height);
    const data = imageData.data;

    // Add noise for texture
    for (let i = 0; i < data.length; i += 4) {
      const noise = (Math.random() - 0.5) * 10;
      data[i] += noise;     // R
      data[i + 1] += noise; // G
      data[i + 2] += noise; // B
    }

    ctx.putImageData(imageData, 0, 0);
  }

  /**
   * Render seam lines
   */
  renderSeamLines(ctx, pattern, centerX, scale) {
    ctx.save();
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.lineWidth = 1;
    ctx.setLineDash([5, 5]);

    const offsetY = 150 * scale;
    const pieceScale = scale * 2;

    pattern.pieces.forEach(piece => {
      ctx.beginPath();
      
      piece.vertices.forEach((vertex, i) => {
        const x = centerX + (vertex.x - piece.dimensions.width / 2) * pieceScale;
        const y = offsetY + vertex.y * pieceScale;
        
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      });

      ctx.closePath();
      ctx.stroke();
    });

    ctx.restore();
  }

  /**
   * Apply post-processing effects
   */
  async applyPostProcessing(ctx, res, lightingSettings) {
    // Add vignette effect
    const gradient = ctx.createRadialGradient(
      res.width / 2, res.height / 2, 0,
      res.width / 2, res.height / 2, res.width * 0.7
    );
    gradient.addColorStop(0, 'rgba(0, 0, 0, 0)');
    gradient.addColorStop(1, `rgba(0, 0, 0, ${0.3 * (1 - lightingSettings.ambient)})`);

    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, res.width, res.height);
  }

  /**
   * Generate thumbnail
   */
  async generateThumbnail(filepath, renderId) {
    const thumbnailPath = path.join(
      this.outputDir, 
      `render_${renderId}_thumb.png`
    );

    await sharp(filepath)
      .resize(400, 600, {
        fit: 'cover',
        position: 'center'
      })
      .png({ quality: 80 })
      .toFile(thumbnailPath);

    logger.info('Thumbnail generated', { thumbnailPath });

    return thumbnailPath;
  }
}
