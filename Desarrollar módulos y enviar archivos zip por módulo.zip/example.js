/**
 * CAP Module Usage Example
 * Demonstrates how to use the Creative Auto-Production module
 */

import { CAP } from './index.js';
import { logger } from './utils/logger.js';

/**
 * Example 1: Basic garment generation
 */
async function basicGeneration() {
  console.log('\n=== Example 1: Basic Garment Generation ===\n');

  const cap = new CAP({
    minFitScore: 0.85,
    outputDir: './output/cap'
  });

  try {
    const result = await cap.generate({
      fitScore: 0.75, // Below threshold, will trigger generation
      anthropometricData: {
        height: 175,
        bust: 92,
        waist: 72,
        hip: 98,
        shoulderWidth: 42,
        armLength: 62
      },
      style: 'casual',
      occasion: 'work',
      userId: 'user-demo-001'
    });

    console.log('✅ Generation successful!');
    console.log('Garment ID:', result.garmentId);
    console.log('Files generated:');
    console.log('  - Pattern:', result.files.pattern);
    console.log('  - Seams:', result.files.seams);
    console.log('  - Fabric Map:', result.files.fabricMap);
    console.log('  - Render:', result.files.render);
    console.log('  - Metadata:', result.files.metadata);
    console.log('Production Order ID:', result.productionOrder.orderId);
  } catch (error) {
    console.error('❌ Generation failed:', error.message);
  }
}

/**
 * Example 2: Custom fabric and style
 */
async function customFabricGeneration() {
  console.log('\n=== Example 2: Custom Fabric and Style ===\n');

  const cap = new CAP();

  try {
    const result = await cap.generate({
      fitScore: 0.70,
      anthropometricData: {
        height: 168,
        bust: 88,
        waist: 68,
        hip: 94
      },
      style: 'formal',
      occasion: 'formal',
      fabricType: 'silk-blend',
      elasticity: 'low',
      priority: 'high',
      quantity: 2,
      userId: 'user-demo-002'
    });

    console.log('✅ Custom garment generated!');
    console.log('Garment ID:', result.garmentId);
    console.log('Fabric Type:', result.metadata.fabric.type);
    console.log('Style:', result.metadata.design.style);
    console.log('Priority:', result.productionOrder.priority);
    console.log('Quantity:', result.productionOrder.quantity);
  } catch (error) {
    console.error('❌ Generation failed:', error.message);
  }
}

/**
 * Example 3: Athletic wear generation
 */
async function athleticWearGeneration() {
  console.log('\n=== Example 3: Athletic Wear Generation ===\n');

  const cap = new CAP();

  try {
    const result = await cap.generate({
      fitScore: 0.65,
      anthropometricData: {
        height: 182,
        bust: 100,
        waist: 82,
        hip: 102
      },
      style: 'sport',
      occasion: 'sport',
      fabricType: 'athletic-knit',
      elasticity: 'extra-high',
      priority: 'normal',
      userId: 'user-demo-003'
    });

    console.log('✅ Athletic wear generated!');
    console.log('Garment ID:', result.garmentId);
    console.log('Elasticity:', result.metadata.fabric.elasticity);
    console.log('Breathability:', result.metadata.fabric.breathability);
    console.log('Estimated Production Time:', result.productionOrder.estimate.estimatedDuration);
  } catch (error) {
    console.error('❌ Generation failed:', error.message);
  }
}

/**
 * Example 4: Check CAP status
 */
async function checkStatus() {
  console.log('\n=== Example 4: Check CAP Status ===\n');

  const cap = new CAP();
  const status = cap.getStatus();

  console.log('Module:', status.module);
  console.log('Version:', status.version);
  console.log('Status:', status.status);
  console.log('Configuration:', JSON.stringify(status.config, null, 2));
  console.log('Connectors:');
  console.log('  - PAU:', status.connectors.pau ? '✅ Connected' : '❌ Disconnected');
  console.log('  - FTT:', status.connectors.ftt ? '✅ Connected' : '❌ Disconnected');
  console.log('  - Smart Wardrobe:', status.connectors.smartWardrobe ? '✅ Connected' : '❌ Disconnected');
  console.log('  - JIT Factory:', status.connectors.jit ? '✅ Connected' : '❌ Disconnected');
}

/**
 * Example 5: Fit score above threshold (skip generation)
 */
async function skipGeneration() {
  console.log('\n=== Example 5: Skip Generation (High Fit Score) ===\n');

  const cap = new CAP({
    minFitScore: 0.85
  });

  try {
    const result = await cap.generate({
      fitScore: 0.92, // Above threshold, will skip
      anthropometricData: {
        height: 170,
        bust: 90,
        waist: 70,
        hip: 95
      },
      style: 'casual',
      userId: 'user-demo-004'
    });

    console.log('Status:', result.status);
    console.log('Reason:', result.reason);
    console.log('Fit Score:', result.fitScore);
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

/**
 * Example 6: Export garment for production
 */
async function exportGarment() {
  console.log('\n=== Example 6: Export Garment for Production ===\n');

  const cap = new CAP();

  try {
    // First generate a garment
    const generateResult = await cap.generate({
      fitScore: 0.70,
      anthropometricData: {
        height: 175,
        bust: 92,
        waist: 72,
        hip: 98
      },
      style: 'casual',
      userId: 'user-demo-005'
    });

    console.log('✅ Garment generated:', generateResult.garmentId);

    // Then export it
    const exportResult = await cap.export({
      fitScore: 0.70,
      anthropometricData: {
        height: 175,
        bust: 92,
        waist: 72,
        hip: 98
      },
      style: 'casual',
      userId: 'user-demo-005'
    });

    console.log('✅ Garment exported!');
    console.log('Export Format:', exportResult.format);
    console.log('Exported At:', exportResult.exportedAt);
  } catch (error) {
    console.error('❌ Export failed:', error.message);
  }
}

/**
 * Run all examples
 */
async function runAllExamples() {
  console.log('\n╔════════════════════════════════════════════╗');
  console.log('║  CAP Module - Usage Examples              ║');
  console.log('╚════════════════════════════════════════════╝');

  try {
    await checkStatus();
    await basicGeneration();
    await customFabricGeneration();
    await athleticWearGeneration();
    await skipGeneration();
    await exportGarment();

    console.log('\n✅ All examples completed successfully!\n');
  } catch (error) {
    console.error('\n❌ Example execution failed:', error.message);
  }
}

// Run examples if executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runAllExamples().catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
  });
}

export {
  basicGeneration,
  customFabricGeneration,
  athleticWearGeneration,
  checkStatus,
  skipGeneration,
  exportGarment,
  runAllExamples
};
