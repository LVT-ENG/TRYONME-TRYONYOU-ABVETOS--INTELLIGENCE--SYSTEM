/**
 * JIT Connector
 * Connects to JIT (Just-In-Time) Factory Orchestrator for production
 */

import axios from 'axios';
import fs from 'fs/promises';
import FormData from 'form-data';
import { logger } from '../utils/logger.js';

export class JITConnector {
  constructor(config = {}) {
    this.baseURL = config.baseURL || process.env.JIT_API_URL || 'http://localhost:4004/api/jit';
    this.timeout = config.timeout || 15000;
    this.connected = false;
    
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: this.timeout,
      headers: {
        'Content-Type': 'application/json'
      }
    });

    this.initConnection();
  }

  /**
   * Initialize connection to JIT Factory
   */
  async initConnection() {
    try {
      const response = await this.client.get('/health');
      this.connected = response.status === 200;
      logger.info('JIT connector initialized', { connected: this.connected });
    } catch (error) {
      logger.warn('JIT connection failed, using fallback mode', { error: error.message });
      this.connected = false;
    }
  }

  /**
   * Check if connected to JIT Factory
   */
  isConnected() {
    return this.connected;
  }

  /**
   * Create production order
   * @param {Object} params - Order parameters
   * @returns {Promise<Object>} Order result
   */
  async createOrder(params) {
    const { garmentId, files, priority, quantity } = params;

    try {
      if (!this.connected) {
        logger.warn('JIT not connected, creating mock order');
        return this.createMockOrder(params);
      }

      // Prepare order data
      const orderData = {
        garmentId,
        priority: priority || 'normal',
        quantity: quantity || 1,
        requestedBy: 'CAP',
        requestedAt: new Date().toISOString(),
        productionType: 'on-demand',
        files: {
          pattern: files.pattern,
          seams: files.seams,
          fabricMap: files.fabricMap,
          metadata: files.metadata
        }
      };

      // Create order
      const response = await this.client.post('/orders', orderData);
      const orderId = response.data.orderId;

      logger.info('Production order created in JIT', { 
        orderId, 
        garmentId 
      });

      // Upload production files
      const uploadResults = await this.uploadProductionFiles(orderId, files);

      // Get estimated completion time
      const estimate = await this.getProductionEstimate(orderId);

      return {
        success: true,
        orderId,
        garmentId,
        status: 'queued',
        priority,
        quantity,
        files: uploadResults,
        estimate,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to create production order in JIT', { 
        error: error.message, 
        garmentId 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Upload production files
   * @param {string} orderId - Order ID
   * @param {Object} files - Production files
   * @returns {Promise<Object>} Upload results
   */
  async uploadProductionFiles(orderId, files) {
    const uploadResults = {};

    for (const [fileType, filePath] of Object.entries(files)) {
      try {
        const formData = new FormData();
        const fileBuffer = await fs.readFile(filePath);
        formData.append('file', fileBuffer, {
          filename: filePath.split('/').pop(),
          contentType: this.getContentType(fileType)
        });
        formData.append('type', fileType);

        const response = await this.client.post(
          `/orders/${orderId}/files`,
          formData,
          {
            headers: formData.getHeaders()
          }
        );

        uploadResults[fileType] = {
          success: true,
          url: response.data.url,
          fileId: response.data.fileId
        };

        logger.info('Production file uploaded to JIT', { 
          orderId, 
          fileType 
        });
      } catch (error) {
        logger.error('Failed to upload production file to JIT', { 
          error: error.message, 
          orderId, 
          fileType 
        });
        uploadResults[fileType] = {
          success: false,
          error: error.message
        };
      }
    }

    return uploadResults;
  }

  /**
   * Get content type for file type
   */
  getContentType(fileType) {
    const contentTypes = {
      pattern: 'application/dxf',
      seams: 'application/json',
      fabricMap: 'application/json',
      render: 'image/png',
      metadata: 'application/x-yaml'
    };

    return contentTypes[fileType] || 'application/octet-stream';
  }

  /**
   * Get production estimate
   * @param {string} orderId - Order ID
   * @returns {Promise<Object>} Production estimate
   */
  async getProductionEstimate(orderId) {
    try {
      const response = await this.client.get(`/orders/${orderId}/estimate`);
      
      logger.info('Retrieved production estimate from JIT', { orderId });
      
      return {
        estimatedStartTime: response.data.estimatedStartTime,
        estimatedCompletionTime: response.data.estimatedCompletionTime,
        estimatedDuration: response.data.estimatedDuration,
        queuePosition: response.data.queuePosition
      };
    } catch (error) {
      logger.error('Failed to get production estimate from JIT', { 
        error: error.message, 
        orderId 
      });
      return this.getMockEstimate();
    }
  }

  /**
   * Get order status
   * @param {string} orderId - Order ID
   * @returns {Promise<Object>} Order status
   */
  async getOrderStatus(orderId) {
    try {
      if (!this.connected) {
        return { success: false, reason: 'not_connected' };
      }

      const response = await this.client.get(`/orders/${orderId}`);
      
      logger.info('Retrieved order status from JIT', { 
        orderId, 
        status: response.data.status 
      });
      
      return {
        success: true,
        orderId,
        status: response.data.status,
        progress: response.data.progress,
        currentStage: response.data.currentStage,
        estimatedCompletion: response.data.estimatedCompletion,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to get order status from JIT', { 
        error: error.message, 
        orderId 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Update order priority
   * @param {string} orderId - Order ID
   * @param {string} priority - New priority (low, normal, high, urgent)
   * @returns {Promise<Object>} Update result
   */
  async updatePriority(orderId, priority) {
    try {
      if (!this.connected) {
        return { success: false, reason: 'not_connected' };
      }

      const response = await this.client.patch(`/orders/${orderId}/priority`, {
        priority
      });
      
      logger.info('Updated order priority in JIT', { 
        orderId, 
        priority 
      });
      
      return {
        success: true,
        orderId,
        priority,
        newEstimate: response.data.newEstimate,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to update order priority in JIT', { 
        error: error.message, 
        orderId 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Cancel order
   * @param {string} orderId - Order ID
   * @returns {Promise<Object>} Cancellation result
   */
  async cancelOrder(orderId) {
    try {
      if (!this.connected) {
        return { success: false, reason: 'not_connected' };
      }

      const response = await this.client.post(`/orders/${orderId}/cancel`);
      
      logger.info('Cancelled order in JIT', { orderId });
      
      return {
        success: true,
        orderId,
        status: 'cancelled',
        refundable: response.data.refundable,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      logger.error('Failed to cancel order in JIT', { 
        error: error.message, 
        orderId 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Get factory capacity
   * @returns {Promise<Object>} Factory capacity information
   */
  async getFactoryCapacity() {
    try {
      if (!this.connected) {
        return this.getMockCapacity();
      }

      const response = await this.client.get('/factory/capacity');
      
      logger.info('Retrieved factory capacity from JIT');
      
      return {
        currentLoad: response.data.currentLoad,
        maxCapacity: response.data.maxCapacity,
        availableSlots: response.data.availableSlots,
        queueLength: response.data.queueLength,
        averageWaitTime: response.data.averageWaitTime
      };
    } catch (error) {
      logger.error('Failed to get factory capacity from JIT', { 
        error: error.message 
      });
      return this.getMockCapacity();
    }
  }

  /**
   * Get production history
   * @param {Object} filters - Filter criteria
   * @returns {Promise<Object>} Production history
   */
  async getProductionHistory(filters = {}) {
    try {
      if (!this.connected) {
        return { success: false, reason: 'not_connected' };
      }

      const response = await this.client.get('/orders/history', {
        params: filters
      });
      
      logger.info('Retrieved production history from JIT', { 
        count: response.data.orders.length 
      });
      
      return {
        success: true,
        orders: response.data.orders,
        total: response.data.total
      };
    } catch (error) {
      logger.error('Failed to get production history from JIT', { 
        error: error.message 
      });
      return { success: false, error: error.message };
    }
  }

  /**
   * Create mock order (fallback)
   */
  createMockOrder(params) {
    const orderId = `MOCK-${Date.now()}`;
    
    return {
      success: true,
      orderId,
      garmentId: params.garmentId,
      status: 'queued',
      priority: params.priority || 'normal',
      quantity: params.quantity || 1,
      files: {
        pattern: { success: true, mock: true },
        seams: { success: true, mock: true },
        fabricMap: { success: true, mock: true },
        metadata: { success: true, mock: true }
      },
      estimate: this.getMockEstimate(),
      timestamp: new Date().toISOString(),
      mock: true
    };
  }

  /**
   * Get mock estimate
   */
  getMockEstimate() {
    const now = new Date();
    const startTime = new Date(now.getTime() + 2 * 60 * 60 * 1000); // 2 hours
    const completionTime = new Date(startTime.getTime() + 24 * 60 * 60 * 1000); // +24 hours

    return {
      estimatedStartTime: startTime.toISOString(),
      estimatedCompletionTime: completionTime.toISOString(),
      estimatedDuration: '24 hours',
      queuePosition: 5
    };
  }

  /**
   * Get mock capacity
   */
  getMockCapacity() {
    return {
      currentLoad: 65,
      maxCapacity: 100,
      availableSlots: 35,
      queueLength: 12,
      averageWaitTime: '3 hours'
    };
  }

  /**
   * Reconnect to JIT Factory
   */
  async reconnect() {
    logger.info('Attempting to reconnect to JIT Factory');
    await this.initConnection();
    return this.connected;
  }
}
