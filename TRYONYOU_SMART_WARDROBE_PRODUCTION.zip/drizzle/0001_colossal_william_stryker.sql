CREATE TABLE `donations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`itemId` int NOT NULL,
	`donorUserId` int NOT NULL,
	`recipientUserId` int,
	`status` enum('offered','accepted','completed','cancelled') DEFAULT 'offered',
	`donationDate` timestamp,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `donations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `exchanges` (
	`id` int AUTO_INCREMENT NOT NULL,
	`offeredItemId` int NOT NULL,
	`requestedItemId` int NOT NULL,
	`requesterUserId` int NOT NULL,
	`providerUserId` int NOT NULL,
	`status` enum('pending','accepted','completed','cancelled') DEFAULT 'pending',
	`completedDate` timestamp,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `exchanges_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `marketplaceListings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`itemId` int NOT NULL,
	`userId` int NOT NULL,
	`platform` enum('wallapop','limon_cua','internal') NOT NULL,
	`externalId` varchar(255),
	`listingUrl` text,
	`price` decimal(10,2),
	`status` enum('draft','listed','sold','delisted') DEFAULT 'draft',
	`listedDate` timestamp,
	`soldDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `marketplaceListings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `outfitSuggestions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255),
	`occasion` varchar(255),
	`season` varchar(50),
	`itemIds` text,
	`compatibilityScore` int,
	`styleNotes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `outfitSuggestions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `pauInteractions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('outfit_suggestion','donation_advice','exchange_guidance','care_tips','style_consultation','general_chat') NOT NULL,
	`userMessage` text,
	`pauResponse` text,
	`context` text,
	`helpful` boolean,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `pauInteractions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `usageHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`itemId` int NOT NULL,
	`userId` int NOT NULL,
	`wornDate` timestamp NOT NULL DEFAULT (now()),
	`occasion` varchar(255),
	`outfitId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `usageHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wardrobeItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` enum('tops','bottoms','dresses','outerwear','shoes','accessories','activewear','sleepwear') NOT NULL,
	`color` varchar(100),
	`size` varchar(20),
	`brand` varchar(255),
	`condition` enum('new','excellent','good','fair','worn') DEFAULT 'good',
	`material` varchar(255),
	`season` enum('spring','summer','fall','winter','all-season') DEFAULT 'all-season',
	`imageUrl` text,
	`location` varchar(255),
	`purchaseDate` timestamp,
	`purchasePrice` decimal(10,2),
	`estimatedValue` decimal(10,2),
	`notes` text,
	`isAvailableForExchange` boolean DEFAULT false,
	`isAvailableForDonation` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wardrobeItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `sizeXS` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `users` ADD `sizeS` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `users` ADD `sizeM` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `users` ADD `sizeL` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `users` ADD `sizeXL` boolean DEFAULT false;--> statement-breakpoint
ALTER TABLE `users` ADD `styleProfile` text;