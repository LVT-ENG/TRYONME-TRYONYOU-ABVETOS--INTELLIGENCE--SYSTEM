import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import AdminSeed from "./pages/AdminSeed";
import SmartWardrobe from "./pages/SmartWardrobe";
import PauAssistant from "./pages/PauAssistant";
import SolidarityWardrobe from "./pages/SolidarityWardrobe";
import Marketplace from "./pages/Marketplace";
import VirtualTryOn from "./pages/VirtualTryOn";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
       <Route path={"/admin/seed"} component={AdminSeed} />
      <Route path={"/smart-wardrobe"} component={SmartWardrobe} />
      <Route path={"/pau-assistant"} component={PauAssistant} />
      <Route path={"/solidarity-wardrobe"} component={SolidarityWardrobe} />
      <Route path={"/marketplace"} component={Marketplace} />
      <Route path={"/virtual-tryon"} component={VirtualTryOn} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
