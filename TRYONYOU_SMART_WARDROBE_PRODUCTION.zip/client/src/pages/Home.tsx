import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, Heart, Gift, DollarSign, TrendingUp, Users, ArrowRight, CheckCircle } from "lucide-react";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        {/* Navigation */}
        <nav className="border-b border-slate-700/50 backdrop-blur-md sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">TRYONYOU</span>
            </div>
            <a href={getLoginUrl()} className="text-white hover:text-purple-300 transition">
              Sign In
            </a>
          </div>
        </nav>

        {/* Hero Section */}
        <div className="container mx-auto px-4 py-20">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Your Intelligent Wardrobe Companion
            </h1>
            <p className="text-xl text-slate-300 mb-8">
              Manage your clothing, get AI-powered outfit suggestions, share sustainably, and sell items directly from your wardrobe.
            </p>
            <a href={getLoginUrl()}>
              <Button size="lg" className="gap-2 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600">
                Get Started Free
                <ArrowRight className="w-4 h-4" />
              </Button>
            </a>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
            {[
              {
                icon: <Sparkles className="w-6 h-6" />,
                title: "Smart Wardrobe",
                description: "AI-powered outfit suggestions and wardrobe management",
                color: "from-purple-500 to-blue-500",
              },
              {
                icon: <Heart className="w-6 h-6" />,
                title: "Pau Assistant",
                description: "Your personal style advisor powered by AI",
                color: "from-pink-500 to-red-500",
              },
              {
                icon: <Gift className="w-6 h-6" />,
                title: "Solidarity Wardrobe",
                description: "Donate and exchange items with the community",
                color: "from-green-500 to-emerald-500",
              },
              {
                icon: <DollarSign className="w-6 h-6" />,
                title: "Marketplace",
                description: "Sell items on Wallapop and Limón Cuá instantly",
                color: "from-yellow-500 to-orange-500",
              },
            ].map((feature, idx) => (
              <Card key={idx} className="bg-slate-800/50 border-slate-700 backdrop-blur">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4`}>
                    <div className="text-white">{feature.icon}</div>
                  </div>
                  <CardTitle className="text-white">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-400">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Features Section */}
          <div className="max-w-4xl mx-auto mb-20">
            <h2 className="text-3xl font-bold text-white mb-12 text-center">Why Choose TRYONYOU?</h2>

            <div className="space-y-8">
              {[
                {
                  title: "Intelligent Wardrobe Management",
                  description: "Track every item, remember where you stored it, and get suggestions on what to wear based on weather, occasion, and your style preferences.",
                  items: ["Usage tracking", "Location memory", "Smart suggestions", "Size fit logic"],
                },
                {
                  title: "Pau AI Assistant",
                  description: "Your personal wardrobe advisor that learns your style, suggests outfits, and recommends when to donate or exchange items.",
                  items: ["Outfit suggestions", "Care tips", "Donation guidance", "Style consultation"],
                },
                {
                  title: "Sustainable Fashion Community",
                  description: "Share, donate, and exchange items with other TRYONYOU users. Reduce waste and build a more inclusive fashion ecosystem.",
                  items: ["Peer-to-peer exchanges", "Community donations", "Environmental impact tracking", "Family wardrobe sharing"],
                },
                {
                  title: "Direct Marketplace Integration",
                  description: "Sell your items directly on Wallapop and Limón Cuá with pre-filled listings and one-click publishing.",
                  items: ["Pre-filled listings", "Instant link generation", "Price suggestions", "Multi-platform support"],
                },
              ].map((section, idx) => (
                <div key={idx} className="bg-slate-800/50 border border-slate-700 rounded-lg p-8 backdrop-blur">
                  <h3 className="text-xl font-bold text-white mb-4">{section.title}</h3>
                  <p className="text-slate-400 mb-6">{section.description}</p>
                  <div className="grid grid-cols-2 gap-3">
                    {section.items.map((item, itemIdx) => (
                      <div key={itemIdx} className="flex items-center gap-2 text-slate-300">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span className="text-sm">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Section */}
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-12 text-center mb-20">
            <h2 className="text-3xl font-bold text-white mb-4">Ready to Transform Your Wardrobe?</h2>
            <p className="text-purple-100 mb-8 text-lg">Join thousands of users who are managing their fashion sustainably and intelligently.</p>
            <a href={getLoginUrl()}>
              <Button size="lg" variant="secondary" className="gap-2">
                Start Your Free Trial
                <ArrowRight className="w-4 h-4" />
              </Button>
            </a>
          </div>
        </div>

        {/* Footer */}
        <footer className="border-t border-slate-700/50 bg-slate-900/50 backdrop-blur-md py-8">
          <div className="container mx-auto px-4 text-center text-slate-400">
            <p>&copy; 2024 TRYONYOU. Intelligent wardrobe for a sustainable future.</p>
          </div>
        </footer>
      </div>
    );
  }

  // Authenticated view
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-900">TRYONYOU</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-slate-600">Welcome, {user?.name || "User"}!</span>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">Welcome to TRYONYOU</h1>
          <p className="text-lg text-slate-600 mb-12">Your intelligent wardrobe management platform</p>

          {/* Module Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {[
              {
                icon: <Sparkles className="w-8 h-8" />,
                title: "Smart Wardrobe",
                description: "Manage your items, track usage, and get outfit suggestions",
                href: "/smart-wardrobe",
                color: "from-purple-500 to-blue-500",
                accent: "purple",
              },
              {
                icon: <Heart className="w-8 h-8" />,
                title: "Pau Assistant",
                description: "Chat with your AI wardrobe advisor for personalized guidance",
                href: "/pau-assistant",
                color: "from-pink-500 to-red-500",
                accent: "pink",
              },
              {
                icon: <Gift className="w-8 h-8" />,
                title: "Solidarity Wardrobe",
                description: "Donate and exchange items with the community",
                href: "/solidarity-wardrobe",
                color: "from-green-500 to-emerald-500",
                accent: "green",
              },
              {
                icon: <DollarSign className="w-8 h-8" />,
                title: "Marketplace",
                description: "Sell your items on Wallapop and Limón Cuá",
                href: "/marketplace",
                color: "from-yellow-500 to-orange-500",
                accent: "yellow",
              },
              {
                icon: <Sparkles className="w-8 h-8" />,
                title: "Virtual Try-On",
                description: "Try on items using your camera in real-time",
                href: "/virtual-tryon",
                color: "from-indigo-500 to-purple-500",
                accent: "indigo",
              },
            ].map((module, idx) => (
              <Link key={idx} href={module.href}>
                <Card className="h-full hover:shadow-lg transition-all cursor-pointer overflow-hidden group">
                  <div className={`h-20 bg-gradient-to-r ${module.color}`} />
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${module.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                      <div className="text-white">{module.icon}</div>
                    </div>
                    <CardTitle>{module.title}</CardTitle>
                    <CardDescription>{module.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" className="w-full gap-2">
                      Enter <ArrowRight className="w-4 h-4" />
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>

          {/* Quick Stats */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">Your Wardrobe</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-slate-900">0</div>
                <p className="text-xs text-slate-500 mt-1">items tracked</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">Community Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-slate-900">0</div>
                <p className="text-xs text-slate-500 mt-1">items shared</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">Potential Earnings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-slate-900">€0</div>
                <p className="text-xs text-slate-500 mt-1">from marketplace sales</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
