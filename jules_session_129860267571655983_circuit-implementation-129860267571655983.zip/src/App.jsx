import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import FitModule from './pages/FitModule';
import CapModule from './pages/CapModule';
import AbvetModule from './pages/AbvetModule';
import ClaimsModule from './pages/ClaimsModule';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <div style={{ paddingBottom: '100px', minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
        <nav style={{ padding: '20px', borderBottom: '1px solid #333', display: 'flex', gap: '20px', justifyContent: 'center' }}>
          <Link to="/fit">Avatar (Fit)</Link>
          <Link to="/cap">Producción (Cap)</Link>
          <Link to="/abvet">Pago (Abvet)</Link>
          <Link to="/claims">Patent Claims</Link>
        </nav>

        <main style={{ flex: 1 }}>
          <Routes>
            <Route path="/" element={<div style={{textAlign: 'center', padding: '50px'}}><h1>Bienvenido a Divineo</h1><p>Seleccione un módulo arriba.</p></div>} />
            <Route path="/fit" element={<FitModule />} />
            <Route path="/cap" element={<CapModule />} />
            <Route path="/abvet" element={<AbvetModule />} />
            <Route path="/claims" element={<ClaimsModule />} />
          </Routes>
        </main>

        <Footer />
      </div>
    </Router>
  );
}

export default App;
