import React from 'react';

const Footer = () => {
  return (
    <footer style={{
      textAlign: 'center',
      padding: '20px',
      borderTop: '1px solid #333',
      marginTop: 'auto',
      backgroundColor: 'var(--anthracite)',
      color: 'white',
      position: 'fixed',
      bottom: 0,
      width: '100%'
    }}>
      <p style={{ margin: 0, fontSize: '0.9rem' }}>
        Protected by Patent <strong>PCT/EP2025/067317</strong>
      </p>
      <div style={{ marginTop: '5px' }}>
        <a 
          href="/docs/patent/consolidated_patent.pdf" 
          target="_blank" 
          rel="noopener noreferrer"
          style={{ fontSize: '0.8rem' }}
        >
          View Consolidated Patent
        </a>
      </div>
    </footer>
  );
};

export default Footer;
