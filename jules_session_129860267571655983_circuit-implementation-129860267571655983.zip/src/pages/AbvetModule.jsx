import React from 'react';

const AbvetModule = () => {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1 style={{ color: 'var(--gold)' }}>Pago Biométrico</h1>
      <p>Procesando Pago Biométrico.</p>
    </div>
  );
};

export default AbvetModule;
