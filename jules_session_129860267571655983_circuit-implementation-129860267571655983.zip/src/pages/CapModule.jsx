import React from 'react';

const CapModule = () => {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1 style={{ color: 'var(--gold)' }}>Creative Auto-Production</h1>
      <p>Producción Automática en Espera.</p>
    </div>
  );
};

export default CapModule;
