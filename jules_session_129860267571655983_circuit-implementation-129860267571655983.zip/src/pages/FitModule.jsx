import React from 'react';

const FitModule = () => {
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h1 style={{ color: 'var(--gold)' }}>Espejo Mágico</h1>
      <p>Módulo de Avatar 3D en construcción.</p>
    </div>
  );
};

export default FitModule;
