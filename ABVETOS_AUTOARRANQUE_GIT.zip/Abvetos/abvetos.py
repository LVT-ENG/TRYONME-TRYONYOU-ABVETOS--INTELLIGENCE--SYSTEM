#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import os
from datetime import datetime

try:
    from PIL import Image, ImageDraw
    PIL_OK = True
except Exception:
    PIL_OK = False

APP_NAME = "Abvetos"
BASE_DOMAIN = "abvetos.com"

ICLOUD_BASE = os.path.expanduser("~/Library/Mobile Documents/com~apple~CloudDocs")
OUT_DIR = os.path.join(ICLOUD_BASE, APP_NAME)

def timestamp():
    return datetime.now().isoformat()

def prepare_dir():
    os.makedirs(OUT_DIR, exist_ok=True)
    return OUT_DIR

def save_text(base):
    with open(os.path.join(base, "abvetos.txt"), "w", encoding="utf-8") as f:
        f.write(f"{APP_NAME} — {BASE_DOMAIN}\n")
        f.write(f"Timestamp: {timestamp()}\n")

def save_json(base):
    data = {
        "app": APP_NAME,
        "domain": BASE_DOMAIN,
        "mode": "auto",
        "timestamp": timestamp()
    }
    with open(os.path.join(base, "abvetos.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def save_image(base):
    if not PIL_OK:
        return
    img = Image.new("RGB", (600, 300), color=(20, 20, 20))
    d = ImageDraw.Draw(img)
    d.text((40, 130), f"{APP_NAME} — {BASE_DOMAIN}", fill=(255,255,255))
    img.save(os.path.join(base, "abvetos.png"))

def main():
    base = prepare_dir()
    save_text(base)
    save_json(base)
    save_image(base)
    os.system(f'open "{base}"')

if __name__ == "__main__":
    main()
