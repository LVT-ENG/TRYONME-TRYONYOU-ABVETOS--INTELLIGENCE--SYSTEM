export default function App() {
 return (
  <div style={{padding:'40px',fontSize:'22px'}}>
   TRYONYOU – ABVETOS – ULTRA – PLUS – ULTIMATUM<br/>
   Project Base (Manus + DRS-TRYONYOU v1.0)
  </div>
 )
}
