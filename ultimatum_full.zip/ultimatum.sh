#!/usr/bin/env bash
# =========================================================
# TRYONYOU–ABVETOS–ULTRA–PLUS–ULTIMATUM — FULL PIPELINE
# Baseline: Vite 7.1.2
# =========================================================
set -euo pipefail

CANONICAL="git@github.com:LVT-ENG/TRYONME-TRYONYOU-ABVETOS--INTELLIGENCE--SYSTEM.git"
WORKDIR="$HOME/tryonyou-abvetos-ultra-plus-ultimatum"
BRANCH_DEV="develop"
BRANCH_MAIN="main"

echo "🚀 Clonando/actualizando repo canónico..."
[ -d "$WORKDIR/.git" ] || git clone "$CANONICAL" "$WORKDIR"
cd "$WORKDIR"
git fetch --all
git checkout -B "$BRANCH_DEV"

echo "📂 Creando estructura Vite 7.1.2..."
mkdir -p apps/web/{public/{assets,docs/claims},src/{pages,components,styles,lib}}          packages/shared docs/{patent,merge} .github/workflows

# Tokens
cat > packages/shared/design-tokens.ts <<'TS'
export const colors = {
  gold:'#D3B26A', peacock:'#0E6B6B', anth:'#141619',
  base:'#0B0D10', text:'#EEF0F3',
  glass:'rgba(255,255,255,.06)', glassStroke:'rgba(255,255,255,.18)'
};
export const radii = { sm:'10px', md:'16px', lg:'22px', xl:'28px' };
export const shadow = { glow:'0 0 24px rgba(211,178,106,.35)', panel:'0 20px 60px rgba(0,0,0,.45)' };
export const z = { bg:0, hero:1, glass:2, ui:3, nav:10 };
export const dur = { fast:'160ms', normal:'320ms', slow:'680ms' };
export const ease = { out:'cubic-bezier(.2,.9,.2,1)' };
TS

# CSS global
cat > apps/web/src/styles/global.css <<'CSS'
:root{
  --gold:#D3B26A; --peacock:#0E6B6B; --anth:#141619; --base:#0B0D10; --text:#EEF0F3;
  --glass:rgba(255,255,255,.06); --glass-stroke:rgba(255,255,255,.18);
  --shadow-panel:0 20px 60px rgba(0,0,0,.45); --glow:0 0 24px rgba(211,178,106,.35);
  font-family:Inter,Roboto,system-ui,-apple-system,Segoe UI,sans-serif;
}
*{box-sizing:border-box} html,body,#app{height:100%;margin:0;background:var(--base);color:var(--text)}
a{color:var(--gold)} .container{max-width:1200px;margin:0 auto;padding:0 24px}
CSS

# index.html + vite.config
cat > apps/web/index.html <<'HTML'
<!doctype html>
<html>
<head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>TRYONYOU — Ultimatum</title></head>
<body>
  <div id="nav"></div><div id="app"></div>
  <script type="module" src="/src/main.ts"></script>
</body>
</html>
HTML

cat > apps/web/vite.config.ts <<'TS'
import { defineConfig } from 'vite';
export default defineConfig({ server:{port:5173}, preview:{port:4173} });
TS

# Simple Navbar
cat > apps/web/src/components/Navbar.tsx <<'TSX'
export default function Navbar(){
  return ("<nav class='container'><b>TRYONYOU</b> — <a onclick=\"window.nav('/')\">Home</a></nav>");
}
TSX

# Main entry (SPA router básico)
cat > apps/web/src/main.ts <<'TS'
import './styles/global.css';
import Navbar from './components/Navbar.tsx';
document.getElementById('nav')!.innerHTML = Navbar();
document.getElementById('app')!.innerHTML = "<h1>TRYONYOU — Ultimatum</h1>";
TS

# Claims README
cat > apps/web/public/docs/claims/README.md <<'MD'
# 8 Super-Claims
1) Avatar 3D paramétrico
2) Fit comparator objetivo
3) Simulación física textil
4) PAU Recommender (FTT)
5) CAP Auto-Production
6) Pago dual ABVET (iris+voz)
7) Orquestación JIT + QA
8) Sistema embebible/versionado
MD

# Workflows mínimos
cat > .github/workflows/deploy-vercel.yml <<'YAML'
name: deploy-vercel
on: { push: { branches: [ main ] } }
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: echo "Build & deploy Vercel aquí (token en secrets)"
YAML

cat > .github/workflows/notify-telegram.yml <<'YAML'
name: notify-telegram
on: { push: { branches: [ develop ] } }
jobs:
  notify:
    runs-on: ubuntu-latest
    steps:
      - run: echo "Notify Telegram (usar TELEGRAM_BOT_TOKEN)"
YAML

echo "✅ Pipeline listo: estructura + branding + claims + CI/CD base"
