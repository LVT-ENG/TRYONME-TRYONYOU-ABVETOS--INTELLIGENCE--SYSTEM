const input = document.getElementById("fileInput");
const preview = document.getElementById("preview");

if (input) {
  input.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    preview.src = url;
  });
}
