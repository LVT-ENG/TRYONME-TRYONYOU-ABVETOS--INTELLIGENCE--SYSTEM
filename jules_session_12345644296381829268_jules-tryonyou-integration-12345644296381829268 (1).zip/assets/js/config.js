const TryOnYouConfig = {
    store: "Galeries Lafayette",
    displayMetrics: false,
    useElasticityLogic: true,
    animation: "pau_snap_transition"
};
