#!/bin/bash

echo "🚀 Starting TryOnYou Pilot Integration..."

# 1. Create Web Structure
mkdir -p assets/js assets/css
touch demo.html

# 2. Inject the "No-Size" Configuration
cat <<EOF > assets/js/config.js
const TryOnYouConfig = {
    store: "Galeries Lafayette",
    displayMetrics: false,
    useElasticityLogic: true,
    animation: "pau_snap_transition"
};
EOF

# 3. Inject the Scanner Widget into demo.html
cat <<EOF > demo.html
<!DOCTYPE html>
<html lang="en">
<head><title>TryOnYou - Scanner</title></head>
<body>
    <div id="scanner-container">
        <h1>Body Scan in Progress...</h1>
        <p>Calculating the perfect fit based on drape and fabric elasticity.</p>
    </div>
    <script src="assets/js/config.js"></script>
</body>
</html>
EOF

# 4. Populate the Landing Page (index.html) with the "Snap" experience
cat <<EOF > index.html
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TryOnYou | Galeries Lafayette - Expérience Scan</title>
    <style>
        body { font-family: 'Helvetica', sans-serif; text-align: center; background: #f9f9f9; }
        .mirror-container { position: relative; width: 300px; margin: 50px auto; cursor: pointer; }
        #model-display { width: 100%; border-radius: 15px; transition: all 0.4s ease; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
        .snap-btn { margin-top: 20px; padding: 10px 25px; background: #000; color: #fff; border: none; border-radius: 20px; cursor: pointer; }
        .carousel { margin-top: 40px; font-style: italic; color: #555; height: 30px; }
        .nav-demo { display: inline-block; margin-top: 50px; color: #000; font-weight: bold; text-decoration: none; border-bottom: 2px solid #000; }
    </style>
</head>
<body>

    <h1>TryOnYou</h1>
    
    <div class="mirror-container" onclick="executeSnap()">
        <img id="model-display" src="https://via.placeholder.com/300x500?text=Modele+Initial" alt="Miroir TryOnYou">
        <p>✨ Cliquez pour le "Snap" de Pau</p>
    </div>

    <div class="carousel" id="claim-text">
        Recommandation personnalisée sans mesures inconfortables.
    </div>

    <a href="demo.html" class="nav-demo">Aller vers la Démo de Scan →</a>

    <script>
        const claims = [
            "L'élasticité et le tombé analysés en temps réel.",
            "Zéro chiffres, zéro tailles, juste votre coupe parfaite.",
            "Intégré avec les collections Galeries Lafayette."
        ];
        let currentClaim = 0;

        function executeSnap() {
            const img = document.getElementById('model-display');
            img.style.transform = "scale(0.95)";
            img.style.filter = "brightness(1.5) blur(5px)";
            
            setTimeout(() => {
                // Ici, on simule le changement de modèle dans le miroir
                img.src = "https://via.placeholder.com/300x500?text=Modele+Transforme";
                img.style.transform = "scale(1)";
                img.style.filter = "none";
            }, 300);
        }

        // Cycle des claims
        setInterval(() => {
            currentClaim = (currentClaim + 1) % claims.length;
            document.getElementById('claim-text').innerText = claims[currentClaim];
        }, 3000);
    </script>
</body>
</html>
EOF

chmod +x assets/js/config.js
echo "✅ index.html créé avec l'expérience 'Snap' et le carrousel."
echo "✅ Integration complete. Web structure ready for the pilot."
