import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Questionnaire } from './components/Questionnaire';
import { BiometricCapture } from './components/BiometricCapture';
import { ShopPAU } from './components/ShopPAU';
import { MockupViewer } from './components/MockupViewer';
import { BiometricCheckout } from './components/BiometricCheckout';
import { RetailMirror } from './components/RetailMirror';
import { SmartCloset } from './components/SmartCloset';
import { LiveStylist } from './components/LiveStylist';
import { VirtualTryOn } from './components/VirtualTryOn';
import { VeoStudio } from './components/VeoStudio';
import { AdminDashboard } from './components/AdminDashboard';
import { TextileLab } from './components/TextileLab';
import { TrendTracker } from './components/TrendTracker';
import { registerInCloset } from './services/smartCloset';
import { syncToGoogleStudio, sendToGoogleStudio } from './services/googleStudioService';
import { AppState, UserProfile, DetailedProduct, Product } from './types';
import { ShieldCheck, ArrowRight, Monitor, Zap, Globe, Film, Database, TrendingUp, FlaskConical } from 'lucide-react';

function App() {
  const [appState, setAppState] = useState<AppState>('landing');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [look, setLook] = useState(1);
  const [isSyncing, setIsSyncing] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [userProfile, setUserProfile] = useState<Partial<UserProfile>>({
    name: 'Stakeholder Demo',
    email: 'pilot@tryonyou.app',
    avbetBalance: 250,
    biometrics: { avatarPhotos: [], voicePrint: false, irisScan: false }
  });

  const [checkoutSuccess, setCheckoutSuccess] = useState(false);

  const handleCheckoutSuccess = () => setCheckoutSuccess(true);

  const handleBiometricComplete = async (result: any) => {
    setIsSyncing(true);
    
    try {
      sendToGoogleStudio(result);
      await syncToGoogleStudio(result);
    } catch (e) {
      console.warn("Studio Sync non-critical failure:", e);
    }
    
    setUserProfile(prev => ({
      ...prev,
      biometrics: {
        ...prev.biometrics!,
        measurements: {
          chest: result.shoulder_cm,
          shoulders: result.shoulder_cm,
          waist: result.waist_cm,
          hips: result.hip_cm
        },
        rawResults: result,
        irisScan: true,
        voicePrint: true
      },
      height: result.height_cm
    }));

    setIsSyncing(false);
    setAppState('shop_pau');
  };

  const handleRetailPurchase = (product: DetailedProduct) => {
    registerInCloset('pilot@tryonyou.app', {
      sku: product.sku,
      mockupId: 'MIRROR-VTO',
      orderId: `RET-${Date.now()}`,
      productDetails: product
    });
    setAppState('smart_closet');
  };

  const handleTryOn = (product: Product) => {
    setSelectedProduct(product);
    setAppState('vto_preview');
  };

  const cycleLook = () => {
    setLook((prev) => (prev % 3) + 1);
  };

  const renderContent = () => {
    switch (appState) {
      case 'landing':
        return (
          <div className="flex-1 flex flex-col animate-in fade-in duration-1000">
            <div className="text-center space-y-20 pt-10">
              <div className="space-y-8">
                <div className="inline-flex items-center gap-3 bg-gold/10 border border-gold/20 px-6 py-2 rounded-full text-gold">
                   <ShieldCheck size={14} />
                   <p className="font-black tracking-[0.4em] text-[9px] uppercase italic">TRYONME × ABVETOS SYSTEM</p>
                </div>
                
                <h1 className="text-6xl md:text-[8rem] font-black tracking-tighter leading-[0.85] uppercase italic">
                  ULTRA PLUS<br/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-gold to-white">ULTIMATUM.</span>
                </h1>
                
                <p className="text-slate-400 text-xl md:text-2xl max-w-3xl mx-auto font-medium leading-relaxed">
                  LVT Engineering v2.5.2. <br/>ABVETOS Intelligence System: Neural fashion at scale.
                </p>
              </div>

              <div className="flex flex-col md:flex-row justify-center items-center gap-8">
                <button 
                  onClick={() => setAppState('questionnaire')}
                  className="bg-white text-black hover:bg-gold px-16 py-8 rounded-full font-black text-2xl transition-all shadow-[0_0_60px_rgba(197,160,89,0.2)] uppercase italic tracking-tighter active:scale-95 flex items-center gap-4 group"
                >
                  Probador Virtual <ArrowRight className="group-hover:translate-x-2 transition-transform" />
                </button>
                
                <button 
                  onClick={() => setAppState('textile_lab')}
                  className="bg-transparent border-2 border-white/10 hover:border-gold text-white px-10 py-8 rounded-full font-black text-xl transition-all uppercase tracking-widest flex items-center gap-3"
                >
                  <FlaskConical size={24} /> TEXTILE LAB
                </button>
              </div>

              <div className="grid md:grid-cols-3 gap-10 py-20 border-t border-white/5">
                <div 
                  onClick={() => setAppState('textile_lab')}
                  className="group relative cursor-pointer text-center bg-white/5 rounded-[3rem] p-12 hover:bg-white/10 transition-all border border-white/5"
                >
                   <div className="p-4 bg-gold/10 rounded-2xl text-gold w-max mx-auto mb-6">
                      <FlaskConical size={32} />
                   </div>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter mb-2">Textile Lab</h3>
                  <p className="text-slate-500 text-sm font-medium uppercase tracking-widest">Fiber Integrity Study.</p>
                </div>

                <div 
                  onClick={() => setAppState('trend_tracker')}
                  className="group relative cursor-pointer text-center bg-white/5 rounded-[3rem] p-12 hover:bg-white/10 transition-all border border-white/5"
                >
                   <div className="p-4 bg-blue-500/10 rounded-2xl text-blue-400 w-max mx-auto mb-6">
                      <TrendingUp size={32} />
                   </div>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter mb-2">Trend Tracker</h3>
                  <p className="text-slate-500 text-sm font-medium uppercase tracking-widest">FGT Top-20 Insights.</p>
                </div>

                <div 
                  onClick={() => setAppState('veo_studio')}
                  className="group relative cursor-pointer text-center bg-white/5 rounded-[3rem] p-12 hover:bg-white/10 transition-all border border-white/5"
                >
                   <div className="p-4 bg-rose-500/10 rounded-2xl text-rose-400 w-max mx-auto mb-6">
                      <Film size={32} />
                   </div>
                  <h3 className="text-xl font-black uppercase italic tracking-tighter mb-2">Veo Studio</h3>
                  <p className="text-slate-500 text-sm font-medium uppercase tracking-widest">Cinematic Transitions.</p>
                </div>
              </div>
            </div>
          </div>
        );
      case 'textile_lab':
        return <TextileLab />;
      case 'trend_tracker':
        return <TrendTracker />;
      case 'vto_preview':
        return selectedProduct ? (
          <VirtualTryOn 
            product={selectedProduct} 
            userProfile={userProfile} 
            onClose={() => setAppState('shop_pau')} 
            onProceedToCheckout={() => setAppState('checkout_avbet')} 
          />
        ) : null;
      case 'veo_studio':
        return <VeoStudio onClose={() => setAppState('landing')} />;
      case 'live_stylist':
        return <LiveStylist onClose={() => setAppState('landing')} />;
      case 'questionnaire':
        return (
          <Questionnaire onComplete={(data) => {
            setUserProfile(prev => ({...prev, ...data}));
            setAppState('biometrics');
          }} />
        );
      case 'biometrics':
        return (
          <BiometricCapture 
            onComplete={handleBiometricComplete} 
            onClose={() => setAppState('landing')}
          />
        );
      case 'shop_pau':
        return (
          <ShopPAU 
            onNext={() => setAppState('fgt_mockups')} 
            onTryOn={handleTryOn} 
            userProfile={userProfile} 
          />
        );
      case 'fgt_mockups':
        return <MockupViewer onSelect={() => setAppState('checkout_avbet')} />;
      case 'checkout_avbet':
        return checkoutSuccess ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center animate-in zoom-in-95">
             <div className="w-32 h-32 bg-gold/10 rounded-full flex items-center justify-center text-gold mb-12 shadow-[0_0_80px_rgba(197,160,89,0.2)] border border-gold/20">
               <Zap size={64} />
             </div>
             <h2 className="text-6xl font-black text-white mb-6 tracking-tighter uppercase italic">Biometric Sync Success</h2>
             <button 
               onClick={() => { setCheckoutSuccess(false); setAppState('smart_closet'); }}
               className="bg-gold text-black px-16 py-6 rounded-full font-black uppercase text-lg tracking-widest hover:bg-white transition-all shadow-2xl"
             >
               VIEW CLOSET →
             </button>
           </div>
        ) : <BiometricCheckout onSuccess={handleCheckoutSuccess} />;
      case 'smart_closet':
        return <SmartCloset userProfile={userProfile} />;
      case 'retail_kiosk':
        return <RetailMirror onExit={() => setAppState('landing')} onBuy={handleRetailPurchase} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-anthracite font-sans text-white selection:bg-gold selection:text-black">
      <Navbar currentState={appState} onNavigate={setAppState} />

      <div className="fixed top-24 left-1/2 -translate-x-1/2 z-40 hidden md:block">
         <div className="bg-black/60 backdrop-blur-2xl border border-white/5 px-6 py-2 rounded-full flex items-center gap-4 shadow-2xl">
           <div className="flex items-center gap-2">
             <div className="w-2 h-2 bg-[#00ff88] rounded-full animate-pulse shadow-[0_0_10px_#00ff88]"></div>
             <span className="text-[9px] font-black uppercase tracking-[0.3em] text-[#00ff88]">SYSTEM ORIGIN: LVT-ENG</span>
           </div>
           <div className="h-3 w-px bg-white/10"></div>
           <span className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.2em]">PATENT: PCT/EP2025/067317</span>
         </div>
      </div>

      <main className={`${['retail_kiosk', 'live_stylist', 'vto_preview', 'veo_studio'].includes(appState) ? '' : 'pt-32 pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto'} min-h-[calc(100vh-64px)] flex flex-col`}>
        {renderContent()}
      </main>

      {showAdmin && <AdminDashboard onClose={() => setShowAdmin(false)} />}

      {isSyncing && (
        <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-2xl flex flex-col items-center justify-center text-center p-10 animate-in fade-in duration-500">
           <div className="relative w-24 h-24 mb-10">
              <div className="absolute inset-0 border-4 border-gold/20 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-gold rounded-full border-t-transparent animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                 <Globe size={40} className="text-gold animate-pulse" />
              </div>
           </div>
           <h3 className="text-3xl font-black uppercase tracking-tighter text-white mb-4 italic">Looker Studio Sync</h3>
           <p className="text-gold font-black uppercase tracking-[0.4em] text-[10px] mb-8 italic">SYNCHRONIZING WITH HUB71 NODE...</p>
        </div>
      )}

      {appState === 'landing' && (
        <footer className="py-20 bg-[#050505] border-t border-white/5">
           <div className="max-w-7xl mx-auto px-10 flex flex-col md:flex-row justify-between items-center gap-10">
              <div className="text-left">
                <h2 className="text-3xl font-black tracking-tighter uppercase italic mb-2">TryOnMe Intelligence</h2>
                <p className="text-slate-600 text-[10px] uppercase tracking-[0.4em] font-medium">Lafayette Engineering Lab © 2025</p>
              </div>
              <div className="flex items-center gap-6">
                 <button onClick={() => setShowAdmin(true)} className="text-slate-500 hover:text-gold transition-colors text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
                   <Database size={14} /> Stakeholder Console
                 </button>
              </div>
           </div>
        </footer>
      )}
    </div>
  );
}

export default App;