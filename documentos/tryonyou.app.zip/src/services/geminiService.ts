
import { GoogleGenAI, Type } from "@google/genai";
import { RecipeData } from "../types";

// Initialize the client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Biometric Extraction (The "Patented" Step)
 * Analyzes body proportions using a known scalar reference (A4 paper).
 */
export const analyzeBiometrics = async (base64Image: string) => {
  if (!navigator.onLine) {
    throw new Error("OFFLINE: Neural link requires an active network connection.");
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview', 
      contents: {
          parts: [
            { inlineData: { data: base64Image, mimeType: 'image/png' } },
            { 
              text: "Référence d'échelle : l'utilisateur tient une feuille A4 (21x29.7cm) verticalement contre sa poitrine. " +
                    "Analysez la morphologie corporelle. Calculez les mesures en cm. " +
                    "Retournez un objet JSON avec : shoulder_cm (nombre), waist_cm (nombre), hip_cm (nombre), height_cm (nombre), posture_analysis (chaîne de caractères, brève classification)." 
            }
          ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            shoulder_cm: { type: Type.NUMBER },
            waist_cm: { type: Type.NUMBER },
            hip_cm: { type: Type.NUMBER },
            height_cm: { type: Type.NUMBER },
            posture_analysis: { type: Type.STRING }
          },
          required: ["shoulder_cm", "waist_cm", "hip_cm", "height_cm", "posture_analysis"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("CALIBRATION_FAILED: Aucune donnée biométrique n'a pu être extraite de l'image.");
    
    return JSON.parse(text);
  } catch (error: any) {
    console.error("L'analyse biométrique a échoué :", error);
    if (error.message?.includes('API_KEY')) {
      throw new Error("ERREUR D'AUTH : L'authentification sécurisée a échoué. Identifiants système invalides.");
    }
    if (error.message?.includes('fetch') || error.message?.includes('network')) {
      throw new Error("DÉLAI D'ATTENTE RÉSEAU : Synchronisation neurale interrompue par des problèmes de connectivité.");
    }
    throw error;
  }
};

// Removed deprecated Schema type reference and used plain object for the schema.
const recipeResponseSchema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "Creative name of the dish" },
    description: { type: Type.STRING, description: "A short, appetizing description (max 2 sentences)" },
    cookingTime: { type: Type.STRING, description: "Total time e.g., '45 mins'" },
    difficulty: { type: Type.STRING, enum: ["Easy", "Medium", "Hard"] },
    calories: { type: Type.NUMBER, description: "Approximate calories per serving" },
    cuisine: { type: Type.STRING, description: "Type of cuisine e.g., Italian, Mexican" },
    ingredients: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of ingredients with quantities"
    },
    instructions: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Step by step cooking instructions"
    },
    nutrition: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, enum: ["Protein", "Carbs", "Fat"] },
          value: { type: Type.NUMBER, description: "Amount in grams" },
          unit: { type: Type.STRING, enum: ["g"] },
          fill: { type: Type.STRING, description: "Hex color code for chart (Protein: #8884d8, Carbs: #82ca9d, Fat: #ffc658)" }
        },
        required: ["name", "value", "unit", "fill"]
      }
    }
  },
  required: ["title", "description", "cookingTime", "difficulty", "calories", "ingredients", "instructions", "nutrition", "cuisine"]
};

export async function generateRecipe(prompt: string, imageBase64?: string): Promise<RecipeData> {
  const model = "gemini-3-flash-preview"; 

  let contents: any = prompt;

  if (imageBase64) {
    contents = {
      parts: [
        {
          inlineData: {
            mimeType: "image/jpeg", 
            data: imageBase64
          }
        },
        {
          text: `Identify the food items or dish in this image. Based on that, generate a detailed recipe. User extra context: ${prompt}`
        }
      ]
    };
  } else {
    contents = `Generate a creative recipe based on these ingredients or request: ${prompt}`;
  }

  const response = await ai.models.generateContent({
    model: model,
    contents: contents,
    config: {
      responseMimeType: "application/json",
      responseSchema: recipeResponseSchema,
      systemInstruction: "You are a world-class Michelin star chef. Create recipes that are accurate, delicious, and easy to follow. Ensure nutrition data is realistic.",
      temperature: 0.7
    }
  });

  if (!response.text) {
    throw new Error("No recipe generated");
  }

  return JSON.parse(response.text) as RecipeData;
}

export async function generateRecipeImage(description: string): Promise<string> {
  const response = await ai.models.generateImages({
    model: 'imagen-4.0-generate-001',
    prompt: `Professional food photography of ${description}, overhead shot, studio lighting, 8k resolution, highly detailed, appetizing presentation, garnish`,
    config: {
      numberOfImages: 1,
      aspectRatio: '16:9',
      outputMimeType: 'image/jpeg'
    }
  });

  if (!response.generatedImages || response.generatedImages.length === 0) {
    throw new Error("Failed to generate image");
  }

  const base64String = response.generatedImages[0].image.imageBytes;
  return `data:image/jpeg;base64,${base64String}`;
}

/**
 * Virtual Try-On Image Generation
 */
export async function generateVirtualTryOn(
  garmentDescription: string, 
  biometricContext: { 
    height_cm: number, 
    waist_cm: number, 
    hip_cm: number, 
    shoulder_cm: number 
  }
): Promise<string> {
  const biometricStr = `${biometricContext.height_cm}cm height, ${biometricContext.shoulder_cm}cm shoulders, ${biometricContext.waist_cm}cm waist, and ${biometricContext.hip_cm}cm hips`;
  
  const response = await ai.models.generateImages({
    model: 'imagen-4.0-generate-001',
    prompt: `A high-end, photorealistic mirror selfie in a luxury fitting room. A person with exact biometric proportions of ${biometricStr} is wearing: ${garmentDescription}. The fabric drapes realistically according to these body measurements. Professional fashion photography, fitting room mirror reflection, cinematic lighting, 8k resolution, highly detailed textile texture, perfect fit.`,
    config: {
      numberOfImages: 1,
      aspectRatio: '9:16', 
      outputMimeType: 'image/jpeg'
    }
  });

  if (!response.generatedImages || response.generatedImages.length === 0) {
    throw new Error("Failed to generate VTO image");
  }

  const base64String = response.generatedImages[0].image.imageBytes;
  return `data:image/jpeg;base64,${base64String}`;
}
