import React, { useState, useEffect, useRef } from 'react';
import { ShieldCheck, AlertCircle, X, CheckCircle2, Scan, RefreshCw, CameraOff, WifiOff, HelpCircle, ArrowLeft } from 'lucide-react';
import { analyzeBiometrics } from '../services/geminiService';

interface Props {
  onComplete: (data: any) => void;
  onClose?: () => void;
}

type ErrorType = 'permission' | 'network' | 'calibration' | 'unknown';

interface AppError {
  message: string;
  type: ErrorType;
  title: string;
  advice: string;
}

export const BiometricCapture: React.FC<Props> = ({ onComplete, onClose }) => {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [error, setError] = useState<AppError | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [showHelp, setShowHelp] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
      setIsCameraActive(true);
    } catch (err: any) {
      setError({
        type: 'permission',
        title: "Camera Access Required",
        message: "We couldn't link to your camera device.",
        advice: "The Neural Mirror uses your camera to measure body proportions. Please click the camera icon in your browser's address bar to allow access and then reload."
      });
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  const handleCapture = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    setIsAnalyzing(true);
    setError(null);
    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.drawImage(video, 0, 0);
    const base64Data = canvas.toDataURL('image/png', 0.8).split(',')[1];
    
    try {
      const data = await analyzeBiometrics(base64Data);
      if (data) {
        setResults(data);
      } else {
        setError({
          type: 'calibration',
          title: "Calibration Mismatch",
          message: "The Neural Link couldn't detect your measurements accurately.",
          advice: "Ensure you are holding an A4 paper (vertical) against your chest. Check that your lighting is bright and your full upper body is in the frame."
        });
      }
    } catch (err: any) {
      const msg = err.message || "";
      if (msg.includes('NETWORK') || msg.includes('OFFLINE') || msg.includes('fetch')) {
        setError({ 
          type: 'network', 
          title: "Connectivity Lost",
          message: "Sync interrupted by network issues.",
          advice: "Please check your internet connection. Neural calibration requires a stable uplink to the Lafayette Cluster."
        });
      } else {
        setError({
          type: 'unknown',
          title: "Neural Handshake Error",
          message: msg || "An unexpected error occurred.",
          advice: "The system might be experiencing high load. Please try again in a few moments."
        });
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#020617] flex flex-col items-center justify-center p-4 font-sans overflow-hidden">
      {/* HUD Header */}
      <div className="w-full max-w-5xl flex justify-between items-center mb-8 px-4 z-50">
        <div className="flex items-center gap-4 text-white">
          <div className="bg-[#c5a059] p-2 rounded-xl text-black">
             <ShieldCheck size={20} />
          </div>
          <div>
            <h2 className="header-font font-black text-2xl tracking-tighter uppercase leading-none">Neural Mirror Capture</h2>
            <p className="text-[#c5a059] font-bold uppercase tracking-[0.3em] text-[10px] mt-1 italic">Ultimatum Protocol Active</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowHelp(!showHelp)}
            className="p-3 bg-white/5 hover:bg-white/10 rounded-full text-slate-400 transition-colors border border-white/10"
            title="Help & Tips"
          >
            <HelpCircle size={24} />
          </button>
          <button onClick={onClose} className="p-3 bg-white/5 hover:bg-rose-500/20 rounded-full text-white transition-colors border border-white/10">
            <X size={24} />
          </button>
        </div>
      </div>

      <div className="relative w-full max-w-5xl aspect-video bg-black rounded-[3rem] overflow-hidden border-4 border-white/5 shadow-[0_0_100px_rgba(197,160,89,0.1)]">
        {showHelp && (
          <div className="absolute inset-0 z-[60] bg-[#020617]/95 backdrop-blur-xl p-12 flex flex-col items-center justify-center text-center animate-in fade-in zoom-in duration-300">
             <div className="max-w-2xl space-y-8">
                <h3 className="text-3xl font-black uppercase tracking-tighter italic text-[#c5a059]">Calibration Protocol</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                   <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                      <div className="w-10 h-10 bg-[#c5a059]/20 rounded-full flex items-center justify-center text-[#c5a059] mx-auto mb-4 font-black">1</div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Hold A4 Paper</p>
                      <p className="text-xs text-white">Hold an A4 paper (vertical) flat against your chest center.</p>
                   </div>
                   <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                      <div className="w-10 h-10 bg-[#c5a059]/20 rounded-full flex items-center justify-center text-[#c5a059] mx-auto mb-4 font-black">2</div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Stand 1.5m Away</p>
                      <p className="text-xs text-white">Ensure your head and waist are visible in the frame.</p>
                   </div>
                   <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                      <div className="w-10 h-10 bg-[#c5a059]/20 rounded-full flex items-center justify-center text-[#c5a059] mx-auto mb-4 font-black">3</div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Bright Lighting</p>
                      <p className="text-xs text-white">Avoid backlighting. Face a strong, soft light source.</p>
                   </div>
                </div>
                <button 
                  onClick={() => setShowHelp(false)}
                  className="bg-white text-black px-12 py-4 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-[#c5a059] transition-all shadow-xl"
                >
                  I'm Ready
                </button>
             </div>
          </div>
        )}

        {!isCameraActive && !error ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/50 backdrop-blur-3xl text-white p-12 z-10">
            <button onClick={startCamera} className="bg-white text-slate-950 px-12 py-6 rounded-2xl font-black text-xl hover:bg-[#c5a059] transition-all shadow-2xl uppercase tracking-tighter">
              Activate Neural Mirror
            </button>
            <p className="mt-6 text-[10px] text-slate-500 font-black uppercase tracking-[0.4em]">Biometric Auth Required</p>
          </div>
        ) : error ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-rose-950/90 backdrop-blur-3xl text-white p-12 z-[70] animate-in fade-in zoom-in duration-500">
             <div className="max-w-md text-center space-y-6">
                <div className="w-20 h-20 bg-rose-500/20 rounded-full flex items-center justify-center text-rose-500 mx-auto border border-rose-500/30">
                   {error.type === 'permission' ? <CameraOff size={32} /> : 
                    error.type === 'network' ? <WifiOff size={32} /> : 
                    <AlertCircle size={32} />}
                </div>
                <div className="space-y-2">
                   <h3 className="text-3xl font-black uppercase tracking-tighter italic">{error.title}</h3>
                   <p className="text-rose-200 font-bold text-sm tracking-tight">{error.message}</p>
                </div>
                <div className="bg-black/40 p-6 rounded-3xl border border-white/5">
                   <p className="text-xs text-slate-400 leading-relaxed italic">
                     {error.advice}
                   </p>
                </div>
                <div className="flex gap-4 justify-center pt-4">
                   <button 
                    onClick={error.type === 'permission' ? () => window.location.reload() : startCamera} 
                    className="flex-1 bg-white text-black px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-rose-500 hover:text-white transition-all shadow-xl"
                   >
                     {error.type === 'permission' ? 'Reload System' : 'Retry Handshake'}
                   </button>
                   <button 
                    onClick={() => { setError(null); setIsCameraActive(false); }}
                    className="flex-1 bg-white/5 border border-white/10 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-white/10 transition-all"
                   >
                     Back
                   </button>
                </div>
             </div>
          </div>
        ) : (
          <div className="relative w-full h-full bg-slate-950 overflow-hidden">
            <video ref={videoRef} autoPlay playsInline muted className={`absolute inset-0 w-full h-full object-cover scale-x-[-1] grayscale transition-opacity duration-1000 ${isAnalyzing ? 'opacity-20' : 'opacity-40'}`} />
            <canvas ref={canvasRef} className="hidden" />
            
            {!results && !isAnalyzing && (
              <div className="absolute inset-0 pointer-events-none z-20">
                <div className="absolute top-8 left-8 flex flex-col gap-1 opacity-40">
                  <span className="text-[5px] text-white font-mono tracking-[0.3em] uppercase">Session_ID: 8D34-0FE5-BD2F</span>
                  <span className="text-[5px] text-white font-mono tracking-[0.3em] uppercase">Encryption: AES_256_ACTIVE</span>
                </div>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="w-44 h-60 border-[0.5px] border-dashed border-[#00ff00]/20 rounded-[50%] mb-12"></div>
                </div>
                <div className="absolute bottom-8 right-8 w-16 h-24 border-[0.5px] border-[#e65a5a]/30 rounded flex items-center justify-center bg-[#e65a5a]/5 backdrop-blur-sm">
                  <span className="text-[4px] text-white/40 font-black uppercase tracking-[0.4em] text-center px-1 leading-tight">
                    REF_A4<br/>SCALE_1:1
                  </span>
                </div>
                
                {/* 1PX LASER SCANNER */}
                <div className="absolute left-0 right-0 h-[1px] bg-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.8)] z-30 animate-scan"></div>
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-rose-500/5 to-transparent h-1/2 w-full animate-scan opacity-30"></div>
                
                <div className="absolute bottom-10 left-0 right-0 flex flex-col items-center">
                  <div className="w-[0.5px] h-4 bg-amber-500/50 animate-pulse"></div>
                  <p className="text-[5px] font-black text-amber-500/60 tracking-[0.6em] uppercase mt-1">
                    Pau // Waiting_for_Subject
                  </p>
                </div>
              </div>
            )}

            {isAnalyzing && (
              <div className="absolute inset-0 bg-black/95 backdrop-blur-md flex flex-col items-center justify-center text-white z-50">
                <div className="w-5 h-5 border-[1px] border-[#e65a5a]/50 border-t-white rounded-full animate-spin mb-4"></div>
                <h2 className="text-[7px] font-black tracking-[0.6em] text-white/60 uppercase italic">
                  Computing_Biometric_Matrix
                </h2>
                <div className="mt-6 w-24 h-[1px] bg-neutral-900 overflow-hidden">
                  <div className="w-full h-full bg-[#e65a5a] animate-loading-bar"></div>
                </div>
              </div>
            )}

            {results && (
              <div className="absolute inset-0 bg-[#fcfaf2] p-8 flex flex-col items-center justify-center animate-in zoom-in-95 duration-500 text-slate-900 z-50 overflow-y-auto">
                <div className="w-full max-w-[400px] flex flex-col items-center">
                  <div className="mb-6 text-center">
                    <p className="text-[8px] font-black tracking-[0.3em] text-slate-400 uppercase">TryOnYou.app</p>
                    <h2 className="text-3xl font-black tracking-tighter text-slate-900 italic mt-1 border-l-4 border-[#e65a5a] pl-3 uppercase">DATA_REPORT_V2.5</h2>
                  </div>

                  <div className="grid grid-cols-2 gap-3 w-full mb-8">
                    {[
                      { label: 'Hombros', value: results.shoulder_cm },
                      { label: 'Cintura', value: results.waist_cm },
                      { label: 'Cadera', value: results.hip_cm },
                      { label: 'Estatura', value: results.height_cm }
                    ].map((item) => (
                      <div key={item.label} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex flex-col items-center text-center">
                        <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mb-1">{item.label}</p>
                        <p className="text-xl font-black text-slate-900">
                          {item.value}{typeof item.value === 'number' ? 'cm' : ''}
                        </p>
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={() => onComplete(results)}
                    className="w-full bg-slate-900 text-white py-4 rounded-full font-black uppercase tracking-widest text-[10px] hover:bg-rose-500 transition-all shadow-xl active:scale-95 flex items-center justify-center gap-3"
                  >
                    Confirm & Proceed <CheckCircle2 size={16} />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="mt-8 flex gap-8 z-50">
        {!results && isCameraActive && !error && !isAnalyzing && (
          <button 
            onClick={handleCapture}
            className="px-16 py-6 bg-rose-500 text-white font-black rounded-full uppercase tracking-widest text-lg shadow-2xl hover:bg-rose-600 transition-all hover:scale-105 active:scale-95 flex items-center gap-3"
          >
            <Scan size={24} /> Run Neural Scan
          </button>
        )}
      </div>

      <style>{`
        @keyframes scan {
          0% { top: 0; opacity: 0; }
          10% { opacity: 1; }
          90% { opacity: 1; }
          100% { top: 100%; opacity: 0; }
        }
        @keyframes loading-bar {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .animate-scan { animation: scan 3s cubic-bezier(0.4, 0, 0.2, 1) infinite; }
        .animate-loading-bar { animation: loading-bar 2s infinite; }
      `}</style>
    </div>
  );
};