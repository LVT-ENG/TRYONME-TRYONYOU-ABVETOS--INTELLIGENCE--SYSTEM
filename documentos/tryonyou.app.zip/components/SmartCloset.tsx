
import React, { useState, useEffect, useMemo } from 'react';
import { 
  RefreshCw, Leaf, Coins, ArrowUpRight, Recycle, 
  Globe, Sparkles, AlertCircle, TrendingUp, CheckCircle,
  Shirt, History, Info, Package
} from 'lucide-react';
import { WardrobeItem, UserProfile } from '../types';
import { getWardrobeItems, donateItem } from '../services/smartCloset';

interface Props {
  userProfile: Partial<UserProfile>;
}

export const SmartCloset: React.FC<Props> = ({ userProfile }) => {
  const [activeTab, setActiveTab] = useState<'collection' | 'autodonate' | 'impact'>('collection');
  const [items, setItems] = useState<WardrobeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [balance, setBalance] = useState(userProfile.avbetBalance || 150);
  const [donatingId, setDonatingId] = useState<string | null>(null);
  const [lastEarned, setLastEarned] = useState<number | null>(null);

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    setLoading(true);
    const data = await getWardrobeItems();
    setItems(data);
    setLoading(false);
  };

  const handleDonate = async (item: WardrobeItem) => {
    if (!window.confirm(`Donate "${item.productName}" for ${item.avbetValue} AVBT credits?`)) return;
    setDonatingId(item.id);
    const result = await donateItem(item.id);
    if (result.success) {
      setLastEarned(result.earnedCredits);
      setBalance(prev => prev + result.earnedCredits);
      setItems(prev => prev.map(i => i.id === item.id ? { ...i, status: 'donated' } : i));
      setTimeout(() => setLastEarned(null), 3000);
    }
    setDonatingId(null);
  };

  const donationSuggestions = useMemo(() => {
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);
    return items.filter(item => {
      if (item.status !== 'active') return false;
      const refDate = new Date(item.lastInteractedDate || item.purchaseDate);
      return refDate < sixMonthsAgo || item.condition === 'worn';
    });
  }, [items]);

  const totalCO2 = items.reduce((acc, curr) => acc + curr.ecoImpact.co2Saved, 0);

  return (
    <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in duration-700 pb-20">
      
      {/* Ecosystem Header */}
      <div className="bg-slate-900 rounded-[3.5rem] p-12 md:p-16 text-white relative overflow-hidden shadow-2xl border border-white/5">
        <Globe className="absolute -right-32 -top-32 w-[30rem] h-[30rem] text-rose-500/10 opacity-20" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-16">
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-6xl font-black mb-6 tracking-tighter leading-none uppercase italic">Circular <br/><span className="text-rose-500 font-light not-italic">Wardrobe.</span></h1>
            <div className="flex items-center gap-6 justify-center md:justify-start">
               <div className="flex items-center gap-2 bg-rose-500/10 border border-rose-500/20 px-4 py-1.5 rounded-full">
                  <Recycle size={14} className="text-rose-500" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-rose-500">AutoDonate V2.1</span>
               </div>
               <p className="text-slate-400 text-sm font-medium">Tracking {items.length} assets across lifecycle.</p>
            </div>
          </div>
          <div className="bg-slate-800 border border-white/5 p-10 rounded-[3rem] text-center w-64 shadow-2xl relative group">
             <div className="absolute inset-0 bg-gradient-to-br from-rose-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
             {lastEarned !== null && <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-green-500 text-white px-4 py-1 rounded-full text-[10px] font-black animate-bounce">+{lastEarned} AVBT</div>}
             <p className="text-5xl font-black text-white mb-2 tracking-tighter">{balance}</p>
             <p className="text-[10px] text-rose-400 uppercase font-black tracking-widest">AVBET Liquidity</p>
          </div>
        </div>
      </div>

      {/* Primary Navigation */}
      <div className="flex gap-12 border-b border-white/5 px-8">
        {[
          { id: 'collection', label: 'My Inventory', icon: <Shirt size={18} /> },
          { id: 'autodonate', label: 'AutoDonate Engine', icon: <Recycle size={18} /> },
          { id: 'impact', label: 'Circular Impact', icon: <Leaf size={18} /> }
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)} 
            className={`pb-6 text-sm font-black uppercase transition-all relative flex items-center gap-3 ${activeTab === tab.id ? 'text-white' : 'text-slate-500 hover:text-slate-300'}`}
          >
            {tab.icon}
            {tab.label}
            {activeTab === tab.id && <div className="absolute bottom-0 left-0 w-full h-1 bg-rose-500 rounded-t-full shadow-[0_0_15px_rgba(244,63,94,0.5)]"></div>}
          </button>
        ))}
      </div>

      <div className="mt-12">
        {activeTab === 'collection' && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
            {items.map((item) => (
              <div key={item.id} className="group bg-white/5 rounded-[3rem] overflow-hidden shadow-xl border border-white/5 transition-all duration-500">
                <div className="relative aspect-[3/4] overflow-hidden">
                  <img src={item.image} alt={item.productName} className="w-full h-full object-cover grayscale opacity-60 transition-all duration-1000 group-hover:scale-110 group-hover:grayscale-0 group-hover:opacity-100" />
                  <div className="absolute top-6 left-6">
                    <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border ${item.status === 'active' ? 'bg-black/60 text-white border-white/20' : 'bg-green-500 text-white border-green-400'}`}>
                      {item.status === 'active' ? 'Owned' : 'Recycled'}
                    </span>
                  </div>
                  {item.status === 'active' && (
                    <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center p-12 text-center">
                       <p className="text-slate-400 text-[10px] uppercase font-black tracking-[0.3em] mb-2">Buyback Value</p>
                       <p className="text-6xl font-black text-white mb-10 tracking-tighter">{item.avbetValue} <span className="text-xl font-light text-rose-500 italic">AVBT</span></p>
                       <button onClick={() => handleDonate(item)} className="w-full py-5 bg-white text-slate-950 rounded-2xl font-black text-lg hover:bg-rose-600 hover:text-white transition-all shadow-2xl">
                         Process Donation
                       </button>
                    </div>
                  )}
                </div>
                <div className="p-10 space-y-4">
                  <h3 className="font-black text-xl text-white uppercase tracking-tighter truncate">{item.productName}</h3>
                  <div className="flex justify-between items-center text-[10px] text-slate-500 font-bold uppercase tracking-widest">
                     <span className="flex items-center gap-2"><History size={12}/> {item.purchaseDate}</span>
                     <span className="text-gold">Lafayette Verified</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'autodonate' && (
          <div className="space-y-12 animate-in slide-in-from-bottom-6">
             <div className="bg-rose-500/5 border border-rose-500/20 p-12 rounded-[4rem] flex flex-col md:flex-row items-center justify-between gap-12">
                <div className="max-w-xl space-y-6">
                   <div className="w-16 h-16 bg-rose-500/10 rounded-[2rem] flex items-center justify-center text-rose-500">
                      <TrendingUp size={32} />
                   </div>
                   <h2 className="text-4xl font-black uppercase italic tracking-tighter text-white leading-none">Smart Recirculation</h2>
                   <p className="text-slate-400 font-medium text-lg leading-relaxed">
                      Our PAU Engine has identified <span className="text-white font-black">{donationSuggestions.length} assets</span> that are eligible for the circular loop. 
                      Donate now to receive immediate AVBT credits and reduce your carbon footprint.
                   </p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                   <div className="bg-black/40 p-8 rounded-[2.5rem] border border-white/5 text-center">
                      <p className="text-3xl font-black text-white mb-1">{donationSuggestions.length}</p>
                      <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Target Assets</p>
                   </div>
                   <div className="bg-black/40 p-8 rounded-[2.5rem] border border-white/5 text-center">
                      <p className="text-3xl font-black text-rose-500 mb-1">{donationSuggestions.reduce((a, b) => a + b.avbetValue, 0)}</p>
                      <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Total Value</p>
                   </div>
                </div>
             </div>

             <div className="grid md:grid-cols-2 gap-8">
                {donationSuggestions.map(item => (
                  <div key={item.id} className="bg-white/5 border border-white/10 p-8 rounded-[3rem] flex items-center gap-8 group">
                     <div className="w-32 h-40 rounded-[2rem] overflow-hidden shrink-0">
                        <img src={item.image} className="w-full h-full object-cover" alt="" />
                     </div>
                     <div className="flex-1 space-y-4">
                        <div>
                           <p className="text-rose-500 text-[10px] font-black uppercase tracking-widest mb-1 flex items-center gap-2">
                             <AlertCircle size={12} /> Low Usage Detected
                           </p>
                           <h4 className="text-xl font-black text-white uppercase tracking-tighter">{item.productName}</h4>
                        </div>
                        <div className="flex justify-between items-end">
                           <div className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">
                              Value: <span className="text-white">{item.avbetValue} AVBT</span>
                           </div>
                           <button 
                            onClick={() => handleDonate(item)}
                            className="bg-white text-black px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-rose-500 hover:text-white transition-all shadow-xl"
                           >
                              Instant Donate
                           </button>
                        </div>
                     </div>
                  </div>
                ))}
             </div>
          </div>
        )}

        {activeTab === 'impact' && (
          <div className="grid md:grid-cols-3 gap-10 animate-in zoom-in-95 duration-500">
             <div className="md:col-span-2 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 p-12 rounded-[4rem] relative overflow-hidden">
                <Leaf className="absolute -right-20 -bottom-20 w-80 h-80 text-emerald-500/5 rotate-12" />
                <div className="relative z-10 space-y-10">
                   <h2 className="text-5xl font-black text-white uppercase italic tracking-tighter leading-none">Environmental <br/><span className="text-emerald-400">Ledger.</span></h2>
                   <div className="grid grid-cols-2 gap-12">
                      <div className="space-y-2">
                         <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">CO2 Mitigation</p>
                         <p className="text-5xl font-black text-white tracking-tighter">{totalCO2.toFixed(1)} <span className="text-xl font-light text-emerald-500 uppercase">Kg</span></p>
                      </div>
                      <div className="space-y-2">
                         <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Water Preservation</p>
                         <p className="text-5xl font-black text-white tracking-tighter">{(items.reduce((a, b) => a + b.ecoImpact.waterSaved, 0) / 1000).toFixed(1)} <span className="text-xl font-light text-emerald-500 uppercase">KL</span></p>
                      </div>
                   </div>
                   <div className="pt-10 border-t border-white/10 flex items-center gap-4 text-slate-400 text-sm font-medium leading-relaxed">
                      <div className="bg-emerald-500/10 p-3 rounded-2xl text-emerald-400"><CheckCircle size={20} /></div>
                      Your wardrobe is currently <strong className="text-white">42% more sustainable</strong> than the industry benchmark.
                   </div>
                </div>
             </div>

             <div className="bg-slate-900 border border-white/5 p-12 rounded-[4rem] flex flex-col justify-center space-y-8">
                <div className="space-y-4">
                   <div className="p-4 bg-white/5 rounded-3xl border border-white/5 w-max">
                      <Package className="text-gold" size={32} />
                   </div>
                   <h4 className="text-2xl font-black text-white uppercase italic tracking-tighter">Logistics Node</h4>
                   <p className="text-slate-500 text-xs font-medium leading-relaxed">
                      LVT JIT production eliminates excess inventory. When you donate, our reverse logistics network picks up the item within 48 hours.
                   </p>
                </div>
                <button className="w-full bg-white/5 border border-white/10 text-white py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-white hover:text-black transition-all">
                   View Lifecycle Map
                </button>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};
