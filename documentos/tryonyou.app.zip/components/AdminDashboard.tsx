import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ShieldCheck, Activity, Users, TrendingUp, ArrowLeft, Download, Globe, GitBranch, Terminal } from 'lucide-react';

interface Props {
  onClose: () => void;
}

export const AdminDashboard: React.FC<Props> = ({ onClose }) => {
  const chartData = [
    { name: '08:00', scans: 12, conversion: 45 },
    { name: '10:00', scans: 45, conversion: 52 },
    { name: '12:00', scans: 89, conversion: 61 },
    { name: '14:00', scans: 124, conversion: 65 },
    { name: '16:00', scans: 142, conversion: 68 },
    { name: '18:00', scans: 110, conversion: 72 },
    { name: '20:00', scans: 65, conversion: 75 },
  ];

  return (
    <div className="fixed inset-0 z-[150] bg-[#020617] overflow-y-auto font-sans text-[#F5EFE6] pb-20">
      <nav className="sticky top-0 z-50 bg-[#020617]/80 backdrop-blur-xl border-b border-white/5 p-6 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full transition-colors">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-xl font-black tracking-tighter uppercase italic">STAKEHOLDER <span className="text-[#C5A46D]">CONSOLE</span></h1>
            <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">LVT-ENG Architecture // Hub71- UAE</p>
          </div>
        </div>
        <button className="flex items-center gap-2 bg-[#C5A46D] text-black px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-white transition-all">
          <Download size={16} /> EXPORT ANALYTICS
        </button>
      </nav>

      <main className="max-w-7xl mx-auto p-6 md:p-12 space-y-12 animate-in fade-in duration-700">
        <div className="bg-[#C5A46D]/5 border border-[#C5A46D]/20 p-8 rounded-[3rem] flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl">
           <div className="flex items-center gap-6">
              <div className="w-16 h-16 bg-[#C5A46D]/10 rounded-full flex items-center justify-center text-[#C5A46D] animate-pulse">
                 <GitBranch size={32} />
              </div>
              <div>
                 <h2 className="text-2xl font-black uppercase tracking-tighter italic">Origin: ADGM Tech Hub</h2>
                 <p className="text-slate-400 text-sm font-medium">Valuation Target: <span className="font-mono text-[#C5A46D]">€400M</span></p>
              </div>
           </div>
           <div className="bg-black/40 px-8 py-4 rounded-3xl border border-white/5">
              <p className="text-[9px] font-black uppercase text-slate-500 tracking-[0.4em] mb-1">Patent Guard</p>
              <p className="text-sm font-mono text-green-400">RULE_26_COMPLIANT</p>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            { label: 'Neural Scans', value: '1,420', icon: <Users className="text-[#C5A46D]" />, trend: '+UAE Q1' },
            { label: 'Avg. Fit Rate', value: '98.4%', icon: <Activity className="text-rose-500" />, trend: 'Target Met' },
            { label: 'JIT Conversion', value: '65%', icon: <TrendingUp className="text-green-400" />, trend: 'Stable' },
            { label: 'ADGM License', value: 'Hub71', icon: <ShieldCheck className="text-amber-500" />, trend: 'Active' }
          ].map((kpi, i) => (
            <div key={i} className="bg-white/5 border border-white/10 p-8 rounded-[2.5rem] shadow-2xl">
              <div className="flex justify-between items-start mb-6">
                <div className="p-3 bg-white/5 rounded-2xl">{kpi.icon}</div>
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-500">{kpi.trend}</span>
              </div>
              <p className="text-4xl font-black tracking-tighter mb-1">{kpi.value}</p>
              <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{kpi.label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 bg-white/5 border border-white/10 p-10 rounded-[3.5rem] space-y-8">
            <h3 className="text-2xl font-black uppercase tracking-tighter italic">Scalability Metrics</h3>
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                  <YAxis stroke="#64748b" fontSize={10} />
                  <Tooltip contentStyle={{ backgroundColor: '#020617', border: 'none', borderRadius: '12px' }} />
                  <Area type="monotone" dataKey="scans" stroke="#C5A46D" fill="#C5A46D33" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-slate-900 border border-white/5 p-10 rounded-[3.5rem] flex flex-col">
            <h3 className="text-xl font-black uppercase tracking-tighter italic mb-8 flex items-center gap-3">
              <Terminal size={20} className="text-[#C5A46D]" /> Pipeline Logs
            </h3>
            <div className="flex-1 space-y-6 overflow-y-auto pr-4">
               {[
                 { time: '16:42', msg: 'Sync established with Hub71 node' },
                 { time: '16:38', msg: 'Biometric Hash rule 26 updated' },
                 { time: '16:30', msg: 'Google Studio reporting active' },
                 { time: '16:25', msg: 'Iris validation token generated' },
               ].map((log, i) => (
                 <div key={i} className="flex gap-4 items-start border-l-2 border-white/5 pl-4">
                   <div className="shrink-0 text-[10px] font-mono text-slate-500">{log.time}</div>
                   <p className="text-[11px] font-bold uppercase tracking-tight text-[#C5A46D]">{log.msg}</p>
                 </div>
               ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};