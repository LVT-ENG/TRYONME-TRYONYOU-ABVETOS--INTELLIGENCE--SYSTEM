import React, { useState, useRef, useEffect } from 'react';
import { X, Zap, Power, ShieldCheck, Activity, ShoppingBag, Ruler, Scan, Sparkles } from 'lucide-react';
import { GarmentMeasurements, DetailedProduct } from '../types';
import { simulateUserScan, calculatePerfectFit } from '../services/sizingService';
import { INVENTORY_DATABASE } from '../data/inventoryDatabase';

interface Props {
  onExit: () => void;
  onBuy?: (product: DetailedProduct) => void;
}

export const RetailMirror: React.FC<Props> = ({ onExit, onBuy }) => {
  const [index, setIndex] = useState(0);
  const [isCameraStarted, setIsCameraStarted] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [userMetrics, setUserMetrics] = useState<GarmentMeasurements | null>(null);
  const [fitResult, setFitResult] = useState<{size: string, details: string} | null>(null);
  const [sessionID] = useState(() => Math.random().toString(16).slice(2, 10).toUpperCase());
  
  const videoRef = useRef<HTMLVideoElement>(null);

  const startVisionSystem = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: { ideal: 1920 }, height: { ideal: 1080 } } 
      });
      if (videoRef.current) videoRef.current.srcObject = stream;
      setIsCameraStarted(true);
      
      setTimeout(() => {
        const metrics = simulateUserScan();
        setUserMetrics(metrics);
        
        const product = INVENTORY_DATABASE[index];
        if (product) {
          const fit = calculatePerfectFit(metrics, product);
          setFitResult({ size: fit.size, details: fit.matchDetails });
        }
      }, 1500);
    } catch (err) {
      console.warn("Camera fallback active.");
      setIsCameraStarted(true);
      setUserMetrics(simulateUserScan());
    }
  };

  useEffect(() => {
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      }
    };
  }, []);

  const handleNext = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      const nextIdx = (index + 1) % INVENTORY_DATABASE.length;
      setIndex(nextIdx);
      
      if (userMetrics) {
        const product = INVENTORY_DATABASE[nextIdx];
        const fit = calculatePerfectFit(userMetrics, product);
        setFitResult({ size: fit.size, details: fit.matchDetails });
      }
      setIsAnalyzing(false);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-[#020617] flex flex-col items-center justify-center p-6 overflow-hidden font-sans select-none">
      <div className="relative w-[340px] h-[610px] rounded-[3.5rem] overflow-hidden border border-white/10 shadow-[0_0_150px_rgba(0,0,0,0.9)] bg-[#050505] group">
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          muted 
          className={`absolute inset-0 w-full h-full object-cover grayscale-[40%] transition-opacity duration-1000 scale-x-[-1] ${isCameraStarted ? 'opacity-80' : 'opacity-0'}`} 
        />
        <div className={`absolute inset-0 transition-all duration-1000 ease-[cubic-bezier(0.23,1,0.32,1)] ${isAnalyzing ? 'scale-110 blur-3xl opacity-20' : 'scale-100 opacity-30'}`}>
          <img 
            src={INVENTORY_DATABASE[index].image} 
            className="w-full h-full object-cover mix-blend-screen"
            alt="Virtual Layer"
            key={index}
          />
        </div>
        <div className="absolute inset-0 pointer-events-none z-20">
          <div className="absolute top-10 left-10 flex flex-col gap-1 opacity-60">
            <div className="flex items-center gap-2">
               <ShieldCheck size={10} className="text-rose-500" />
               <span className="text-[6px] text-white font-mono tracking-[0.4em] uppercase font-bold">SESSION: {sessionID}</span>
            </div>
            <span className="text-[5px] text-white/40 font-mono tracking-[0.4em] uppercase pl-4">AES_256_ACTIVE</span>
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-52 h-72 border-[0.5px] border-dashed border-[#00ff00]/10 rounded-[50%] mb-12 animate-pulse"></div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-rose-500/30 to-transparent h-[1px] w-full animate-scan"></div>
        </div>

        {fitResult && isCameraStarted && !isAnalyzing && (
          <div className="absolute top-[28%] left-0 right-0 flex flex-col items-center z-30 animate-in fade-in zoom-in duration-1000">
             <div className="bg-black/40 backdrop-blur-2xl px-10 py-5 rounded-[2.5rem] border border-white/10 text-center shadow-2xl">
                <p className="text-[7px] font-black text-rose-500 tracking-[0.5em] uppercase mb-1 flex items-center justify-center gap-2">
                  <Activity size={10} /> NEURAL_FIT_SYCHRONIZED
                </p>
                <p className="text-4xl font-black text-white tracking-tighter uppercase italic leading-none">
                  SIZE {fitResult.size}
                </p>
             </div>
          </div>
        )}

        {fitResult && isCameraStarted && !isAnalyzing && (
          <div className="absolute bottom-16 left-0 right-0 flex justify-center z-40 px-10 pointer-events-auto">
             <button 
              onClick={() => onBuy && onBuy(INVENTORY_DATABASE[index])}
              className="w-full py-4 bg-white text-black font-black text-[11px] rounded-2xl uppercase tracking-[0.4em] hover:bg-rose-600 hover:text-white transition-all shadow-2xl flex items-center justify-center gap-3"
             >
               Confirm Production <Zap size={14} />
             </button>
          </div>
        )}

        {!isCameraStarted && (
          <div className="absolute inset-0 z-50 bg-[#020617] flex flex-col items-center justify-center text-center p-12">
            <Power size={48} className="text-amber-500 animate-pulse mb-10" />
            <h2 className="text-3xl font-black text-white tracking-tighter uppercase mb-3">Neural Mirror</h2>
            <button 
              onClick={startVisionSystem}
              className="bg-white text-slate-950 px-12 py-5 rounded-2xl font-black text-[10px] uppercase tracking-[0.4em] hover:bg-amber-500 transition-all shadow-2xl"
            >
              INITIALIZE_SYNC
            </button>
          </div>
        )}
      </div>

      <div className="mt-16 flex flex-col items-center z-40">
        <button 
          onClick={handleNext}
          disabled={!isCameraStarted || isAnalyzing}
          className="group relative px-20 py-6 border border-white/10 rounded-full bg-black/40 backdrop-blur-2xl transition-all hover:border-white/30 disabled:opacity-20 shadow-2xl"
        >
          <span className="text-[10px] font-black tracking-[0.8em] uppercase text-white/40 group-hover:text-white transition-colors duration-500">
            {isAnalyzing ? "SYNCING..." : "Next_Outfit →"}
          </span>
        </button>
      </div>

      <button onClick={onExit} className="absolute top-10 right-10 p-5 bg-white/5 rounded-full text-white/20 hover:text-rose-500 hover:bg-white/10 transition-all z-50 border border-white/5 backdrop-blur-md">
        <X size={28} />
      </button>

      <style>{`
        @keyframes scan {
          0% { transform: translateY(0); opacity: 0; }
          10%, 90% { opacity: 1; }
          100% { transform: translateY(610px); opacity: 0; }
        }
        .animate-scan { animation: scan 3.5s linear infinite; }
      `}</style>
    </div>
  );
};