import React, { useState } from 'react';
import { ArrowRight, Weight, Ruler, MapPin, Palette, Sparkles, User, MessageSquare, AlertCircle } from 'lucide-react';
import { UserProfile } from '../types';

interface Props {
  onComplete: (data: Partial<UserProfile>) => void;
}

export const Questionnaire: React.FC<Props> = ({ onComplete }) => {
  const [formData, setFormData] = useState({
    city: '',
    weight: '',
    height: '',
    styles: '',
    colors: '',
    gramaje: '180',
    description: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.description.trim()) newErrors.description = "Neural Vision description is required for style calibration.";
    if (!formData.city.trim()) newErrors.city = "City is required for localized trend mapping.";
    
    const weightNum = Number(formData.weight);
    if (!formData.weight || weightNum < 30 || weightNum > 250) {
      newErrors.weight = "Please enter a valid weight (30-250kg).";
    }
    
    const heightNum = Number(formData.height);
    if (!formData.height || heightNum < 100 || heightNum > 250) {
      newErrors.height = "Please enter a valid height (100-250cm).";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    onComplete({
      city: formData.city,
      weight: Number(formData.weight),
      height: Number(formData.height),
      preferences: {
        styles: formData.styles.split(',').map(s => s.trim()).filter(Boolean),
        colors: formData.colors.split(',').map(c => c.trim()).filter(Boolean),
        fabricWeight: Number(formData.gramaje)
      }
    });
  };

  return (
    <div className="max-w-4xl mx-auto animate-in zoom-in-95 duration-700">
      <div className="bg-white rounded-[3.5rem] shadow-2xl border border-slate-100 overflow-hidden">
        <div className="p-12 bg-slate-950 text-white relative overflow-hidden">
          <Sparkles className="absolute -right-10 -top-10 w-48 h-48 text-rose-500/20" />
          <h2 className="text-4xl font-black tracking-tighter uppercase mb-3 flex items-center gap-3">
            <User size={32} className="text-rose-500" /> ABVETOS Intake
          </h2>
          <p className="text-slate-400 font-medium text-lg leading-relaxed">
            “Tell me about your vision. How do you want to feel in your clothes? Let's calibrate your Neural Profile.”
          </p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-12 space-y-10">
          <div className="space-y-4">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] flex items-center gap-2">
              <MessageSquare size={14} className="text-rose-500" /> Neural Vision
            </label>
            <textarea 
              className={`w-full p-6 bg-slate-50 border rounded-3xl focus:ring-2 focus:ring-rose-500 outline-none transition-all text-xl font-medium resize-none ${errors.description ? 'border-rose-500 bg-rose-50' : 'border-slate-100'}`}
              placeholder="E.g., I love avant-garde silhouettes, loose fabrics, and monochromatic tones. I want to feel powerful yet comfortable."
              rows={4}
              value={formData.description}
              onChange={e => {
                setFormData({...formData, description: e.target.value});
                if (errors.description) setErrors(prev => { const n = {...prev}; delete n.description; return n; });
              }}
            />
            {errors.description && <p className="text-rose-600 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1"><AlertCircle size={12}/> {errors.description}</p>}
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <MapPin size={14} /> City
              </label>
              <input 
                className={`w-full p-5 bg-slate-50 border rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all ${errors.city ? 'border-rose-500 bg-rose-50' : 'border-slate-100'}`}
                placeholder="Where do you wear it?"
                value={formData.city}
                onChange={e => {
                  setFormData({...formData, city: e.target.value});
                  if (errors.city) setErrors(prev => { const n = {...prev}; delete n.city; return n; });
                }}
              />
              {errors.city && <p className="text-rose-600 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1"><AlertCircle size={12}/> {errors.city}</p>}
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Weight size={14} /> Weight (kg)
                </label>
                <input 
                  type="number"
                  className={`w-full p-5 bg-slate-50 border rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all ${errors.weight ? 'border-rose-500 bg-rose-50' : 'border-slate-100'}`}
                  value={formData.weight}
                  onChange={e => {
                    setFormData({...formData, weight: e.target.value});
                    if (errors.weight) setErrors(prev => { const n = {...prev}; delete n.weight; return n; });
                  }}
                />
                {errors.weight && <p className="text-rose-600 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1"><AlertCircle size={12}/> {errors.weight}</p>}
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Ruler size={14} /> Height (cm)
                </label>
                <input 
                  type="number"
                  className={`w-full p-5 bg-slate-50 border rounded-2xl focus:ring-2 focus:ring-rose-500 outline-none transition-all ${errors.height ? 'border-rose-500 bg-rose-50' : 'border-slate-100'}`}
                  value={formData.height}
                  onChange={e => {
                    setFormData({...formData, height: e.target.value});
                    if (errors.height) setErrors(prev => { const n = {...prev}; delete n.height; return n; });
                  }}
                />
                {errors.height && <p className="text-rose-600 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1"><AlertCircle size={12}/> {errors.height}</p>}
              </div>
            </div>
          </div>

          <button type="submit" className="w-full py-6 bg-slate-950 text-white rounded-[2rem] font-black text-2xl hover:bg-rose-600 transition-all flex items-center justify-center gap-4 shadow-2xl uppercase tracking-tighter group">
            Proceed to Biometric Calibration <ArrowRight size={24} className="group-hover:translate-x-2 transition-transform" />
          </button>
        </form>
      </div>
    </div>
  );
};