
import React, { useState } from 'react';
import { garments } from '../data/garments';
import { AppState, Mockup } from '../types';
import { ArrowLeft, ArrowRight, ShoppingBag, Wand2, Share2, Check, Box, Image as ImageIcon, Crosshair } from 'lucide-react';

interface Props {
  onSelect: (mockupId: string) => void;
}

const MOCKUPS = [
  { id: 'MK-1', title: 'FGT: Peacock Suit V1', image: '/assets/demo/image_16.jpg', modelUrl: 'https://modelviewer.dev/shared-assets/models/Astronaut.glb', price: 1250 },
  { id: 'MK-2', title: 'FGT: Peacock Suit V2', image: '/assets/demo/image_17.jpg', modelUrl: 'https://modelviewer.dev/shared-assets/models/Astronaut.glb', price: 1250 },
  { id: 'MK-3', title: 'FGT: Peacock Suit V3', image: '/assets/demo/image_18.jpg', modelUrl: 'https://modelviewer.dev/shared-assets/models/Astronaut.glb', price: 1250 },
  { id: 'MK-4', title: 'FGT: Geometric Urban', image: '/assets/demo/image_2.jpg', modelUrl: 'https://modelviewer.dev/shared-assets/models/Astronaut.glb', price: 180 }, 
  { id: 'MK-5', title: 'FGT: Red Abstract', image: '/assets/demo/image_5.jpg', modelUrl: 'https://modelviewer.dev/shared-assets/models/Astronaut.glb', price: 300 },
];

export const MockupViewer: React.FC<Props> = ({ onSelect }) => {
  const [page, setPage] = useState(0);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<Record<string, '2d' | '3d'>>({});
  
  const itemsPerPage = 3;
  const totalPages = Math.ceil(MOCKUPS.length / itemsPerPage);
  const currentMockups = MOCKUPS.slice(page * itemsPerPage, (page + 1) * itemsPerPage);

  const toggleView = (id: string) => {
    setViewMode(prev => ({
      ...prev,
      [id]: prev[id] === '3d' ? '2d' : '3d'
    }));
  };

  const handleShare = async (m: typeof MOCKUPS[0]) => {
    const shareData = {
      title: `TryOnYou | ${m.title}`,
      text: `Descubre este diseño único generado por IA para Lafayette Excellence: ${m.title}. ¡Pieza exclusiva 1 de 1!`,
      url: window.location.href,
    };

    if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        if ((err as Error).name !== 'AbortError') console.error('Error sharing:', err);
      }
    } else {
      // Fallback to clipboard
      try {
        await navigator.clipboard.writeText(`${shareData.text}\n\nVer diseño en: ${shareData.url}`);
        setCopiedId(m.id);
        setTimeout(() => setCopiedId(null), 2000);
      } catch (err) {
        console.error('Failed to copy:', err);
      }
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto space-y-16 animate-in slide-in-from-right-8 duration-700">
      
      <div className="text-center max-w-4xl mx-auto space-y-6">
        <div className="inline-flex items-center gap-2 bg-purple-50 text-purple-600 px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.4em] border border-purple-100">
          <Wand2 size={16} />
          <span>Fashion Generative Tech</span>
        </div>
        <h2 className="text-6xl md:text-[6.5rem] font-black text-slate-950 tracking-tighter leading-none">Generative <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-rose-500 italic">3D Assets.</span></h2>
        <p className="text-slate-500 text-xl font-medium leading-relaxed">
          The ABVETOS engine has compiled these garments into interactive 3D meshes. 
          Inspect the structural integrity and Lafayette silk textures before JIT production.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-12">
        {currentMockups.map((m) => {
          const mode = viewMode[m.id] || '2d';
          return (
            <div 
              key={m.id} 
              className="group bg-white rounded-[3.5rem] shadow-[0_40px_100px_-20px_rgba(0,0,0,0.1)] overflow-hidden border border-slate-100 flex flex-col hover:-translate-y-2 transition-all duration-700"
            >
              {/* Media Container */}
              <div className="flex-1 relative overflow-hidden aspect-[3/4] bg-[#050505]">
                 
                 {/* 2D MODE */}
                 <div className={`absolute inset-0 transition-opacity duration-700 ${mode === '2d' ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}>
                    <img 
                      src={m.image} 
                      alt={m.title} 
                      className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" 
                    />
                 </div>

                 {/* 3D MODE */}
                 <div className={`absolute inset-0 transition-opacity duration-700 ${mode === '3d' ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}>
                    {/* HUD Technical Grid Overlay */}
                    <div className="absolute inset-0 pointer-events-none z-20 opacity-20" style={{
                      backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)',
                      backgroundSize: '20px 20px'
                    }}></div>
                    
                    <div className="absolute top-6 left-6 z-30 opacity-40">
                       <div className="flex items-center gap-2">
                          <Crosshair size={10} className="text-rose-500" />
                          <span className="text-[6px] text-white font-mono tracking-widest uppercase italic">Neural_Mesh_Analysis</span>
                       </div>
                    </div>

                    <model-viewer
                      src={m.modelUrl}
                      alt={m.title}
                      auto-rotate
                      camera-controls
                      shadow-intensity="2.0"
                      shadow-softness="0.5"
                      exposure="1.2"
                      environment-image="neutral"
                      auto-rotate-delay="0"
                      rotation-per-second="30deg"
                      interaction-prompt="auto"
                      touch-action="pan-y"
                    ></model-viewer>
                 </div>

                 {/* Interactive HUD Controls */}
                 <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-8 gap-4 z-40">
                   <button 
                    onClick={() => onSelect(m.id)}
                    className="w-full bg-white text-slate-950 py-5 rounded-2xl font-black text-lg hover:scale-105 transition-all flex items-center justify-center gap-3 shadow-2xl uppercase tracking-tighter"
                   >
                     <ShoppingBag size={20} /> Purchase 1:1 Piece
                   </button>
                   <div className="flex gap-4 w-full">
                     <button 
                      onClick={() => handleShare(m)}
                      className="flex-1 bg-white/10 backdrop-blur-md text-white border border-white/20 py-4 rounded-2xl font-black text-xs hover:bg-white/20 transition-all flex items-center justify-center gap-2 uppercase tracking-tighter"
                     >
                       {copiedId === m.id ? <Check size={16} /> : <Share2 size={16} />}
                       {copiedId === m.id ? 'Copied' : 'Share'}
                     </button>
                     <button 
                      onClick={() => toggleView(m.id)}
                      className={`flex-1 ${mode === '3d' ? 'bg-rose-500 text-white' : 'bg-white/10 backdrop-blur-md text-white border border-white/20'} py-4 rounded-2xl font-black text-xs hover:scale-105 transition-all flex items-center justify-center gap-2 uppercase tracking-tighter`}
                     >
                       {mode === '3d' ? <ImageIcon size={16} /> : <Box size={16} />}
                       {mode === '3d' ? '2D View' : '3D Inspect'}
                     </button>
                   </div>
                 </div>

                 <div className="absolute top-6 left-6 bg-slate-950/60 backdrop-blur-md text-white text-[10px] px-4 py-1.5 rounded-full border border-white/20 font-black uppercase tracking-widest z-30">
                   {mode === '3d' ? '3D Neural Mesh' : 'Standard Edit'}
                 </div>
              </div>
              
              <div className="p-10 bg-white">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-black text-2xl text-slate-950 uppercase tracking-tighter mb-1 leading-none">{m.title}</h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.4em] mt-2 italic">FGT_GEN_ALGO_0.2.5</p>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-black text-rose-600 leading-none mb-1 tracking-tighter">{m.price}€</p>
                    <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">AVBET Secured</p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {totalPages > 1 && (
        <div className="flex justify-center items-center gap-10 mt-16 pb-20">
          <button 
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
            className="p-6 rounded-full border border-slate-200 hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-xl bg-white"
          >
            <ArrowLeft size={32} />
          </button>
          <div className="flex gap-4">
            {Array.from({length: totalPages}).map((_, i) => (              <div key={i} className={`h-1.5 rounded-full transition-all duration-1000 ${page === i ? 'w-16 bg-slate-900 shadow-lg' : 'w-4 bg-slate-200'}`} />
            ))}
          </div>
          <button 
            onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
            disabled={page === totalPages - 1}
            className="p-6 rounded-full border border-slate-200 hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-xl bg-white"
          >
            <ArrowRight size={32} />
          </button>
        </div>
      )}
    </div>
  );
};
