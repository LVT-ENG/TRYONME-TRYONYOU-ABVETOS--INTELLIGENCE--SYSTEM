
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { X, Mic, MicOff, Camera, VideoOff, Volume2, Sparkles, Activity, Cpu } from 'lucide-react';

interface Props {
  onClose: () => void;
}

export const LiveStylist: React.FC<Props> = ({ onClose }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isMicActive, setIsMicActive] = useState(true);
  const [isCameraActive, setIsCameraActive] = useState(true);
  const [inputTranscription, setInputTranscription] = useState("");
  const [outputTranscription, setOutputTranscription] = useState("");
  const [audioLevel, setAudioLevel] = useState(0);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const nextStartTimeRef = useRef<number>(0);

  // Audio Encoding/Decoding Utilities
  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
    return buffer;
  };

  useEffect(() => {
    const initializeLiveSession = async () => {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputCtx;

      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: { facingMode: 'user' } });
        streamRef.current = stream;
        if (videoRef.current) videoRef.current.srcObject = stream;

        const sessionPromise = ai.live.connect({
          model: 'gemini-2.5-flash-native-audio-preview-09-2025',
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
            systemInstruction: "You are Pau, the world-class French fashion stylist for TryOnYou. You are high-fashion, direct, and sophisticated. You can see the user through the camera frames being streamed. Offer real-time style advice, critique their outfit with French elegance, and guide them through the Ultimatum collection. Be brief but impactful.",
            inputAudioTranscription: {},
            outputAudioTranscription: {}
          },
          callbacks: {
            onopen: () => {
              setIsConnected(true);
              // Start Microphone Stream
              const source = inputCtx.createMediaStreamSource(stream);
              const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
              const analyser = inputCtx.createAnalyser();
              analyser.fftSize = 256;
              const dataArray = new Uint8Array(analyser.frequencyBinCount);

              // Fixed: Strictly following rule to rely solely on sessionPromise and not add other condition checks (like isMicActive) inside onaudioprocess.
              scriptProcessor.onaudioprocess = (e) => {
                const inputData = e.inputBuffer.getChannelData(0);
                
                // Audio level visualization
                analyser.getByteFrequencyData(dataArray);
                const avg = dataArray.reduce((a, b) => a + b) / dataArray.length;
                setAudioLevel(avg);

                const int16 = new Int16Array(inputData.length);
                for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
                const pcmBlob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };
                sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
              };
              source.connect(analyser);
              source.connect(scriptProcessor);
              scriptProcessor.connect(inputCtx.destination);

              // Start Video Frame Stream (1 frame per second)
              const interval = setInterval(() => {
                if (!videoRef.current || !canvasRef.current) return;
                const canvas = canvasRef.current;
                const video = videoRef.current;
                canvas.width = 320;
                canvas.height = 240;
                const ctx = canvas.getContext('2d');
                if (ctx) {
                  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                  canvas.toBlob(async (blob) => {
                    if (blob) {
                      const reader = new FileReader();
                      reader.onloadend = () => {
                        const base64Data = (reader.result as string).split(',')[1];
                        sessionPromise.then(s => s.sendRealtimeInput({ media: { data: base64Data, mimeType: 'image/jpeg' } }));
                      };
                      reader.readAsDataURL(blob);
                    }
                  }, 'image/jpeg', 0.5);
                }
              }, 1000);

              return () => clearInterval(interval);
            },
            onmessage: async (msg: LiveServerMessage) => {
              if (msg.serverContent?.inputTranscription) {
                setInputTranscription(msg.serverContent.inputTranscription.text);
              }
              if (msg.serverContent?.outputTranscription) {
                setOutputTranscription(prev => prev + msg.serverContent!.outputTranscription!.text);
              }
              if (msg.serverContent?.turnComplete) {
                setOutputTranscription("");
              }

              const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
              if (audioData) {
                nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
                const buffer = await decodeAudioData(decode(audioData), outputCtx, 24000, 1);
                const source = outputCtx.createBufferSource();
                source.buffer = buffer;
                source.connect(outputCtx.destination);
                source.onended = () => sourcesRef.current.delete(source);
                source.start(nextStartTimeRef.current);
                nextStartTimeRef.current += buffer.duration;
                sourcesRef.current.add(source);
              }

              if (msg.serverContent?.interrupted) {
                sourcesRef.current.forEach(s => s.stop());
                sourcesRef.current.clear();
                nextStartTimeRef.current = 0;
              }
            },
            onclose: () => setIsConnected(false),
            onerror: (e) => console.error("Live Stylist Neural Link Error:", e)
          }
        });

        sessionRef.current = await sessionPromise;
      } catch (err) {
        console.error("Failed to connect to Neural Link:", err);
      }
    };

    initializeLiveSession();

    return () => {
      sessionRef.current?.close();
      streamRef.current?.getTracks().forEach(t => t.stop());
      if (audioContextRef.current) audioContextRef.current.close();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[100] bg-[#050505] flex flex-col items-center justify-center font-sans overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,#c5a059_0%,transparent_70%)] opacity-10 animate-pulse"></div>
      </div>

      {/* Header */}
      <div className="absolute top-10 left-10 right-10 flex justify-between items-center z-50">
        <div className="flex items-center gap-4">
          <div className="bg-[#c5a059] p-3 rounded-2xl shadow-[0_0_20px_rgba(197,160,89,0.4)]">
             <Cpu size={24} className="text-black" />
          </div>
          <div>
            <h2 className="text-2xl font-black uppercase tracking-tighter text-white">Pau Neural Link</h2>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-[#00ff88] animate-pulse shadow-[0_0_10px_#00ff88]' : 'bg-red-500'}`}></div>
              <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500">{isConnected ? 'Session Active' : 'Connecting...'}</span>
            </div>
          </div>
        </div>
        <button onClick={onClose} className="p-4 bg-white/5 border border-white/10 rounded-full text-white hover:bg-rose-500 transition-all">
          <X size={28} />
        </button>
      </div>

      {/* Main Stylist Orb */}
      <div className="relative flex flex-col items-center justify-center gap-12 w-full max-w-4xl px-8">
        
        {/* Transcription Bubbles */}
        <div className="w-full space-y-4 min-h-[120px] flex flex-col justify-end">
           {inputTranscription && (
             <div className="self-end bg-white/5 border border-white/10 px-6 py-3 rounded-[2rem] rounded-tr-sm animate-in slide-in-from-right-4">
               <p className="text-slate-400 text-xs italic">"{inputTranscription}"</p>
             </div>
           )}
           {outputTranscription && (
             <div className="self-start bg-[#c5a059]/10 border border-[#c5a059]/30 px-8 py-4 rounded-[2.5rem] rounded-tl-sm animate-in slide-in-from-left-4">
               <p className="text-[#c5a059] text-xl font-bold tracking-tight leading-relaxed">{outputTranscription}</p>
             </div>
           )}
        </div>

        {/* The Core Orb */}
        <div className="relative group">
           {/* Glow Layers */}
           <div className="absolute inset-0 bg-[#c5a059]/20 rounded-full blur-[120px] animate-pulse"></div>
           <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full border border-white/10 flex items-center justify-center overflow-hidden bg-black shadow-[0_0_100px_rgba(197,160,89,0.1)]">
              {/* Dynamic Waveform Visualizer */}
              <div className="flex items-center gap-1">
                {[...Array(12)].map((_, i) => (
                  <div 
                    key={i} 
                    className="w-1.5 bg-[#c5a059] rounded-full transition-all duration-75"
                    style={{ height: `${20 + (audioLevel * (0.5 + Math.random()))}px` }}
                  ></div>
                ))}
              </div>
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                 <Sparkles size={48} className="text-[#c5a059] opacity-30 animate-spin-slow" />
              </div>
           </div>
           
           {/* Floating HUD info */}
           <div className="absolute -top-10 -right-10 bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10 shadow-2xl">
              <Activity size={16} className="text-[#00ff88] mb-1" />
              <p className="text-[8px] font-black uppercase text-slate-500 tracking-widest">Neural Analysis</p>
              <p className="text-[10px] font-bold text-white">Style Precision: 98.4%</p>
           </div>
        </div>

        {/* User Camera Preview */}
        <div className="relative w-48 h-64 md:w-64 md:h-80 rounded-[2.5rem] overflow-hidden border border-white/10 shadow-2xl group transition-all hover:scale-105">
           <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted 
            className={`w-full h-full object-cover scale-x-[-1] transition-opacity duration-1000 ${isCameraActive ? 'opacity-60 grayscale' : 'opacity-0'}`} 
           />
           {!isCameraActive && (
             <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
               <VideoOff className="text-slate-600" size={32} />
             </div>
           )}
           <div className="absolute inset-0 border-[0.5px] border-white/20 pointer-events-none"></div>
           <canvas ref={canvasRef} className="hidden" />
           <div className="absolute bottom-4 left-4 right-4 bg-black/60 backdrop-blur-md px-4 py-2 rounded-xl border border-white/10">
              <p className="text-[8px] font-black uppercase text-[#c5a059] tracking-widest">Pau's Vision View</p>
           </div>
        </div>
      </div>

      {/* Control Bar */}
      <div className="absolute bottom-16 flex items-center gap-8 bg-white/5 backdrop-blur-2xl px-10 py-6 rounded-[3rem] border border-white/10 shadow-2xl z-50">
        <button 
          onClick={() => setIsMicActive(!isMicActive)}
          className={`p-5 rounded-full transition-all ${isMicActive ? 'bg-white text-black hover:bg-slate-200' : 'bg-rose-500/20 text-rose-500 border border-rose-500/30'}`}
        >
          {isMicActive ? <Mic size={24} /> : <MicOff size={24} />}
        </button>
        <button 
          onClick={() => setIsCameraActive(!isCameraActive)}
          className={`p-5 rounded-full transition-all ${isCameraActive ? 'bg-white text-black hover:bg-slate-200' : 'bg-rose-500/20 text-rose-500 border border-rose-500/30'}`}
        >
          {isCameraActive ? <Camera size={24} /> : <VideoOff size={24} />}
        </button>
        <div className="h-10 w-px bg-white/10"></div>
        <div className="flex flex-col">
          <span className="text-[9px] font-black uppercase text-slate-500 tracking-[0.4em] mb-1">Active Device</span>
          <span className="text-[11px] font-bold text-white flex items-center gap-2"><Volume2 size={12} className="text-[#c5a059]" /> Neural High-Fi</span>
        </div>
      </div>

      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 10s linear infinite;
        }
      `}</style>
    </div>
  );
};
