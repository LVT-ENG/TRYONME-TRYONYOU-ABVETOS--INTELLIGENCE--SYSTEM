import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldCheck, AlertCircle, X, CheckCircle2, Scan, RefreshCw, 
  CameraOff, WifiOff, HelpCircle, Info, Sun, Ruler, 
  FileText, Globe, Activity, Lock, Settings, MousePointer2
} from 'lucide-react';
import { analyzeBiometrics } from '../services/geminiService';

interface Props {
  onComplete: (data: any) => void;
  onClose?: () => void;
}

type ErrorType = 'permission' | 'network' | 'calibration' | 'unknown';

interface AppError {
  message: string;
  type: ErrorType;
  title: string;
  advice: string;
  checklist?: { icon: React.ReactNode; text: string }[];
}

export const BiometricCapture: React.FC<Props> = ({ onComplete, onClose }) => {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [error, setError] = useState<AppError | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [showHelp, setShowHelp] = useState(false);
  const [envStatus, setEnvStatus] = useState("Initializing Environment...");
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Rotate environment status messages for immersion
  useEffect(() => {
    if (isCameraActive && !isAnalyzing) {
      const messages = ["Lafayette Node: Stable", "Lighting: Computing Flux", "Subject Detection: Ready", "Neural Mesh: Calibrating"];
      let i = 0;
      const interval = setInterval(() => {
        setEnvStatus(messages[i % messages.length]);
        i++;
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [isCameraActive, isAnalyzing]);

  const startCamera = async () => {
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
      setIsCameraActive(true);
    } catch (err: any) {
      setError({
        type: 'permission',
        title: "Pardon, Access Denied",
        message: "My vision is currently clouded. I need your permission to link with the camera.",
        advice: "Precision styling requires visual input. Please grant camera access via your browser's security settings to proceed with the Ultimatum protocol.",
        checklist: [
          { icon: <Lock size={16} />, text: "Click the Padlock icon in your URL bar" },
          { icon: <Settings size={16} />, text: "Set 'Camera' to 'Allow'" },
          { icon: <RefreshCw size={16} />, text: "Refresh this session to sync" }
        ]
      });
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  const handleCapture = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    setIsAnalyzing(true);
    setError(null);
    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.drawImage(video, 0, 0);
    const base64Data = canvas.toDataURL('image/png', 0.8).split(',')[1];
    
    try {
      const data = await analyzeBiometrics(base64Data);
      // Heuristic: check if response looks valid
      if (data && data.shoulder_cm > 20) {
        setResults(data);
      } else {
        setError({
          type: 'calibration',
          title: "Calibration Mismatch",
          message: "The neural engine found an inconsistency in your scale reference.",
          advice: "Precision is the soul of elegance. Without a clear A4 reference, I cannot guarantee a Zero-Return fit.",
          checklist: [
            { icon: <FileText size={16} />, text: "Ensure A4 paper is vertical & unbent" },
            { icon: <Sun size={16} />, text: "Avoid shadows over the paper surface" },
            { icon: <Ruler size={16} />, text: "Show your head down to your waist" }
          ]
        });
      }
    } catch (err: any) {
      const msg = err.message || "";
      if (msg.includes('NETWORK') || msg.includes('OFFLINE') || msg.includes('fetch')) {
        setError({ 
          type: 'network', 
          title: "Neural Sync Severed",
          message: "The link to the Lafayette high-fidelity nodes has been lost.",
          advice: "Excellence requires a stable uplink. Please verify your connection to the ADGM Tech Hub network.",
          checklist: [
            { icon: <Globe size={16} />, text: "Check your Wi-Fi or LTE signal" },
            { icon: <WifiOff size={16} />, text: "Disable any restrictive VPNs" }
          ]
        });
      } else {
        setError({
          type: 'unknown',
          title: "Handshake Protocol Error",
          message: "A mismatch occurred in the MoE v1.1.0 router logic.",
          advice: "Even the most advanced systems require a brief pause. Let's attempt to re-initialize the handshake.",
          checklist: [
            { icon: <RefreshCw size={16} />, text: "Try the 'Reset System' button below" }
          ]
        });
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#020617] flex flex-col items-center justify-center p-4 font-sans overflow-hidden">
      
      {/* HUD HEADER */}
      <div className="w-full max-w-5xl flex justify-between items-center mb-8 px-4 z-50">
        <div className="flex items-center gap-4 text-white">
          <div className="bg-[#c5a059] p-3 rounded-2xl text-black shadow-[0_0_15px_rgba(197,160,89,0.3)] border border-white/10">
             <ShieldCheck size={20} />
          </div>
          <div>
            <h2 className="text-2xl font-black tracking-tighter uppercase leading-none italic">Neural Mirror <span className="text-[#c5a059]">Sync</span></h2>
            <p className="text-slate-500 font-bold uppercase tracking-[0.3em] text-[9px] mt-1">LVT-ENG Ultimatum v2.5</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowHelp(!showHelp)}
            className="p-3 bg-white/5 hover:bg-white/10 rounded-full text-slate-400 transition-colors border border-white/10"
            title="Calibration Protocol"
          >
            <HelpCircle size={24} />
          </button>
          <button onClick={onClose} className="p-3 bg-white/5 hover:bg-rose-500/20 rounded-full text-white transition-colors border border-white/10">
            <X size={24} />
          </button>
        </div>
      </div>

      <div className="relative w-full max-w-5xl aspect-video bg-black rounded-[3.5rem] overflow-hidden border-4 border-white/5 shadow-[0_0_100px_rgba(197,160,89,0.1)] group">
        
        {/* HELP OVERLAY */}
        {showHelp && (
          <div className="absolute inset-0 z-[60] bg-[#020617]/95 backdrop-blur-xl p-12 flex flex-col items-center justify-center text-center animate-in fade-in zoom-in duration-300">
             <div className="max-w-2xl space-y-10">
                <h3 className="text-4xl font-black uppercase tracking-tighter italic text-[#c5a059]">Calibration Protocol</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
                   <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10">
                      <FileText size={24} className="text-[#c5a059] mb-4" />
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-300 mb-2">A4 Reference</p>
                      <p className="text-xs text-slate-400 leading-relaxed">Hold an A4 paper (21x29.7cm) vertically flat against your chest. This is our measurement anchor.</p>
                   </div>
                   <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10">
                      <Ruler size={24} className="text-[#c5a059] mb-4" />
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-300 mb-2">Ideal Frame</p>
                      <p className="text-xs text-slate-400 leading-relaxed">Stand 1.5 - 2 meters away. Your head down to your waist must be clearly in the frame.</p>
                   </div>
                   <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10">
                      <Sun size={24} className="text-[#c5a059] mb-4" />
                      <p className="text-[10px] font-black uppercase tracking-widest text-slate-300 mb-2">Direct Light</p>
                      <p className="text-xs text-slate-400 leading-relaxed">Face a window or soft indoor light. Backlighting creates shadows that disrupt neural mapping.</p>
                   </div>
                </div>
                <button 
                  onClick={() => setShowHelp(false)}
                  className="bg-white text-black px-16 py-5 rounded-2xl font-black uppercase tracking-widest text-sm hover:bg-[#c5a059] transition-all shadow-xl"
                >
                  Confirm Settings
                </button>
             </div>
          </div>
        )}

        {/* INITIAL STATE */}
        {!isCameraActive && !error ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0a0a0a] text-white p-12 z-10">
            <div className="mb-10 p-10 rounded-full bg-white/5 border border-white/10 animate-float relative">
               <Scan size={80} className="text-[#c5a059]" />
               <div className="absolute inset-0 border-2 border-dashed border-[#c5a059]/20 rounded-full animate-spin-slow"></div>
            </div>
            <button onClick={startCamera} className="bg-white text-slate-950 px-16 py-7 rounded-3xl font-black text-3xl hover:bg-[#c5a059] transition-all shadow-[0_0_60px_rgba(255,255,255,0.1)] uppercase italic tracking-tighter active:scale-95">
              Initialize Mirror
            </button>
            <p className="mt-8 text-[10px] text-slate-500 font-black uppercase tracking-[0.5em] animate-pulse italic">Lafayette Biometric Handshake v1.1.0</p>
          </div>
        ) : error ? (
          /* REFINED ERROR HUD */
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#020617]/98 backdrop-blur-3xl text-white p-12 z-[70] animate-in fade-in zoom-in duration-500 overflow-y-auto">
             <div className="max-w-4xl w-full grid md:grid-cols-2 gap-12 items-center">
                <div className="space-y-8 text-center md:text-left">
                  <div className="w-20 h-20 bg-rose-500/10 rounded-3xl flex items-center justify-center text-rose-500 border border-rose-500/30 mx-auto md:mx-0 shadow-[0_0_40px_rgba(244,63,94,0.1)]">
                    {error.type === 'permission' ? <CameraOff size={40} /> : 
                      error.type === 'network' ? <WifiOff size={40} /> : 
                      <AlertCircle size={40} />}
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-4xl font-black uppercase tracking-tighter italic text-[#F5EFE6] leading-none">{error.title}</h3>
                    <p className="text-rose-200/80 font-medium text-lg tracking-tight leading-relaxed">{error.message}</p>
                    <div className="p-6 bg-white/5 rounded-[2rem] border border-white/10 text-sm text-slate-400 italic leading-relaxed">
                      "{error.advice}"
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <button 
                      onClick={error.type === 'permission' ? () => window.location.reload() : startCamera} 
                      className="flex-1 bg-white text-black py-5 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-rose-500 hover:text-white transition-all shadow-2xl active:scale-95"
                    >
                      {error.type === 'permission' ? 'Reload System' : 'Retry Handshake'}
                    </button>
                    <button 
                      onClick={() => { setError(null); setIsCameraActive(false); }}
                      className="flex-1 bg-white/5 border border-white/10 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-white/10 transition-all active:scale-95"
                    >
                      Back to Origin
                    </button>
                  </div>
                </div>

                {/* VISUAL TROUBLESHOOTING CHECKLIST */}
                {error.checklist && (
                  <div className="bg-white/5 border border-white/10 p-10 rounded-[3rem] space-y-8">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#c5a059] flex items-center gap-2">
                      <Settings size={14} /> Diagnostic Requirements
                    </h4>
                    <div className="space-y-6">
                       {error.checklist.map((item, i) => (
                         <div key={i} className="flex items-center gap-5 group">
                           <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0 text-[#c5a059] group-hover:bg-[#c5a059]/10 transition-colors">
                             {item.icon}
                           </div>
                           <p className="text-sm text-slate-300 font-medium group-hover:text-white transition-colors">{item.text}</p>
                         </div>
                       ))}
                    </div>
                    <div className="pt-6 border-t border-white/5 flex items-center gap-3 opacity-40">
                      <Globe size={14} />
                      <span className="text-[8px] font-black uppercase tracking-widest">Node Status: Dubai/ADGM Cluster Ready</span>
                    </div>
                  </div>
                )}
             </div>
          </div>
        ) : (
          /* ACTIVE FEED */
          <div className="relative w-full h-full bg-[#0a0a0a] overflow-hidden">
            <video ref={videoRef} autoPlay playsInline muted className={`absolute inset-0 w-full h-full object-cover scale-x-[-1] grayscale transition-opacity duration-1000 ${isAnalyzing ? 'opacity-20' : 'opacity-40'}`} />
            <canvas ref={canvasRef} className="hidden" />
            
            {/* HUD TECHNICAL OVERLAY */}
            {!results && !isAnalyzing && (
              <div className="absolute inset-0 pointer-events-none z-20">
                <div className="absolute top-10 left-10 flex flex-col gap-1 opacity-40">
                  <span className="text-[7px] text-white font-mono tracking-[0.4em] uppercase">LINK_ID: {Math.random().toString(16).slice(2,10).toUpperCase()}</span>
                  <span className="text-[7px] text-white font-mono tracking-[0.4em] uppercase">ENCRYPTION: AES_256_ACTIVE</span>
                </div>
                
                <div className="absolute top-10 right-10 text-right opacity-40">
                  <div className="flex items-center gap-2 justify-end">
                    <div className="w-1.5 h-1.5 bg-[#00ff88] rounded-full animate-pulse shadow-[0_0_8px_#00ff88]"></div>
                    <span className="text-[9px] text-white font-black uppercase tracking-[0.2em] italic">{envStatus}</span>
                  </div>
                </div>

                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="w-64 h-80 border-[0.5px] border-dashed border-[#c5a059]/30 rounded-[4rem] mb-12 relative">
                     <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-black px-3 text-[7px] font-black text-[#c5a059] tracking-widest">POSITION SUBJECT</div>
                  </div>
                </div>
                
                <div className="absolute bottom-10 right-10 w-24 h-32 border-[1px] border-[#c5a059]/30 rounded-[1.5rem] flex items-center justify-center bg-[#c5a059]/5 backdrop-blur-sm shadow-2xl">
                  <div className="text-center px-2 space-y-2">
                    <FileText size={20} className="text-[#c5a059]/40 mx-auto" />
                    <span className="text-[6px] text-white/50 font-black uppercase tracking-[0.3em] block leading-tight">
                      A4 SCALE<br/>REFERENCED
                    </span>
                  </div>
                </div>
                
                {/* LASER SCANNER ANIMATION */}
                <div className="absolute left-0 right-0 h-[2px] bg-[#c5a059] shadow-[0_0_30px_#C5A46D] z-30 animate-scan-fast"></div>
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#c5a059]/5 to-transparent h-1/2 w-full animate-scan-fast opacity-40"></div>
                
                <div className="absolute bottom-12 left-0 right-0 flex flex-col items-center">
                  <div className="w-[1px] h-8 bg-amber-500/50 animate-pulse"></div>
                  <p className="text-[7px] font-black text-amber-500/60 tracking-[1em] uppercase mt-3 italic">
                    Pau Neural // Waiting for Subject
                  </p>
                </div>
              </div>
            )}

            {/* ANALYZING STATE */}
            {isAnalyzing && (
              <div className="absolute inset-0 bg-black/95 backdrop-blur-3xl flex flex-col items-center justify-center text-white z-50">
                <div className="relative mb-10">
                  <div className="w-24 h-24 border-2 border-[#c5a059]/20 rounded-full animate-spin border-t-[#c5a059]"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Activity size={32} className="text-[#c5a059] animate-pulse" />
                  </div>
                </div>
                <h2 className="text-[11px] font-black tracking-[0.8em] text-[#c5a059] uppercase italic animate-pulse">
                  Synthesizing Biometric Matrix
                </h2>
                <div className="mt-10 w-64 h-[2px] bg-white/5 overflow-hidden rounded-full">
                  <div className="w-full h-full bg-[#c5a059] animate-loading-bar shadow-[0_0_15px_#c5a059]"></div>
                </div>
                <p className="mt-8 text-[8px] text-slate-500 uppercase tracking-widest italic">Requesting Inference from MoE v1.1.0 Cluster...</p>
              </div>
            )}

            {/* RESULTS STATE */}
            {results && (
              <div className="absolute inset-0 bg-[#fcfaf2] p-12 flex flex-col items-center justify-center animate-in zoom-in-95 duration-500 text-slate-900 z-50 overflow-y-auto">
                <div className="w-full max-w-xl flex flex-col items-center">
                  <div className="mb-12 text-center">
                    <p className="text-[10px] font-black tracking-[0.6em] text-slate-400 uppercase italic">TryOnYou Intelligence</p>
                    <h2 className="text-5xl font-black tracking-tighter text-slate-900 italic mt-3 border-l-[8px] border-[#c5a059] pl-6 uppercase">Biometric Report</h2>
                  </div>

                  <div className="grid grid-cols-2 gap-6 w-full mb-12">
                    {[
                      { label: 'Shoulders', value: results.shoulder_cm },
                      { label: 'Waist', value: results.waist_cm },
                      { label: 'Hips', value: results.hip_cm },
                      { label: 'Height', value: results.height_cm }
                    ].map((item) => (
                      <div key={item.label} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-[0_15px_40px_rgba(0,0,0,0.03)] flex flex-col items-center text-center group hover:border-[#c5a059] transition-all">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 group-hover:text-[#c5a059] transition-colors">{item.label}</p>
                        <p className="text-4xl font-black text-slate-900 tracking-tighter">
                          {item.value}<span className="text-xl font-light italic ml-1 text-slate-400">cm</span>
                        </p>
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={() => onComplete(results)}
                    className="w-full bg-slate-900 text-white py-7 rounded-[2rem] font-black uppercase tracking-widest text-sm hover:bg-[#c5a059] transition-all shadow-2xl active:scale-95 flex items-center justify-center gap-4 group"
                  >
                    Lock Neural Profile <CheckCircle2 size={24} className="group-hover:scale-125 transition-transform" />
                  </button>
                  <p className="mt-6 text-[8px] text-slate-400 uppercase tracking-widest font-black">Accuracy Guaranteed by Ultimatum Protocol</p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ACTION FOOTER */}
      <div className="mt-12 flex gap-8 z-50">
        {!results && isCameraActive && !error && !isAnalyzing && (
          <button 
            onClick={handleCapture}
            className="px-24 py-8 bg-[#c5a059] text-black font-black rounded-full uppercase tracking-widest text-2xl shadow-[0_0_60px_rgba(197,160,89,0.3)] hover:bg-white hover:scale-105 active:scale-95 transition-all flex items-center gap-5 italic group"
          >
            <Scan size={32} className="group-hover:rotate-12 transition-transform" /> Start Neural Scan
          </button>
        )}
      </div>

      <style>{`
        @keyframes scan-fast {
          0% { transform: translateY(0); opacity: 0; }
          10%, 90% { opacity: 1; }
          100% { transform: translateY(540px); opacity: 0; }
        }
        @keyframes loading-bar {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-15px); }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-scan-fast { animation: scan-fast 2.5s cubic-bezier(0.4, 0, 0.2, 1) infinite; }
        .animate-loading-bar { animation: loading-bar 2s cubic-bezier(0.4, 0, 0.2, 1) infinite; }
        .animate-float { animation: float 5s ease-in-out infinite; }
        .animate-spin-slow { animation: spin-slow 12s linear infinite; }
      `}</style>
    </div>
  );
};