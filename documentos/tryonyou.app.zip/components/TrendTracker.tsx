import React from 'react';
import { TrendingUp, Globe, Zap, Search, ArrowRight, BarChart3, Target, Crosshair } from 'lucide-react';

export const TrendTracker: React.FC = () => {
  const trends = [
    { city: "Abu Dhabi", trend: "Bio-Luminescent Silk", volume: "+142%", tag: "#Hub71" },
    { city: "Paris", trend: "Cyber-Structuralism", volume: "+85%", tag: "#LVT-ENG" },
    { city: "Tokyo", trend: "Neural-Adaptive Minimalism", volume: "+210%", tag: "#ADGM" },
    { city: "New York", trend: "Digital Lavender Satin", volume: "+64%", tag: "#TRYONYOU" }
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-16 animate-in slide-in-from-bottom-10 duration-1000 py-12">
      <div className="flex flex-col md:flex-row justify-between items-end gap-10">
        <div className="max-w-2xl space-y-6">
          <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 px-6 py-2 rounded-full text-blue-400">
            <Globe size={16} />
            <span className="text-[10px] font-black uppercase tracking-[0.4em]">FGT (Fashion Global Trends)</span>
          </div>
          <h2 className="text-6xl md:text-7xl font-black tracking-tighter uppercase italic leading-none">Global<br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-white">Intelligence.</span></h2>
          <p className="text-slate-400 text-xl font-medium leading-relaxed">
            Real-time sentiment analysis from the Lafayette Cluster. We track the Google Top-20 
            FGT metrics to adjust your PAU recommendations instantly.
          </p>
        </div>
        <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 flex items-center gap-8 shadow-2xl backdrop-blur-xl">
           <div className="text-center">
              <p className="text-3xl font-black text-white tracking-tighter">24M</p>
              <p className="text-[8px] text-slate-500 font-black uppercase tracking-widest">Data Points/hr</p>
           </div>
           <div className="w-px h-12 bg-white/10"></div>
           <div className="text-center">
              <p className="text-3xl font-black text-blue-400 tracking-tighter">98.4%</p>
              <p className="text-[8px] text-slate-500 font-black uppercase tracking-widest">Accuracy</p>
           </div>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-6">
        {trends.map((item, idx) => (
          <div key={idx} className="group bg-white/5 border border-white/10 p-8 rounded-[3rem] hover:bg-white/10 transition-all hover:-translate-y-2">
            <div className="flex justify-between items-start mb-10">
               <div className="p-3 bg-blue-500/10 rounded-2xl text-blue-400">
                  <Target size={20} />
               </div>
               <span className="text-green-400 text-xs font-black italic">{item.volume}</span>
            </div>
            <div className="space-y-2">
               <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{item.city}</p>
               <h3 className="text-xl font-black uppercase tracking-tighter italic text-white leading-tight">{item.trend}</h3>
            </div>
            <div className="mt-6 flex items-center justify-between">
               <span className="text-[9px] font-black text-blue-400/60 tracking-widest">{item.tag}</span>
               <ArrowRight size={14} className="text-slate-500 group-hover:text-white transition-colors" />
            </div>
          </div>
        ))}
      </div>

      <div className="relative h-[400px] rounded-[4rem] overflow-hidden border border-white/10 shadow-2xl">
         <img 
          src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1600&q=80" 
          className="w-full h-full object-cover opacity-20"
          alt="Data Grid"
         />
         <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex flex-col justify-end p-12">
            <div className="flex flex-col md:flex-row justify-between items-end gap-10">
               <div className="max-w-xl space-y-4">
                  <h4 className="text-3xl font-black uppercase italic tracking-tighter">Neural Trend Visualization</h4>
                  <p className="text-slate-400 text-sm font-medium leading-relaxed">
                     Our FTT module (Fashion Trend Tracker) is the heart of the ABVETOS Intelligence System. 
                     It predicts shifts in textile preference before they reach commercial retail.
                  </p>
               </div>
               <button className="bg-white text-black px-12 py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-blue-400 transition-all flex items-center gap-3 active:scale-95 shadow-2xl">
                  <Crosshair size={18} /> Sync with Hub71 Node
               </button>
            </div>
         </div>
      </div>
    </div>
  );
};