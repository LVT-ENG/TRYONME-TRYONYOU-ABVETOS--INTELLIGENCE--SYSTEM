import React, { useState, useMemo } from 'react';
import { Heart, X, Sparkles, Zap, Filter, Monitor } from 'lucide-react';
import { Product, UserProfile } from '../types';

interface Props {
  onNext: () => void;
  onTryOn: (product: Product) => void;
  userProfile: Partial<UserProfile>;
}

const PRODUCT_CATALOG: Product[] = [
  { sku: 'PAU-001', name: 'Neoprene Oversize Jacket', category: 'Jackets', description: 'Structural cut, high-density technical fabric.', price: 120, image: '/assets/demo/image_11.jpg', tags: ['urban', 'heavy', 'oversize'] },
  { sku: 'PAU-002', name: 'Red Chic Dress', category: 'Dresses', description: 'Timeless elegance in vibrant silk.', price: 299, image: '/assets/demo/image_6.jpg', tags: ['luxury', 'red', 'light'] },
  { sku: 'PAU-003', name: 'Geometric Urban Look', category: 'Sets', description: 'Bold patterns for daily high-fashion.', price: 180, image: '/assets/demo/image_21.jpg', tags: ['minimal', 'pattern', 'medium'] },
  { sku: 'PAU-004', name: 'Casual Leather Set', category: 'Sets', description: 'Premium leather essentials.', price: 450, image: '/assets/demo/image_12.jpg', tags: ['urban', 'leather', 'medium'] },
  { sku: 'PAU-005', name: 'Smart Casual Edit', category: 'Sets', description: 'Perfect for office and after-work.', price: 220, image: '/assets/demo/image_15.jpg', tags: ['street', 'blue', 'heavy'] },
];

export const ShopPAU: React.FC<Props> = ({ onNext, onTryOn, userProfile }) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = useMemo(() => {
    return ['All', ...new Set(PRODUCT_CATALOG.map(p => p.category))];
  }, []);

  const filteredProducts = useMemo(() => {
    if (activeCategory === 'All') return PRODUCT_CATALOG;
    return PRODUCT_CATALOG.filter(p => p.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className="max-w-7xl mx-auto animate-in fade-in duration-700">
      <div className="relative rounded-[3rem] overflow-hidden mb-12 bg-slate-900 shadow-2xl border border-white/5">
        <div className="absolute inset-0">
          <img src="/assets/demo/image_15.jpg" className="w-full h-full object-cover opacity-30 mix-blend-overlay" alt="PAU AI" />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/60 to-transparent"></div>
        </div>
        
        <div className="relative p-10 md:p-16 text-[#F5EFE6] flex flex-col md:flex-row justify-between items-end gap-10">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-[#C5A46D] font-black tracking-[0.4em] text-[10px] mb-4 uppercase">
              <Sparkles size={16} />
              <span>Personalized Algorithm Unit</span>
            </div>
            <h2 className="text-5xl md:text-7xl font-black mb-6 tracking-tighter leading-none">AI Curated <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#C5A46D] to-[#F5EFE6]">ULTIMATUM</span></h2>
            <p className="text-slate-400 text-xl leading-relaxed font-medium">
              We've analyzed your biometrics to render the <strong className="text-white">FGT Top-20</strong>. 
              Engineering silhouettes for your specific morphology.
            </p>
          </div>
          
          <button 
            onClick={onNext} 
            className="group flex items-center gap-4 bg-[#C5A46D] text-black px-10 py-5 rounded-2xl font-black text-lg hover:bg-white transition-all shadow-2xl hover:scale-105"
          >
            <Zap size={22} className="group-hover:animate-pulse" />
            FGT MOCKUPS
          </button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
        {filteredProducts.map((product, idx) => (
          <div 
            key={product.sku} 
            className="group relative bg-[#141619] rounded-[2.5rem] overflow-hidden shadow-xl border border-white/5 transition-all duration-500 transform hover:-translate-y-2"
          >
            <div className="aspect-[4/5] relative overflow-hidden">
              <img src={product.image} alt={product.name} className="w-full h-full object-cover grayscale transition-transform duration-1000 group-hover:scale-110 group-hover:grayscale-0" />
              
              <div className="absolute top-6 left-6 bg-black/80 backdrop-blur-md px-4 py-1.5 rounded-full text-[10px] font-black text-[#C5A46D] shadow-lg flex items-center gap-2 border border-white/10">
                <span className="w-2 h-2 bg-[#C5A46D] rounded-full animate-pulse"></span>
                9{8 + (idx % 2)}% MATCH
              </div>

              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-10">
                <div className="flex justify-center gap-4 transform translate-y-6 group-hover:translate-y-0 transition-transform duration-500">
                  <button onClick={() => onTryOn(product)} className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-black hover:bg-[#C5A46D] transition-all shadow-2xl">
                    <Monitor size={28} />
                  </button>
                  <button onClick={() => onNext()} className="w-14 h-14 bg-[#C5A46D] rounded-2xl flex items-center justify-center text-black hover:bg-white hover:scale-110 transition-all shadow-2xl">
                    <Heart size={28} fill="currentColor" />
                  </button>
                </div>
              </div>
            </div>
            
            <div className="p-8">
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-black text-2xl text-white leading-tight tracking-tighter uppercase">{product.name}</h3>
                <span className="font-black text-[#C5A46D] bg-[#C5A46D]/10 px-3 py-1 rounded-lg text-sm">{product.price}€</span>
              </div>
              <p className="text-slate-500 text-sm font-medium line-clamp-2 leading-relaxed">{product.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};