
import React, { useState } from 'react';
import { Microscope, Layers, Dna, ArrowRight, CheckCircle2, FlaskConical, Zap, Ruler, Activity } from 'lucide-react';

export const TextileLab: React.FC = () => {
  const [activeAnalysis, setActiveAnalysis] = useState<number | null>(null);

  const comparisons = [
    {
      title: "Lafayette Silk Satin",
      metric: "98% Durability",
      dna: "850nm Refraction",
      description: "High-density bio-silk with neural-adaptive gloss. Engineered for mirror rendering accuracy.",
      tags: ["Bio-Sourced", "Oeko-Tex", "Anti-Wrinkle"],
      gsm: 120
    },
    {
      title: "Ultimatum Neoprene",
      metric: "4-Way Adaptive",
      dna: "Thermic Regulator",
      description: "Synthetic structure optimized for JIT production. Zero-waste pattern cutting compatible.",
      tags: ["Zero-Waste", "Machine-Wash", "Neural-Lock"],
      gsm: 320
    }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-16 animate-in fade-in duration-1000 py-12">
      <div className="text-center space-y-6">
        <div className="inline-flex items-center gap-2 bg-gold/10 border border-gold/20 px-6 py-2 rounded-full text-gold">
          <FlaskConical size={16} />
          <span className="text-[10px] font-black uppercase tracking-[0.4em]">TextileComparator™ // LVT-ENG</span>
        </div>
        <h2 className="text-6xl md:text-7xl font-black tracking-tighter uppercase italic leading-none">Fiber<br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-gold to-white">Intelligence.</span></h2>
        <p className="text-slate-400 max-w-2xl mx-auto text-lg font-medium leading-relaxed">
          Validating Lafayette Excellence fiber integrity. Microscopic analysis of drape and breathability 
          linked to your 3D Avatar morphology.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-10">
        {comparisons.map((item, idx) => (
          <div 
            key={idx}
            className="group relative bg-white/5 border border-white/10 rounded-[3.5rem] p-12 hover:bg-white/10 transition-all cursor-pointer overflow-hidden shadow-2xl"
            onMouseEnter={() => setActiveAnalysis(idx)}
            onMouseLeave={() => setActiveAnalysis(null)}
          >
            <div className="absolute -right-20 -top-20 opacity-5 group-hover:opacity-10 transition-opacity">
               <Layers size={300} className="text-gold" />
            </div>

            <div className="relative z-10 space-y-10">
               <div className="flex justify-between items-start">
                  <div className="p-4 bg-gold/10 rounded-2xl text-gold">
                    {idx === 0 ? <Microscope size={32} /> : <Dna size={32} />}
                  </div>
                  <div className="text-right">
                    <p className="text-gold font-black text-2xl italic tracking-tighter leading-none">{item.metric}</p>
                    <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest mt-2">{item.dna}</p>
                  </div>
               </div>

               <div className="space-y-3">
                  <h3 className="text-3xl font-black uppercase tracking-tighter italic text-white leading-none">{item.title}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed font-medium">{item.description}</p>
               </div>

               <div className="flex flex-wrap gap-3">
                  {item.tags.map(tag => (
                    <span key={tag} className="px-4 py-1.5 bg-white/5 rounded-full text-[10px] font-black uppercase tracking-widest text-slate-300 border border-white/10">
                      {tag}
                    </span>
                  ))}
               </div>

               <div className={`pt-10 border-t border-white/5 flex items-center justify-between transition-all duration-700 ${activeAnalysis === idx ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
                  <div className="flex items-center gap-3">
                    <CheckCircle2 size={16} className="text-green-500" />
                    <span className="text-[10px] font-bold text-white uppercase tracking-widest italic">Molecular Verified</span>
                  </div>
                  <div className="flex items-center gap-2 text-gold">
                     <Activity size={16} className="animate-pulse" />
                     <span className="text-[10px] font-black uppercase tracking-[0.2em]">{item.gsm} GSM</span>
                  </div>
               </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-slate-900 rounded-[4rem] p-16 flex flex-col md:flex-row items-center justify-between gap-16 border border-white/5 shadow-2xl relative overflow-hidden">
         <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,#C5A46D22,transparent)]"></div>
         <div className="max-w-xl space-y-6 relative z-10">
            <h4 className="text-4xl font-black uppercase italic tracking-tighter text-white">Fabric Integrity Engine</h4>
            <p className="text-slate-400 text-lg leading-relaxed font-medium">
               The TextileComparator module synchronizes fiber density with JIT manufacturing. 
               We ensure physical drape matches the Virtual Try-On simulation with 99.8% fidelity.
            </p>
         </div>
         <div className="grid grid-cols-2 gap-6 relative z-10">
            {[
              { icon: <Ruler />, value: '0.02mm', label: 'Precision' },
              { icon: <Layers />, value: '5-Ply', label: 'Strength' }
            ].map((stat, i) => (
              <div key={i} className="bg-white/5 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/5 text-center min-w-[140px] hover:border-gold/30 transition-all">
                <div className="text-gold mx-auto mb-4">{React.cloneElement(stat.icon as React.ReactElement, { size: 28 })}</div>
                <p className="text-2xl font-black text-white tracking-tighter">{stat.value}</p>
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-1">{stat.label}</p>
              </div>
            ))}
         </div>
      </div>
    </div>
  );
};
