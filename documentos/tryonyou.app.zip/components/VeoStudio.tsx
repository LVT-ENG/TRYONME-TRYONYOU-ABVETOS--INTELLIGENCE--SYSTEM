import React, { useState, useRef } from 'react';
import { Upload, Video, Wand2, X, ArrowLeft, Loader2, Sparkles, Film, PlayCircle, RefreshCw } from 'lucide-react';
import { generateVeoSnap } from '../services/geminiService';

interface Props {
  onClose: () => void;
}

export const VeoStudio: React.FC<Props> = ({ onClose }) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setSelectedImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!selectedImage) return;
    
    setIsLoading(true);
    setError(null);
    try {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await window.aistudio.openSelectKey();
      }

      const base64 = selectedImage.split(',')[1];
      const video = await generateVeoSnap(base64, setStatus);
      setVideoUrl(video);
    } catch (err: any) {
      if (err.message === "API_KEY_RESET") {
        await window.aistudio.openSelectKey();
      } else {
        setError("Error en el motor cinemático. Compruebe su conexión o API Key.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[120] bg-anthracite flex flex-col items-center justify-center font-sans overflow-hidden">
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
        backgroundImage: 'radial-gradient(circle, #C5A46D 1px, transparent 1px)',
        backgroundSize: '30px 30px'
      }}></div>

      {/* Header */}
      <div className="absolute top-10 left-10 right-10 flex justify-between items-center z-50">
        <div className="flex items-center gap-4">
           <button onClick={onClose} className="p-4 bg-white/5 border border-white/10 rounded-full text-bone hover:bg-white/10 transition-all group">
             <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
           </button>
           <div>
              <p className="text-[10px] font-black text-gold uppercase tracking-[0.4em] mb-1 italic">Veo 3.1 Neural Runtime</p>
              <h2 className="text-2xl font-black text-bone uppercase tracking-tighter">Cinematic Studio</h2>
           </div>
        </div>
        <button onClick={onClose} className="p-4 bg-white/5 border border-white/10 rounded-full text-bone hover:bg-rose-500 transition-all">
          <X size={24} />
        </button>
      </div>

      <main className="flex-1 w-full max-w-6xl px-8 flex flex-col md:flex-row items-center justify-center gap-12 lg:gap-24 mt-20">
        
        {/* PREVIEW VIEWPORT (9:16 Aspect) */}
        <div className="relative group w-full max-w-[340px] aspect-[9/16] bg-black rounded-[4rem] border-2 border-white/10 overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.6)] ring-1 ring-white/10">
          {!selectedImage && !videoUrl && (
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="absolute inset-0 flex flex-col items-center justify-center cursor-pointer hover:bg-white/5 transition-all text-center p-12"
            >
              <div className="bg-gold/20 p-8 rounded-full mb-6 group-hover:scale-110 transition-transform">
                <Upload size={48} className="text-gold" />
              </div>
              <h3 className="text-xl font-black text-bone uppercase tracking-tighter">Subir Foto</h3>
              <p className="text-slate-500 text-[10px] mt-2 uppercase tracking-[0.2em] leading-relaxed">Referencia para malla neural cinemática</p>
            </div>
          )}

          {selectedImage && !videoUrl && !isLoading && (
            <div className="relative h-full animate-in fade-in duration-500">
              <img src={selectedImage} className="w-full h-full object-cover" alt="Source" />
              <div className="absolute inset-0 bg-black/30 group-hover:opacity-0 transition-opacity"></div>
              <button 
                onClick={() => setSelectedImage(null)}
                className="absolute top-8 right-8 p-3 bg-black/60 backdrop-blur-md rounded-full text-bone border border-white/20 hover:bg-rose-500 transition-colors shadow-xl"
              >
                <X size={18} />
              </button>
            </div>
          )}

          {isLoading && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/95 backdrop-blur-2xl text-center p-12 animate-in fade-in z-30">
               <div className="relative mb-10">
                  <div className="w-32 h-32 border-2 border-gold/30 rounded-full animate-spin border-t-gold"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Sparkles size={40} className="text-gold animate-pulse" />
                  </div>
               </div>
               <h3 className="text-lg font-black text-bone uppercase tracking-widest mb-4 italic">{status}</h3>
               <div className="w-48 h-1 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-gold animate-loading-bar w-full"></div>
               </div>
               <p className="text-[8px] text-gold mt-6 uppercase font-bold tracking-[0.4em] animate-pulse italic">Generando Asset Cinematográfico 1080p...</p>
            </div>
          )}

          {videoUrl && (
            <div className="relative h-full bg-black animate-in zoom-in duration-700">
              <video 
                src={videoUrl} 
                autoPlay 
                loop 
                muted 
                playsInline 
                className="w-full h-full object-cover shadow-inner" 
              />
              <button 
                onClick={() => { setVideoUrl(null); }}
                className="absolute top-8 right-8 p-3 bg-black/60 backdrop-blur-md rounded-full text-bone border border-white/20 hover:bg-gold hover:text-black transition-all shadow-xl"
              >
                <RefreshCw size={18} />
              </button>
            </div>
          )}
          
          <input type="file" ref={fileInputRef} onChange={handleImageUpload} className="hidden" accept="image/*" />
        </div>

        {/* Action Controls */}
        <div className="flex-1 space-y-12 max-w-md text-center md:text-left animate-in slide-in-from-right-8 duration-1000">
          <div className="space-y-6">
             <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-gold/10 border border-gold/20 text-gold text-[10px] font-black uppercase tracking-[0.4em]">
                <Film size={14} /> Renderizado Neural Veo 3.1
             </div>
             <h1 className="text-6xl md:text-8xl font-black text-bone tracking-tighter leading-[0.85] uppercase italic">
               Peacock <br/><span className="text-gold">Snap.</span>
             </h1>
             <p className="text-slate-400 text-lg font-medium leading-relaxed italic">
               La magia de Veo permite una transición fluida entre looks. Crea videos cinemáticos de alta moda en segundos con tu avatar digital.
             </p>
          </div>

          <div className="flex flex-col gap-6">
             <button 
              onClick={handleGenerate}
              disabled={!selectedImage || isLoading}
              className="w-full bg-gold text-black py-8 rounded-[2.5rem] font-black text-2xl hover:bg-bone hover:scale-105 transition-all shadow-[0_0_80px_rgba(197,160,89,0.2)] uppercase italic flex items-center justify-center gap-4 group disabled:opacity-30 disabled:hover:scale-100"
             >
               {isLoading ? <Loader2 className="animate-spin" /> : <Wand2 className="group-hover:animate-bounce" />}
               {isLoading ? "Procesando Malla..." : "Generar Transformación"}
             </button>

             {error && (
               <div className="p-6 bg-rose-500/10 border border-rose-500/20 rounded-[2rem] text-rose-500 text-xs font-bold text-center animate-in shake">
                 {error}
               </div>
             )}
             
             <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 flex items-center gap-6 group">
                <div className="bg-gold/20 p-4 rounded-2xl group-hover:rotate-12 transition-transform duration-500">
                  <PlayCircle className="text-gold" size={32} />
                </div>
                <div className="text-left">
                  <p className="text-bone font-black text-xs uppercase tracking-widest italic">Salida Master</p>
                  <p className="text-[9px] text-slate-500 uppercase tracking-widest leading-relaxed mt-1 italic">
                    Resolución: 1080p MP4 <br/> Optimizado para Display de Retail Vertical
                  </p>
                </div>
             </div>
          </div>
        </div>
      </main>

      <footer className="p-10 text-center text-[8px] text-slate-800 font-mono tracking-[0.8em] uppercase">
        LVT-ENG Cinematic Lab // Ultimatum AI Runtime
      </footer>

      <style>{`
        @keyframes loading-bar {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .animate-loading-bar {
          animation: loading-bar 2.5s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};