import React, { useEffect, useState, useRef } from 'react';
import { Sparkles, X, ShoppingBag, ArrowLeft, Scan, Ruler, CheckCircle2, Loader2, Zap, RefreshCw } from 'lucide-react';
import { Product, UserProfile } from '../types';
import { generateVirtualTryOn, generateVeoSnap } from '../services/geminiService';

interface Props {
  product: Product;
  userProfile: Partial<UserProfile>;
  onClose: () => void;
  onProceedToCheckout: () => void;
}

export const VirtualTryOn: React.FC<Props> = ({ product, userProfile, onClose, onProceedToCheckout }) => {
  const [vtoImage, setVtoImage] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isVeoLoading, setIsVeoLoading] = useState(false);
  const [veoStatus, setVeoStatus] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [calibrationStep, setCalibrationStep] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const calibrationSteps = [
    "Sincronizando Biometría...",
    "Mapeando Silueta...",
    "Generando Texturas Lafayette...",
    "Neural Engine Activo..."
  ];

  useEffect(() => {
    const runVTO = async () => {
      try {
        setIsLoading(true);
        const biometrics = userProfile.biometrics?.rawResults || {
          height_cm: userProfile.height || 175,
          waist_cm: userProfile.biometrics?.measurements?.waist || 75,
          hip_cm: userProfile.biometrics?.measurements?.hips || 95,
          shoulder_cm: userProfile.biometrics?.measurements?.shoulders || 45
        };

        const result = await generateVirtualTryOn(
          `${product.name}: ${product.description}`,
          biometrics
        );
        setVtoImage(result);
      } catch (err: any) {
        setError("La calibración neural falló. Reintente el escaneo biométrico.");
      } finally {
        setIsLoading(false);
      }
    };

    runVTO();
    const stepInterval = setInterval(() => {
      setCalibrationStep(prev => (prev < calibrationSteps.length - 1 ? prev + 1 : prev));
    }, 1800);
    return () => clearInterval(stepInterval);
  }, [product, userProfile]);

  const handleVeoSnap = async () => {
    if (!vtoImage) return;

    try {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await window.aistudio.openSelectKey();
      }

      setIsVeoLoading(true);
      setError(null);
      
      const cleanBase64 = vtoImage.split(',')[1];
      const video = await generateVeoSnap(cleanBase64, setVeoStatus);
      setVideoUrl(video);
    } catch (err: any) {
      if (err.message === "API_KEY_RESET") {
        await window.aistudio.openSelectKey();
      } else {
        setError("Error en render cinemático. Verifique su API Key de pago.");
      }
    } finally {
      setIsVeoLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] bg-anthracite flex flex-col items-center justify-center font-sans overflow-hidden">
      {/* Background Decor */}
      <div className="absolute inset-0 opacity-5 pointer-events-none" style={{
        backgroundImage: 'radial-gradient(circle, #C5A46D 1.5px, transparent 1.5px)',
        backgroundSize: '50px 50px'
      }}></div>

      {/* Header UI */}
      <div className="absolute top-8 left-8 right-8 flex justify-between items-center z-[120]">
        <button onClick={onClose} className="p-4 bg-white/5 border border-white/10 rounded-full text-bone hover:bg-white/10 transition-all group">
          <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
        </button>
        <div className="flex flex-col items-center">
           <p className="text-[10px] font-black text-gold uppercase tracking-[0.6em] mb-1 animate-pulse">SYSTEM: ACTIVE</p>
           <h2 className="text-2xl font-black text-bone uppercase tracking-widest italic">TryOnYou Mirror</h2>
        </div>
        <button onClick={onClose} className="p-4 bg-white/5 border border-white/10 rounded-full text-bone hover:bg-rose-500 transition-all">
          <X size={24} />
        </button>
      </div>

      <main className="flex-1 w-full max-w-7xl px-6 flex flex-col lg:flex-row items-center justify-center gap-12 lg:gap-24">
        
        {/* MIRROR VIEWPORT */}
        <div className="relative group shrink-0">
            {/* Mirror Frame */}
            <div className="w-[300px] h-[540px] md:w-[400px] md:h-[720px] bg-black rounded-[4rem] overflow-hidden border-[10px] border-anthracite shadow-[0_0_80px_rgba(0,0,0,0.8)] relative ring-1 ring-white/10">
               
               <div className="absolute inset-0 z-0">
                 {isLoading ? (
                    <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 p-12 text-center space-y-6">
                        <div className="relative">
                           <div className="w-20 h-20 border-2 border-gold/10 rounded-full animate-spin border-t-gold"></div>
                           <div className="absolute inset-0 flex items-center justify-center">
                              <Scan size={28} className="text-gold animate-pulse" />
                           </div>
                        </div>
                        <p className="text-gold text-[9px] font-black uppercase tracking-[0.4em] animate-pulse italic">
                           {calibrationSteps[calibrationStep]}
                        </p>
                    </div>
                 ) : videoUrl ? (
                   <video 
                    ref={videoRef}
                    src={videoUrl} 
                    autoPlay 
                    loop 
                    muted 
                    playsInline 
                    className="w-full h-full object-cover animate-in fade-in duration-1000" 
                   />
                 ) : (
                   <img src={vtoImage!} className="w-full h-full object-cover animate-in fade-in duration-700" alt="Result" />
                 )}
               </div>

               {/* Overlays */}
               <div className="absolute inset-0 bg-gradient-to-tr from-white/5 via-transparent to-white/5 pointer-events-none z-10"></div>
               
               <div className="absolute inset-0 pointer-events-none z-20">
                  <div className="absolute top-0 left-0 right-0 h-[2px] bg-gold shadow-[0_0_15px_#C5A46D] animate-vto-scan"></div>
                  
                  {!isLoading && (
                    <div className="absolute bottom-10 left-8 right-8 p-6 bg-black/60 backdrop-blur-2xl border border-white/10 rounded-[2.5rem] shadow-2xl">
                       <div className="flex justify-between items-center">
                          <div>
                             <p className="text-[8px] font-black text-gold uppercase tracking-widest mb-1 italic">Verified Silhouette</p>
                             <p className="text-lg font-black text-bone uppercase tracking-tighter leading-none">{product.name}</p>
                          </div>
                          <div className="bg-gold p-3 rounded-2xl text-black">
                             <CheckCircle2 size={18} />
                          </div>
                       </div>
                    </div>
                  )}
               </div>
            </div>
        </div>

        {/* INFO PANEL */}
        <div className="flex-1 space-y-12 text-center lg:text-left max-w-lg">
           <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/5 border border-gold/20 text-gold text-[10px] font-black uppercase tracking-[0.3em]">
                 <Sparkles size={14} /> Neural Precision Render
              </div>
              <h1 className="text-5xl md:text-7xl font-black text-bone tracking-tighter leading-tight uppercase italic">
                ESPEJO <br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-gold to-white">LAFAYETTE.</span>
              </h1>
              <p className="text-slate-400 text-lg leading-relaxed font-medium">
                Hemos ajustado cada patrón a tus <span className="text-bone">{userProfile.height || 178}cm</span>. 
                Experimenta la caída perfecta de los tejidos Lafayette en tiempo real.
              </p>
           </div>

           {error ? (
              <div className="p-6 bg-rose-500/10 border border-rose-500/20 rounded-[2.5rem] text-rose-500 text-sm font-bold animate-pulse">
                 {error}
              </div>
           ) : (
             <div className="flex flex-col gap-6">
                <button 
                  onClick={handleVeoSnap}
                  disabled={isVeoLoading || isLoading}
                  className="w-full relative group overflow-hidden transition-all duration-300 active:scale-95 disabled:opacity-50"
                >
                   <div className={`absolute inset-0 bg-gradient-to-r from-gold to-[#8c744c] rounded-[2.5rem] ${isVeoLoading ? 'animate-pulse' : ''}`}></div>
                   <div className="relative m-[1px] bg-anthracite p-8 rounded-[2.5rem] flex items-center justify-center gap-6 group-hover:bg-transparent transition-all">
                      {isVeoLoading ? (
                        <>
                          <Loader2 size={24} className="text-gold animate-spin" />
                          <p className="text-gold font-black uppercase tracking-[0.4em] text-xs animate-pulse">{veoStatus}</p>
                        </>
                      ) : (
                        <>
                          <Zap size={24} className="text-gold" />
                          <div className="text-left">
                             <p className="text-bone font-black text-xl uppercase italic tracking-tighter leading-none">Cinematic Snap</p>
                             <p className="text-gold text-[9px] font-bold uppercase tracking-[0.3em] mt-1">Veo 3.1 Neural Runtime</p>
                          </div>
                        </>
                      )}
                   </div>
                </button>
                
                <div className="grid grid-cols-2 gap-4">
                  <button onClick={onProceedToCheckout} className="bg-bone text-black py-6 rounded-[2.5rem] font-black text-lg hover:bg-gold transition-all shadow-xl flex items-center justify-center gap-3 uppercase italic">
                    <ShoppingBag size={20} /> Comprar
                  </button>
                  <button onClick={() => setVideoUrl(null)} className="bg-white/5 border border-white/10 text-bone py-6 rounded-[2.5rem] font-black text-lg hover:bg-white/10 transition-all flex items-center justify-center gap-3 uppercase italic">
                    <RefreshCw size={20} /> Reset
                  </button>
                </div>
             </div>
           )}

           <div className="flex items-center gap-4 p-6 bg-white/5 rounded-[2.5rem] border border-white/10 backdrop-blur-xl">
              <div className="p-3 bg-gold/10 rounded-2xl text-gold">
                <Ruler size={20} />
              </div>
              <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest leading-tight">
                Análisis Biométrico: <span className="text-white">Talla {product.availableSizes?.[1] || 'L'}</span> <br/>
                <span className="text-green-500 font-bold">Ajuste Optimizado 99.8%</span>
              </p>
           </div>
        </div>
      </main>

      <style>{`
        @keyframes vto-scan {
          0% { transform: translateY(0); opacity: 0; }
          20% { opacity: 1; }
          80% { opacity: 1; }
          100% { transform: translateY(720px); opacity: 0; }
        }
        .animate-vto-scan { animation: vto-scan 4s cubic-bezier(0.4, 0, 0.2, 1) infinite; }
      `}</style>
    </div>
  );
};