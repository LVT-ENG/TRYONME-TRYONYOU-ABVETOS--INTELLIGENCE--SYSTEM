import React from 'react';
import { Shirt, ShoppingBag, Fingerprint, User, Zap, Film, FlaskConical, TrendingUp } from 'lucide-react';
import { AppState } from '../types';

interface NavbarProps {
  currentState: AppState;
  onNavigate: (state: AppState) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentState, onNavigate }) => {
  if (currentState === 'retail_kiosk') return null;

  return (
    <nav className="fixed top-0 w-full z-50 bg-black/40 backdrop-blur-2xl border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-24">
          
          <div 
            className="flex items-center gap-4 cursor-pointer group"
            onClick={() => onNavigate('landing')}
          >
            <div className="bg-gold text-black p-3 rounded-2xl shadow-[0_0_20px_rgba(197,164,109,0.3)] group-hover:scale-110 transition-all duration-500">
              <Shirt size={24} strokeWidth={2.5} />
            </div>
            <div className="flex flex-col">
              <span className="font-black text-2xl leading-none tracking-tight text-white uppercase italic">
                TRYON<span className="text-gold">YOU</span>
              </span>
              <span className="text-[9px] text-slate-500 font-black tracking-[0.4em] uppercase">ULTIMATUM ECOSYSTEM</span>
            </div>
          </div>
          
          <div className="flex items-center gap-4 md:gap-8">
            <div className="hidden lg:flex items-center gap-6 pr-6 border-r border-white/5">
              <button 
                onClick={() => onNavigate('textile_lab')}
                className={`flex items-center gap-2 transition-all duration-300 ${currentState === 'textile_lab' ? 'text-gold' : 'text-slate-400 hover:text-white'}`}
              >
                <FlaskConical size={18} />
                <span className="text-[9px] font-black uppercase tracking-widest">Lab</span>
              </button>
              <button 
                onClick={() => onNavigate('trend_tracker')}
                className={`flex items-center gap-2 transition-all duration-300 ${currentState === 'trend_tracker' ? 'text-gold' : 'text-slate-400 hover:text-white'}`}
              >
                <TrendingUp size={18} />
                <span className="text-[9px] font-black uppercase tracking-widest">Trends</span>
              </button>
            </div>

            <button 
              onClick={() => onNavigate('veo_studio')}
              className={`flex items-center gap-3 transition-all duration-300 ${currentState === 'veo_studio' ? 'text-gold' : 'text-slate-400 hover:text-white'}`}
            >
              <Film size={20} />
              <span className="hidden sm:inline text-xs font-black uppercase tracking-widest">Studio</span>
            </button>

            <button 
              onClick={() => onNavigate('smart_closet')}
              className={`flex items-center gap-3 transition-all duration-300 ${currentState === 'smart_closet' ? 'text-gold' : 'text-slate-400 hover:text-white'}`}
            >
              <User size={22} />
              <span className="hidden sm:inline text-xs font-black uppercase tracking-widest">CLOSET</span>
            </button>
            
            <button 
              onClick={() => onNavigate('shop_pau')}
              className="flex items-center gap-3 bg-white text-black px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-gold transition-all shadow-xl active:scale-95"
            >
              {currentState === 'checkout_avbet' ? <Fingerprint size={18} /> : <ShoppingBag size={18} />}
              <span>{currentState === 'checkout_avbet' ? 'PAYMENT' : 'SHOP'}</span>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};