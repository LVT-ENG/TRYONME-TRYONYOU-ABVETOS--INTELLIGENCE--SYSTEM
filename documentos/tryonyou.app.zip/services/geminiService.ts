import { GoogleGenAI, Type } from "@google/genai";
import { RecipeData } from "../types";

// Always use process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Biometric Extraction
 */
export const analyzeBiometrics = async (base64Image: string) => {
  if (!navigator.onLine) {
    throw new Error("OFFLINE: Neural link requires an active network connection.");
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview', 
      contents: {
          parts: [
            { inlineData: { data: base64Image, mimeType: 'image/png' } },
            { 
              text: "Scale reference: subject is holding an A4 paper (21x29.7cm) vertically against their chest. " +
                    "Perform a high-precision morphology analysis. Calculate accurate measurements in centimeters. " +
                    "Identify posture quality and silhouette type. " +
                    "Return JSON with: shoulder_cm (number), waist_cm (number), hip_cm (number), height_cm (number), posture_analysis (string)." 
            }
          ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            shoulder_cm: { type: Type.NUMBER },
            waist_cm: { type: Type.NUMBER },
            hip_cm: { type: Type.NUMBER },
            height_cm: { type: Type.NUMBER },
            posture_analysis: { type: Type.STRING }
          },
          required: ["shoulder_cm", "waist_cm", "hip_cm", "height_cm", "posture_analysis"]
        }
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error: any) {
    console.error("Biometric analysis failed:", error);
    throw error;
  }
};

/**
 * Veo Video Generation (The Magical Peacock Snap)
 */
export const generateVeoSnap = async (
  base64Image: string, 
  onStatusUpdate: (msg: string) => void
): Promise<string> => {
  const veoAi = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  onStatusUpdate("Initializing Magic Mirror Protocol...");

  try {
    let operation = await veoAi.models.generateVideos({
      model: 'veo-3.1-fast-generate-preview',
      prompt: 'Cinematic fashion transition. A sophisticated white peacock stands in a luxury atelier. With a magical snap of its iridescent feathers and a burst of golden sparkles, the clothing on the human model transforms instantly into a breathtaking Lafayette high-fashion silk outfit. Slow motion, 8k, photorealistic, elegant editorial aesthetic.',
      image: {
        imageBytes: base64Image,
        mimeType: 'image/png',
      },
      config: {
        numberOfVideos: 1,
        resolution: '1080p',
        aspectRatio: '9:16'
      }
    });

    onStatusUpdate("Calibrating Cinematic Render...");

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 8000));
      onStatusUpdate("Synthesizing Motion Patterns...");
      operation = await veoAi.operations.getVideosOperation({operation: operation});
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) throw new Error("Video generation failed to yield a URI.");

    return `${downloadLink}&key=${process.env.API_KEY}`;
  } catch (error: any) {
    if (error.message?.includes("Requested entity was not found")) {
      throw new Error("API_KEY_RESET");
    }
    throw error;
  }
};

/**
 * Virtual Try-On Image Generation
 */
export async function generateVirtualTryOn(
  garmentDescription: string, 
  biometricContext: { 
    height_cm: number, 
    waist_cm: number, 
    hip_cm: number, 
    shoulder_cm: number 
  }
): Promise<string> {
  const biometricStr = `${biometricContext.height_cm}cm height, ${biometricContext.shoulder_cm}cm shoulders, ${biometricContext.waist_cm}cm waist, and ${biometricContext.hip_cm}cm hips`;
  
  // Rule: Use gemini-2.5-flash-image for general image generation
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          text: `Professional high-end fashion catalog photography. A person with body measurements ${biometricStr} is wearing: ${garmentDescription}. Perfect fit, luxury studio lighting, high-detail fabric textures, Lafayette Excellence brand style, 9:16 aspect ratio.`
        }
      ]
    },
    config: {
      imageConfig: {
        aspectRatio: "9:16"
      }
    }
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  
  throw new Error("Failed to generate VTO image part");
}

export async function generateRecipe(prompt: string, imageBase64?: string): Promise<RecipeData> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: { responseMimeType: "application/json" }
  });
  return JSON.parse(response.text || '{}');
}