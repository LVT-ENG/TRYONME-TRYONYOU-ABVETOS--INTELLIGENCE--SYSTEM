/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./index.tsx",
    "./App.tsx",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        gold: '#C5A46D',
        peacock: '#006D77',
        anthracite: '#141619',
        bone: '#F5EFE6',
      },
    },
  },
  plugins: [],
}