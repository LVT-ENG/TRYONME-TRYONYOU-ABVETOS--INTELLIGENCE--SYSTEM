import React from 'react';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
        src?: string;
        alt?: string;
        'auto-rotate'?: boolean;
        'camera-controls'?: boolean;
        'shadow-intensity'?: string;
        'environment-image'?: string;
        'auto-rotate-delay'?: string;
        'rotation-per-second'?: string;
        'interaction-prompt'?: string;
        'touch-action'?: string;
        'shadow-softness'?: string;
        exposure?: string;
      };
    }
  }

  namespace React {
    namespace JSX {
      interface IntrinsicElements {
        'model-viewer': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
          src?: string;
          alt?: string;
          'auto-rotate'?: boolean;
          'camera-controls'?: boolean;
          'shadow-intensity'?: string;
          'environment-image'?: string;
          'auto-rotate-delay'?: string;
          'rotation-per-second'?: string;
          'interaction-prompt'?: string;
          'touch-action'?: string;
          'shadow-softness'?: string;
          exposure?: string;
        };
      }
    }
  }
}

export type AppState = 
  | 'landing' 
  | 'questionnaire' 
  | 'biometrics' 
  | 'shop_pau' 
  | 'fgt_mockups' 
  | 'checkout_avbet' 
  | 'smart_closet'
  | 'retail_kiosk'
  | 'live_stylist'
  | 'vto_preview'
  | 'veo_studio'
  | 'textile_lab'
  | 'trend_tracker';

export type ProductCategory = 'pants' | 'jacket' | 'shoes' | 'accessory';

export interface BodyComposition {
  posture: 'Excellent' | 'Good' | 'Fair' | 'Requires Attention';
  postureNotes: string;
  bodyFatPctEstimate: number;
  leanMassPctEstimate: number;
  bmiEstimate: number;
  bmrEstimate: number;
  skeletalAnalysis: string;
}

export interface GarmentMeasurements {
  waist?: number;
  hips?: number;
  length?: number;
  chest?: number;
  shoulders?: number;
  sleeve?: number;
  footLength?: number;
}

export interface UserProfile {
  name: string;
  email: string;
  city: string;
  weight: number;
  height: number;
  avbetBalance: number;
  preferences: {
    styles: string[];
    colors: string[];
    fabricWeight: number;
  };
  biometrics: {
    avatarPhotos: string[];
    voicePrint: boolean;
    irisScan: boolean;
    measurements?: GarmentMeasurements; 
    bodyComposition?: BodyComposition;
    rawResults?: {
      shoulder_cm: number;
      waist_cm: number;
      hip_cm: number;
      height_cm: number;
      posture_analysis: string;
    };
  };
}

export interface Product {
  sku: string;
  name: string;
  description: string;
  image: string;
  price: number;
  tags: string[];
  category: string;
  availableSizes?: string[];
}

export interface DetailedProduct extends Product {
  baseMeasurements: GarmentMeasurements;
}

export interface WardrobeItem {
  id: string;
  productName: string;
  image: string;
  purchaseDate: string;
  lastInteractedDate?: string;
  status: 'active' | 'donated';
  condition: 'new' | 'good' | 'worn';
  avbetValue: number;
  ecoImpact: { 
    co2Saved: number; 
    waterSaved: number; 
  };
}

export interface Mockup {
  id: string;
  baseSku: string;
  designId: string;
  previewUrl: string;
  price: number;
  productionData: {
    whiteBaseSku: string;
    printFile: string;
  };
}

export interface Garment {
  id: string;
  name: string;
  category: string;
  image: string;
  price: string;
}

export interface RecipeData {
  title: string;
  description: string;
  cookingTime: string;
  difficulty: string;
  calories: number;
  cuisine: string;
  ingredients: string[];
  instructions: string[];
  nutrition: {
    name: string;
    value: number;
    unit: string;
    fill: string;
  }[];
}