// PMV – Apps Script unificado
const SHEET = 'TAREAS';
const CALENDAR = CalendarApp.getDefaultCalendar();

function sh() {
  return SpreadsheetApp.getActive().getSheetByName(SHEET);
}

function pmv_autoSync() {
  const sheet = sh();
  const data = sheet.getDataRange().getValues();
  const h = data[0];

  const col = {
    id: h.indexOf('ID'),
    proyecto: h.indexOf('Proyecto'),
    tarea: h.indexOf('Tarea'),
    fecha: h.indexOf('Fecha_entrega'),
    estado: h.indexOf('Estado'),
    recordatorio: h.indexOf('Recordatorio'),
    encal: h.indexOf('En_Calendar')
  };

  for (let i = 1; i < data.length; i++) {
    let row = data[i];
    let fecha = row[col.fecha];
    let record = row[col.recordatorio];
    let estado = row[col.estado];
    let marcado = row[col.encal];

    if (!(fecha instanceof Date)) continue;

    if (record === "Sí" && !marcado) {
      CALENDAR.createAllDayEvent(
        `${row[col.proyecto]} – ${row[col.tarea]}`,
        fecha
      );
      sheet.getRange(i + 1, col.encal + 1).setValue("Sí");
      continue;
    }

    if (estado === "Hecha" && marcado === "Sí") {
      sheet.getRange(i + 1, col.encal + 1).setValue("Archivado");
    }
  }
}

function pmv_alertas() {
  const hoy = new Date();
  const sheet = sh();
  const data = sheet.getDataRange().getValues();
  const h = data[0];

  const colF = h.indexOf('Fecha_entrega');
  const colT = h.indexOf('Tarea');
  const colE = h.indexOf('Estado');

  let vencidas = [];

  for (let i = 1; i < data.length; i++) {
    let fecha = data[i][colF];
    let estado = data[i][colE];

    if (fecha instanceof Date && fecha < hoy && estado !== "Hecha") {
      vencidas.push(data[i][colT]);
    }
  }

  if (vencidas.length === 0) return;

  MailApp.sendEmail({
    to: Session.getActiveUser().getEmail(),
    subject: "⚠️ PMV: tareas vencidas",
    htmlBody: "<b>Tareas vencidas:</b><br><br>" + vencidas.join("<br>")
  });
}

function pmv_reporteSemanal() {
  const sheet = sh();
  const data = sheet.getDataRange().getValues();
  const h = data[0];

  const col = {
    tarea: h.indexOf('Tarea'),
    estado: h.indexOf('Estado'),
    proyecto: h.indexOf('Proyecto'),
    prioridad: h.indexOf('Prioridad')
  };

  let hechas = [];
  let pendientes = [];

  for (let i = 1; i < data.length; i++) {
    let row = data[i];
    if (row[col.estado] === "Hecha") hechas.push(row[col.tarea]);
    else pendientes.push(row[col.tarea]);
  }

  MailApp.sendEmail({
    to: Session.getActiveUser().getEmail(),
    subject: "📊 PMV – Reporte semanal",
    htmlBody: "<h2>Reporte semanal</h2>" +
      "<b>Completadas:</b><br>" + (hechas.join("<br>") || "Ninguna") + "<br><br>" +
      "<b>Pendientes:</b><br>" + (pendientes.join("<br>") || "Ninguna")
  });
}
