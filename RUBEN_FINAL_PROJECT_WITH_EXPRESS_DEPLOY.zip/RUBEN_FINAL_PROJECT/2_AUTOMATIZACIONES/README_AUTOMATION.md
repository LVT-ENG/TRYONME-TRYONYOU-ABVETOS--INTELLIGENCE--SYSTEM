# Automatizaciones PMV

Esta carpeta contiene el script principal de Apps Script y una posible separación lógica por módulos.

Pasos para usar en Google Sheets:
1. Crear una hoja con pestaña `TAREAS` y columnas según `1_PMV_DASHBOARD/README_DASHBOARD.md`.
2. Ir a Extensiones → Apps Script.
3. Pegar el contenido de `apps_script_full.js` en el editor.
4. Configurar los triggers sugeridos (cron).
