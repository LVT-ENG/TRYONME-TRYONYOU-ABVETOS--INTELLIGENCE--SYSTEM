# Limitaciones para el rol de usuario (Rubén)

- No debe poder editar scripts ni configuraciones técnicas.
- No debe tocar configuraciones de despliegue.
- No debe tener acceso a claves/API.
