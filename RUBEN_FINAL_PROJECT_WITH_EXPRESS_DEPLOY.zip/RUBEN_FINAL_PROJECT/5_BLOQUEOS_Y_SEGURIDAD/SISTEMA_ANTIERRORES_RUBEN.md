# Sistema anti‑errores – Rubén

Objetivo: que el usuario Rubén no pueda romper el sistema accidentalmente.

Recomendaciones:
- Proteger celdas críticas en el PMV (Google Sheets).
- Dar a Rubén solo permisos de edición donde haga falta.
- Proteger ramas principales del repo (main/master).
- Usar entornos separados: desarrollo / staging / producción.
