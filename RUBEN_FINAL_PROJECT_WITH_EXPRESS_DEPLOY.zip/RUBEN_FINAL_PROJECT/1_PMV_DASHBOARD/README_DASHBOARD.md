# PMV Dashboard – Estructura

Esta carpeta define el dashboard maestro que se implementará en Google Sheets.

Columnas recomendadas en la pestaña `TAREAS`:
- ID
- Proyecto
- Tarea
- Responsable
- Prioridad (Alta / Media / Baja)
- Fecha_inicio
- Fecha_entrega
- Estimación_horas
- Estado (Pendiente / En curso / Bloqueada / Hecha)
- Bloqueo
- Recordatorio (Sí / No)
- En_Calendar

El archivo `ejemplos_de_tareas.csv` contiene filas de ejemplo para importar.
