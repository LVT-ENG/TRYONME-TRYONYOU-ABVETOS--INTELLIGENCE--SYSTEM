# Manual de uso – Rubén

1. Usa el dashboard (PMV) para ver el estado del proyecto.
2. Añade tareas nuevas desde las filas vacías marcadas para ello.
3. No modifiques fórmulas ni columnas protegidas.
4. Usa la demo/interfaz de TRYONYOU que te prepare el desarrollador.
5. Si algo deja de funcionar, contacta al desarrollador en lugar de tocar scripts o código.
