# Instrucciones para desarrollador

Público objetivo: desarrollador full‑stack con experiencia en:
- JavaScript/TypeScript (Node.js)
- Frontend (React u otro framework SPA)
- Integración con APIs (Google Apps Script, Google Calendar)

## Pasos recomendados

1. Revisar `PROYECTO_GENERAL.md` y `README_MASTER.md`.
2. Abrir `1_PMV_DASHBOARD/README_DASHBOARD.md` para entender el flujo del PMV.
3. Revisar `2_AUTOMATIZACIONES/apps_script_full.js` y adaptarlo a la cuenta de Google de Rubén.
4. Usar la estructura de `3_TRYONYOU_SYSTEM` como base del producto:
   - Completar backend (rutas reales, modelos de datos, lógica de negocio).
   - Completar frontend (pantallas, formularios, flujo de usuario).
   - Conectar motor de IA (`ai_engine`) a proveedores/modelos reales.
5. Revisar carpeta `4_DEPLOY` y elegir estrategia (Docker, plataforma PaaS, etc.).
6. Aplicar las recomendaciones de `5_BLOQUEOS_Y_SEGURIDAD` para que Rubén no pueda romper nada accidentalmente.

IMPORTANTE:
- Documentar cualquier decisión técnica extra en un `CHANGELOG.md` o similar.
- Mantener la experiencia de Rubén lo más simple posible (un panel + una demo de TRYONYOU).
