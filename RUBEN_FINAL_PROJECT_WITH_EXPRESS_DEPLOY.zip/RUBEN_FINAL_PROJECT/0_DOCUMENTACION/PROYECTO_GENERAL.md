# Proyecto Final Rubén – Visión General

El objetivo de este proyecto es crear un sistema que:
- Gestione el proyecto de forma automática (PMV).
- Soporte el producto TRYONYOU (compra de ropa sin errores de talla).
- Minimice la intervención técnica del usuario final (Rubén).

Componentes principales:
- PMV_DASHBOARD: gestión de tareas y automatizaciones.
- AUTOMATIZACIONES: Apps Script / servicios de backend ligeros.
- TRYONYOU_SYSTEM: backend + frontend + motor de IA.
- DEPLOY: ficheros base para despliegue (Docker / pipeline).
- BLOQUEOS_Y_SEGURIDAD: lineamientos para proteger el sistema.
