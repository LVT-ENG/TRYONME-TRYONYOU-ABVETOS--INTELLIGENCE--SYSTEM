# Proyecto Final Rubén – Entrega para desarrollador

Este paquete contiene:
- PMV (Project Manager Virtual) basado en Google Sheets + Apps Script.
- Estructura funcional para el sistema TRYONYOU (backend, frontend, IA).
- Automatizaciones (alertas, reportes, sincronización con Calendar).
- Carpeta de documentación para entender y continuar el proyecto.
- Carpeta de seguridad/bloqueos con especificaciones de qué no debe tocar el usuario final (Rubén).

## Objetivo
Que cualquier desarrollador pueda:
1. Revisar la documentación.
2. Conectar el dashboard PMV a la cuenta de Google de Rubén.
3. Ajustar y desplegar TRYONYOU sobre esta base.
4. Dejar todo automatizado y estable.

Rubén no debería tocar nada técnico. Solo usar el dashboard y la interfaz que el desarrollador entregue.
