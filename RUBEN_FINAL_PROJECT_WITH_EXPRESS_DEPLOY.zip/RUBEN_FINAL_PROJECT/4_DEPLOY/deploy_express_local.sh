#!/usr/bin/env bash
# Script de arranque rápido en local para backend Express TRYONYOU

set -e

echo ">> Ir a carpeta de backend"
cd "$(dirname "$0")/../3_TRYONYOU_SYSTEM/backend"

echo ">> Instalando dependencias (si faltan)..."
npm install || echo "Revisa package.json para ajustar dependencias."

echo ">> Lanzando servidor en puerto 3000..."
node server.js
