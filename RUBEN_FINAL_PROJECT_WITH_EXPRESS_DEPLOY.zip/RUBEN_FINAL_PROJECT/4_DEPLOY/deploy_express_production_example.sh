#!/usr/bin/env bash
# Ejemplo de deploy exprés en servidor para backend Express TRYONYOU

set -e

echo ">> Actualizando código (suponiendo repo ya clonado)"
# git pull origin main  # Descomentar cuando se use un repo real

echo ">> Entrando a backend TRYONYOU"
cd "$(dirname "$0")/../3_TRYONYOU_SYSTEM/backend"

echo ">> Instalando dependencias..."
npm install

echo ">> Lanzando con pm2 (asegúrate de tener pm2 instalado: npm install -g pm2)"
pm2 delete tryonyou-backend 2>/dev/null || true
pm2 start server.js --name tryonyou-backend
pm2 save

echo ">> Deploy exprés completado. Servicio corriendo bajo pm2."
