# Despliegue – Guía básica

Esta carpeta contiene ficheros de ejemplo para un despliegue contenedorizado.

El desarrollador puede:
- Adaptar el Dockerfile al backend definido.
- Usar docker-compose para orquestar servicios (base de datos, backend, etc.).
- Usar `pipeline.yml` como referencia para CI/CD (GitHub Actions, GitLab CI, etc.).
