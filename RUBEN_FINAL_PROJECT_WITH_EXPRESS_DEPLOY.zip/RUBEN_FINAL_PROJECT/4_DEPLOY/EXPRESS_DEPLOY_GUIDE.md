# Guía de Deploy Exprés – TRYONYOU (backend Express)

Este backend está pensado para ejecutarse con Node.js + Express.

## 1. Desarrollo local rápido

Requisitos:
- Node.js 18+

Pasos:
1. Ir a la carpeta del backend:
   ```bash
   cd 3_TRYONYOU_SYSTEM/backend
   ```
2. Instalar dependencias (el desarrollador debe completar package.json si hace falta):
   ```bash
   npm install
   ```
3. Lanzar el servidor en modo desarrollo:
   ```bash
   npm run dev
   ```
   o bien:
   ```bash
   node server.js
   ```
4. El backend escuchará en el puerto 3000 (por defecto).

## 2. Deploy exprés en un VPS / servidor propio

Pasos genéricos:
1. Copiar el contenido de `3_TRYONYOU_SYSTEM/backend` al servidor.
2. Ejecutar en el servidor:
   ```bash
   npm install
   npm run build   # opcional, si se define
   npm run start   # o `node server.js`
   ```
3. Usar un process manager tipo `pm2` para que el servicio no caiga:
   ```bash
   npm install -g pm2
   pm2 start server.js --name tryonyou-backend
   pm2 save
   pm2 startup
   ```
4. Poner un reverse proxy delante (Nginx, Caddy, etc.) apuntando al puerto 3000.

## 3. Deploy exprés en plataformas PaaS (Railway, Render, etc.)

1. Crear proyecto nuevo en la plataforma elegida.
2. Conectar el repositorio que contenga esta estructura.
3. Establecer como directorio de trabajo: `3_TRYONYOU_SYSTEM/backend`.
4. Establecer comando de arranque, por ejemplo:
   ```
   npm install && node server.js
   ```
5. Configurar variables de entorno necesarias (cuando se definan).

## 4. Importante

- Este es un esqueleto: el desarrollador debe completar dependencias en package.json,
  modelos de datos y rutas reales.
- Objetivo: poder montar un backend Express funcional de forma rápida (deploy exprés).
