# TRYONYOU – Base técnica

Este directorio define una base para que un desarrollador construya el sistema TRYONYOU:
- backend: API + lógica de negocio.
- frontend: interfaz de usuario.
- ai_engine: componentes de IA para recomendación de tallas / outfits.

El código incluido es solo esqueletal / de ejemplo. Se espera que el desarrollador:
- Defina modelos de datos reales (usuarios, prendas, tallas, historiales, etc.).
- Implemente endpoints y reglas de negocio.
- Conecte el motor de IA con servicios/productos reales.
