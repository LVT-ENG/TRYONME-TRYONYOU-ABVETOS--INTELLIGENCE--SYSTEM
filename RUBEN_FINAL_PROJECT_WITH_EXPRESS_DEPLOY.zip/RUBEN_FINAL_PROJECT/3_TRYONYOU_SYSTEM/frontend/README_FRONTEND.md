# Frontend TRYONYOU

Sugerencia tecnológica:
- React / Next.js (o framework SPA similar).

Requisitos básicos:
- Pantalla de inicio + explicación del producto.
- Flujo de selección de prenda / talla recomendada.
- Opcional: prueba visual / mock de try-on.
