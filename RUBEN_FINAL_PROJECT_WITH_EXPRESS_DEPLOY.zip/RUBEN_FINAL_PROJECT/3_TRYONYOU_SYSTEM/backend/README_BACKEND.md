# Backend TRYONYOU

Sugerencia tecnológica:
- Node.js + Express
- Base de datos (PostgreSQL / MongoDB, a elección del desarrollador)

Este backend deberá:
- Gestionar usuarios, prendas, armarios virtuales.
- Exponer endpoints para recomendaciones de talla / outfit.
- Consumir el motor de IA ubicado en `../ai_engine`.
