// Backend base para TRYONYOU – Node.js / Express (ejemplo)
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'tryonyou-backend' });
});

// TODO: añadir rutas reales (usuarios, prendas, recomendaciones…)

app.listen(PORT, () => {
  console.log(`TRYONYOU backend escuchando en puerto ${PORT}`);
});
