# Motor de IA – TRYONYOU

Este directorio debe albergar:
- Modelos de recomendación de talla.
- Lógica para combinar preferencias, medidas y tallaje de marca.

El archivo `recomendador_de_tallas.py` es una base mínima para que el desarrollador construya el motor real.
