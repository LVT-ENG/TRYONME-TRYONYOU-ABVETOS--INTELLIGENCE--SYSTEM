# Recomendador de tallas – bosquecillo de ejemplo

def recomendar_talla(datos_usuario, datos_prenda):
    """Devuelve una talla recomendada.

    datos_usuario: dict con medidas, peso, altura, preferencias.
    datos_prenda: dict con tabla de tallas, tipo de prenda, etc.
    """
    # TODO: implementar lógica real.
    return "M"

if __name__ == "__main__":
    ejemplo_usuario = {"altura_cm": 175, "peso_kg": 70}
    ejemplo_prenda = {"tipo": "pantalón", "tabla_tallas": ["S", "M", "L"]}
    print(recomendar_talla(ejemplo_usuario, ejemplo_prenda))
