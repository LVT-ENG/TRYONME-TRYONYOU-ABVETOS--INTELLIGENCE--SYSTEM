#!/bin/bash

###############################################################################
# TRYONYOU Deploy Express
# Automated deployment pipeline with testing, Git, and notifications
###############################################################################

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="tryonyou-main"
TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-}"
TELEGRAM_CHAT_ID="${TELEGRAM_CHAT_ID:-}"
VERCEL_TOKEN="${VERCEL_TOKEN:-}"
VERCEL_ORG_ID="${VERCEL_ORG_ID:-}"
VERCEL_PROJECT_ID="${VERCEL_PROJECT_ID:-}"

###############################################################################
# Helper Functions
###############################################################################

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

send_telegram_notification() {
    local message="$1"
    
    if [ -z "$TELEGRAM_BOT_TOKEN" ] || [ -z "$TELEGRAM_CHAT_ID" ]; then
        log_warning "Telegram credentials not configured, skipping notification"
        return 0
    fi
    
    curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
        -d chat_id="${TELEGRAM_CHAT_ID}" \
        -d text="${message}" \
        -d parse_mode="HTML" > /dev/null
}

send_telegram_photo() {
    local photo_path="$1"
    local caption="$2"
    
    if [ -z "$TELEGRAM_BOT_TOKEN" ] || [ -z "$TELEGRAM_CHAT_ID" ]; then
        return 0
    fi
    
    if [ -f "$photo_path" ]; then
        curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendPhoto" \
            -F chat_id="${TELEGRAM_CHAT_ID}" \
            -F photo=@"${photo_path}" \
            -F caption="${caption}" > /dev/null
    fi
}

###############################################################################
# Main Deployment Steps
###############################################################################

step_banner() {
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${GREEN}$1${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
}

# Step 1: Build
build_project() {
    step_banner "📦 STEP 1: Building Project"
    
    log_info "Installing dependencies..."
    npm install
    
    log_info "Running build..."
    npm run build
    
    if [ -d "dist" ]; then
        log_success "Build completed successfully"
        return 0
    else
        log_error "Build failed - dist directory not found"
        return 1
    fi
}

# Step 2: Quick Test
quick_test() {
    step_banner "🧪 STEP 2: Quick Test"
    
    log_info "Checking build output..."
    
    # Check if critical files exist
    local critical_files=(
        "dist/index.html"
        "dist/assets"
    )
    
    for file in "${critical_files[@]}"; do
        if [ -e "dist/$file" ] || [ -e "$file" ]; then
            log_success "✓ Found: $file"
        else
            log_warning "✗ Missing: $file"
        fi
    done
    
    log_success "Quick test completed"
}

# Step 3: Git Operations
git_operations() {
    step_banner "📝 STEP 3: Git Operations"
    
    # Check if git is initialized
    if [ ! -d ".git" ]; then
        log_info "Initializing Git repository..."
        git init
        git branch -M main
    fi
    
    log_info "Adding files to Git..."
    git add .
    
    log_info "Creating commit..."
    local commit_message="Deploy: $(date '+%Y-%m-%d %H:%M:%S')"
    git commit -m "$commit_message" || log_warning "No changes to commit"
    
    # Push if remote exists
    if git remote get-url origin &> /dev/null; then
        log_info "Pushing to remote..."
        git push origin main || log_warning "Push failed or no remote configured"
    else
        log_warning "No Git remote configured, skipping push"
    fi
    
    log_success "Git operations completed"
}

# Step 4: Deploy
deploy_to_vercel() {
    step_banner "🚀 STEP 4: Deploying to Vercel"
    
    # Check if Vercel CLI is installed
    if ! command -v vercel &> /dev/null; then
        log_warning "Vercel CLI not found, installing..."
        npm install -g vercel
    fi
    
    log_info "Deploying to production..."
    
    if [ -n "$VERCEL_TOKEN" ]; then
        export VERCEL_TOKEN
        export VERCEL_ORG_ID
        export VERCEL_PROJECT_ID
        
        vercel --prod --yes --token="$VERCEL_TOKEN" || {
            log_error "Vercel deployment failed"
            return 1
        }
    else
        log_warning "VERCEL_TOKEN not set, attempting interactive deployment..."
        vercel --prod || {
            log_error "Vercel deployment failed"
            return 1
        }
    fi
    
    log_success "Deployment completed"
}

# Step 5: Capture Screenshots
capture_screenshots() {
    step_banner "📸 STEP 5: Capturing Screenshots"
    
    log_info "Screenshots would be captured here (requires headless browser)"
    log_info "Desktop: 1920x1080"
    log_info "Mobile: 375x812"
    
    # Placeholder for screenshot capture
    # In production, this would use Puppeteer or similar
    
    log_success "Screenshot capture completed"
}

# Step 6: Notify
send_notifications() {
    step_banner "📬 STEP 6: Sending Notifications"
    
    local commit_hash=$(git rev-parse --short HEAD 2>/dev/null || echo "N/A")
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    local message="<b>🚀 TRYONYOU Deployment Complete</b>

📦 Project: ${PROJECT_NAME}
⏰ Time: ${timestamp}
🔖 Commit: ${commit_hash}
✅ Status: Success

🌐 URL: https://tryonyou.app
"
    
    send_telegram_notification "$message"
    
    log_success "Notifications sent"
}

# Error Handler
handle_error() {
    local step="$1"
    local error_msg="$2"
    
    log_error "Deployment failed at: $step"
    log_error "Error: $error_msg"
    
    local commit_hash=$(git rev-parse --short HEAD 2>/dev/null || echo "N/A")
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    local error_notification="<b>❌ TRYONYOU Deployment Failed</b>

📦 Project: ${PROJECT_NAME}
⏰ Time: ${timestamp}
🔖 Commit: ${commit_hash}
❌ Failed at: ${step}
📝 Error: ${error_msg}
"
    
    send_telegram_notification "$error_notification"
    
    exit 1
}

###############################################################################
# Main Execution
###############################################################################

main() {
    echo ""
    echo "╔═══════════════════════════════════════════════════════════════════╗"
    echo "║                                                                   ║"
    echo "║              TRYONYOU DEPLOY EXPRESS v1.0.0                      ║"
    echo "║              Automated Deployment Pipeline                       ║"
    echo "║                                                                   ║"
    echo "╚═══════════════════════════════════════════════════════════════════╝"
    echo ""
    
    local start_time=$(date +%s)
    
    # Execute deployment steps
    build_project || handle_error "Build" "Build process failed"
    quick_test || handle_error "Test" "Quick test failed"
    git_operations || handle_error "Git" "Git operations failed"
    deploy_to_vercel || handle_error "Deploy" "Vercel deployment failed"
    capture_screenshots || log_warning "Screenshot capture skipped"
    send_notifications || log_warning "Notification sending failed"
    
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    echo ""
    echo "╔═══════════════════════════════════════════════════════════════════╗"
    echo "║                                                                   ║"
    echo "║              ✅ DEPLOYMENT SUCCESSFUL ✅                          ║"
    echo "║                                                                   ║"
    echo "║              Total Time: ${duration}s                                  ║"
    echo "║              Project: ${PROJECT_NAME}                            ║"
    echo "║                                                                   ║"
    echo "╚═══════════════════════════════════════════════════════════════════╝"
    echo ""
}

# Run main function
main "$@"
