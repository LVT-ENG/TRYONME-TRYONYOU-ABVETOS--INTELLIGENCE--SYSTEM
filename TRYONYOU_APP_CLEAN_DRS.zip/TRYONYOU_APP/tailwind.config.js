/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // DRS-TRYONYOU v1.0 - Official Color System
        tryonyou: {
          // Primary palette: anthracite, gold, bone-white
          anthracite: '#2B2D2F',
          'anthracite-light': '#3A3C3E',
          'anthracite-dark': '#1A1C1E',
          gold: '#D4AF37',
          'gold-light': '#E5C158',
          'gold-dark': '#B8941F',
          'bone-white': '#F5F5DC',
          'bone-white-dark': '#E8E8D0',
          
          // Secondary palette
          blue: '#00A8E8',
          darkblue: '#003459',
          metallic: '#8B92A0',
          silver: '#C0C0C0',
          black: '#0A0A0A',
          smoke: '#1A1A2E',
        },
        // Amparo / OneShot Light style
        amparo: {
          light: '#00D9FF',
          medium: '#00A8CC',
          dark: '#0077B6',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Orbitron', 'sans-serif'],
      },
      backgroundImage: {
        // DRS-TRYONYOU v1.0 - Futuristic showroom gradients
        'showroom': "linear-gradient(135deg, #1A1C1E 0%, #2B2D2F 50%, #3A3C3E 100%)",
        'showroom-gold': "linear-gradient(135deg, #2B2D2F 0%, #D4AF37 50%, #2B2D2F 100%)",
        'metallic': "linear-gradient(135deg, #8B92A0 0%, #C0C0C0 100%)",
        'peacock': "radial-gradient(circle, #00A8E8 0%, #003459 50%, #1A1C1E 100%)",
        'amparo-light': "linear-gradient(135deg, #00D9FF 0%, #00A8CC 50%, #0077B6 100%)",
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'shimmer': 'shimmer 2.5s linear infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        glow: {
          '0%': { boxShadow: '0 0 5px #00A8E8, 0 0 10px #00A8E8' },
          '100%': { boxShadow: '0 0 20px #00A8E8, 0 0 30px #00A8E8, 0 0 40px #00A8E8' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-1000px 0' },
          '100%': { backgroundPosition: '1000px 0' },
        },
      },
    },
  },
  plugins: [],
}
