import { motion } from 'framer-motion'
import { Building2, Users, Rocket, Award, Download, ExternalLink, FileText, Presentation } from 'lucide-react'

const StationF = () => {
  const stats = [
    { label: 'Startups', value: '1000+', icon: Building2 },
    { label: 'Programs', value: '30+', icon: Rocket },
    { label: 'Countries', value: '120+', icon: Users },
    { label: 'Success Rate', value: '85%', icon: Award },
  ]

  const documents = [
    {
      title: 'Executive Summary',
      description: 'Comprehensive overview of TRYONYOU platform and technology',
      icon: FileText,
      type: 'PDF',
      size: '2.4 MB',
    },
    {
      title: 'Technical Presentation',
      description: 'Detailed technical architecture and implementation details',
      icon: Presentation,
      type: 'PPTX',
      size: '15.8 MB',
    },
    {
      title: 'Business Model',
      description: 'Revenue streams, market analysis, and growth strategy',
      icon: FileText,
      type: 'PDF',
      size: '1.9 MB',
    },
    {
      title: 'Demo Showcase',
      description: 'Interactive demonstration of core platform features',
      icon: Presentation,
      type: 'HTML',
      size: '5.2 MB',
    },
  ]

  const milestones = [
    {
      year: '2023',
      title: 'Platform Launch',
      description: 'Initial release of TRYONYOU virtual try-on technology',
    },
    {
      year: '2024',
      title: 'Station-F Partnership',
      description: 'Accepted into Station-F accelerator program',
    },
    {
      year: '2024',
      title: 'DSX Engine Release',
      description: 'Launch of proprietary rendering engine for real-time processing',
    },
    {
      year: '2025',
      title: 'Global Expansion',
      description: 'Scaling operations across Europe, Asia, and Americas',
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-purple-900 via-tryonyou-darkblue to-tryonyou-black">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-10" />
        </div>

        <div className="relative z-10 section-container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-block px-4 py-2 rounded-full glass mb-6">
              <span className="text-purple-300 font-semibold">Station-F Partnership</span>
            </div>
            
            <h1 className="heading-xl mb-6">
              <span className="gradient-text">TRYONYOU</span>
              <br />
              <span className="text-white">at Station-F</span>
            </h1>
            
            <p className="text-xl text-white/80 max-w-3xl mx-auto mb-8">
              The world&apos;s largest startup campus in Paris, France. Join us as we revolutionize 
              the fashion industry with AI-powered virtual try-on technology.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <button className="btn-primary">
                <Download className="inline mr-2" size={20} />
                Download Press Kit
              </button>
              <a 
                href="https://stationf.co" 
                target="_blank" 
                rel="noopener noreferrer"
                className="btn-metallic"
              >
                Visit Station-F
                <ExternalLink className="inline ml-2" size={20} />
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section-container bg-tryonyou-smoke/30">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-center"
            >
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-4">
                <stat.icon size={32} />
              </div>
              <div className="text-4xl font-bold gradient-text mb-2">{stat.value}</div>
              <div className="text-white/60">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="heading-lg mb-8 text-center gradient-text">
            About Station-F
          </h2>
          <div className="space-y-6 text-lg text-white/80">
            <p>
              Station-F is the world&apos;s largest startup campus, located in the heart of Paris, France. 
              Founded by Xavier Niel in 2017, it has become a global hub for innovation and entrepreneurship, 
              hosting over 1,000 startups and 30+ programs under one roof.
            </p>
            <p>
              As part of the Station-F ecosystem, TRYONYOU has access to world-class resources, mentorship, 
              and networking opportunities that accelerate our mission to transform the fashion industry 
              through AI-powered virtual try-on technology.
            </p>
            <p>
              Our presence at Station-F validates our innovative approach and positions us at the forefront 
              of the fashion-tech revolution, alongside some of the most promising startups in Europe.
            </p>
          </div>
        </motion.div>
      </section>

      {/* Documents Section */}
      <section className="section-container bg-tryonyou-smoke/30">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Documentation & Resources
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {documents.map((doc, index) => (
              <motion.div
                key={doc.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="card group cursor-pointer"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                    <doc.icon size={24} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="text-xl font-bold group-hover:text-tryonyou-blue transition-colors">
                        {doc.title}
                      </h3>
                      <span className="text-xs px-2 py-1 rounded bg-tryonyou-blue/20 text-tryonyou-blue">
                        {doc.type}
                      </span>
                    </div>
                    <p className="text-white/60 text-sm mb-3">{doc.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-white/40">{doc.size}</span>
                      <button className="text-tryonyou-blue text-sm font-semibold flex items-center group-hover:gap-2 transition-all">
                        Download
                        <Download size={16} className="ml-1 group-hover:translate-y-0.5 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Timeline Section */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Our Journey
          </h2>
          <div className="max-w-3xl mx-auto">
            {milestones.map((milestone, index) => (
              <motion.div
                key={milestone.year}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="relative pl-8 pb-12 border-l-2 border-tryonyou-blue/30 last:pb-0"
              >
                <div className="absolute left-0 top-0 w-4 h-4 rounded-full bg-tryonyou-blue transform -translate-x-[9px] glow-blue" />
                <div className="text-sm text-tryonyou-blue font-semibold mb-2">{milestone.year}</div>
                <h3 className="text-xl font-bold mb-2">{milestone.title}</h3>
                <p className="text-white/60">{milestone.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="section-container bg-gradient-to-br from-purple-900/50 to-tryonyou-darkblue/50">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="heading-lg mb-6 gradient-text">
            Interested in Learning More?
          </h2>
          <p className="text-lg text-white/80 mb-8">
            Get in touch with our team to explore partnership opportunities
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href="mailto:hello@tryonyou.app" className="btn-primary">
              Contact Us
            </a>
            <button className="btn-metallic">
              Schedule a Demo
            </button>
          </div>
        </motion.div>
      </section>
    </div>
  )
}

export default StationF
