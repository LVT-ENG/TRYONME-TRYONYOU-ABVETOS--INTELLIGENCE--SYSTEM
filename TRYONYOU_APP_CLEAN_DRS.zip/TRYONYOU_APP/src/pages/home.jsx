import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowRight, Sparkles, Zap, Shield, Users, Shirt, Brain, Palette } from 'lucide-react'

const Home = () => {
  const modules = [
    {
      title: 'Station-F',
      description: 'Official presentation and documentation for the world\'s largest startup campus',
      icon: Sparkles,
      path: '/station-f',
      color: 'from-purple-500 to-pink-500',
    },
    {
      title: 'ABVETOS Factory',
      description: 'Advanced AI-powered garment creation and customization system',
      icon: Palette,
      path: '/abvetos-factory',
      color: 'from-blue-500 to-cyan-500',
    },
    {
      title: 'Smart Wardrobe',
      description: 'Intelligent wardrobe management with AI styling recommendations',
      icon: Shirt,
      path: '/smart-wardrobe',
      color: 'from-green-500 to-emerald-500',
    },
    {
      title: 'CAP System',
      description: 'Automated content creation and processing engine',
      icon: Zap,
      path: '/cap-system',
      color: 'from-orange-500 to-red-500',
    },
    {
      title: 'Avatar PAU',
      description: 'AI-powered virtual assistant with "I am from the world" personality',
      icon: Brain,
      path: '/pau',
      color: 'from-indigo-500 to-purple-500',
    },
  ]

  const features = [
    {
      icon: Brain,
      title: 'AI-Powered',
      description: 'Advanced machine learning algorithms for precise virtual try-on experiences',
    },
    {
      icon: Zap,
      title: 'Real-Time Processing',
      description: 'Instant results with our optimized DSX rendering engine',
    },
    {
      icon: Shield,
      title: 'Secure & Private',
      description: 'Your data is protected with enterprise-grade security',
    },
    {
      icon: Users,
      title: 'Community Driven',
      description: 'Join thousands of users transforming the fashion industry',
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section - "Frontón" */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-showroom">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-tryonyou-blue/20 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amparo-light/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-tryonyou-darkblue/10 rounded-full blur-3xl animate-pulse" />
        </div>

        {/* Content */}
        <div className="relative z-10 section-container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Main Logo/Symbol */}
            <motion.div
              className="mb-8 flex justify-center"
              animate={{ 
                rotate: [0, 5, -5, 0],
                scale: [1, 1.05, 1]
              }}
              transition={{ 
                duration: 6,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-tryonyou-metallic via-tryonyou-silver to-tryonyou-gold flex items-center justify-center glow-blue">
                <svg viewBox="0 0 100 100" fill="none" className="w-24 h-24">
                  <circle cx="50" cy="50" r="45" fill="url(#hero-peacock-gradient)" />
                  <circle cx="50" cy="50" r="35" fill="#003459" />
                  <circle cx="50" cy="50" r="25" fill="url(#hero-inner-gradient)" />
                  <path d="M50 25 L60 40 L50 37.5 L40 40 Z" fill="#00A8E8" />
                  <path d="M50 75 L42.5 65 L50 67.5 L57.5 65 Z" fill="#00A8E8" />
                  <circle cx="50" cy="50" r="8" fill="#D4AF37" />
                  <defs>
                    <linearGradient id="hero-peacock-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#8B92A0" />
                      <stop offset="50%" stopColor="#C0C0C0" />
                      <stop offset="100%" stopColor="#8B92A0" />
                    </linearGradient>
                    <radialGradient id="hero-inner-gradient">
                      <stop offset="0%" stopColor="#00A8E8" />
                      <stop offset="100%" stopColor="#003459" />
                    </radialGradient>
                  </defs>
                </svg>
              </div>
            </motion.div>

            {/* Main Title */}
            <h1 className="heading-xl mb-6 gradient-text">
              TRYONYOU
            </h1>
            
            <p className="text-xl md:text-2xl text-white/80 mb-4 max-w-3xl mx-auto">
              Experience the Future of Fashion
            </p>
            
            <p className="text-lg text-white/60 mb-12 max-w-2xl mx-auto">
              AI-Powered Virtual Try-On Platform transforming how you discover, style, and wear fashion
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap justify-center gap-4 mb-16">
              <Link to="/station-f" className="btn-primary text-lg px-8 py-4">
                View Station-F Demo
                <ArrowRight className="inline ml-2" size={20} />
              </Link>
              <Link to="/abvetos-factory" className="btn-metallic text-lg px-8 py-4">
                Explore ABVETOS Factory
              </Link>
            </div>

            {/* Module Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {modules.map((module, index) => (
                <motion.div
                  key={module.path}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 + 0.3 }}
                >
                  <Link to={module.path} className="block group">
                    <div className="card h-full hover:scale-105 transition-transform duration-300">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${module.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                        <module.icon size={24} className="text-white" />
                      </div>
                      <h3 className="text-xl font-bold mb-2 group-hover:text-tryonyou-blue transition-colors">
                        {module.title}
                      </h3>
                      <p className="text-white/60 text-sm">
                        {module.description}
                      </p>
                      <div className="mt-4 flex items-center text-tryonyou-blue text-sm font-semibold">
                        Learn More
                        <ArrowRight size={16} className="ml-2 group-hover:translate-x-2 transition-transform" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
            <div className="w-1 h-3 bg-white/60 rounded-full" />
          </div>
        </motion.div>
      </section>

      {/* What is TRYONYOU Section */}
      <section className="section-container bg-tryonyou-smoke/30">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="heading-lg mb-6 gradient-text">
            What is TRYONYOU?
          </h2>
          <p className="text-lg text-white/80 mb-6 leading-relaxed">
            TRYONYOU is a revolutionary AI-powered virtual try-on platform that transforms the fashion industry. 
            Using cutting-edge computer vision and machine learning technologies, we enable users to virtually 
            try on clothing with unprecedented accuracy and realism.
          </p>
          <p className="text-lg text-white/80 leading-relaxed">
            Our platform combines advanced modules including the ABVETOS Factory for garment creation, 
            Smart Wardrobe for intelligent styling, CAP System for automated content generation, 
            and Avatar PAU for personalized assistance—all powered by our proprietary DSX rendering engine.
          </p>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            How It Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-tryonyou-blue to-tryonyou-darkblue flex items-center justify-center mx-auto mb-4 glow-blue">
                  <feature.icon size={32} />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-white/60">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Video Demo Section */}
      <section className="section-container bg-tryonyou-smoke/30">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-5xl mx-auto"
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            See TRYONYOU in Action
          </h2>
          <div className="relative aspect-video rounded-2xl overflow-hidden glass border-2 border-tryonyou-blue/30 glow-blue">
            <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-tryonyou-darkblue to-tryonyou-black">
              <div className="text-center">
                <div className="w-20 h-20 rounded-full bg-tryonyou-blue/20 flex items-center justify-center mx-auto mb-4 cursor-pointer hover:bg-tryonyou-blue/30 transition-colors">
                  <svg className="w-10 h-10 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
                <p className="text-white/60">Demo Video Coming Soon</p>
                <p className="text-sm text-white/40 mt-2">Powered by PixVerse AI</p>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="heading-lg mb-6 gradient-text">
            Ready to Transform Your Fashion Experience?
          </h2>
          <p className="text-lg text-white/80 mb-8">
            Join the future of virtual try-on technology today
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/station-f" className="btn-primary text-lg px-8 py-4">
              Get Started
              <ArrowRight className="inline ml-2" size={20} />
            </Link>
            <a href="mailto:hello@tryonyou.app" className="btn-metallic text-lg px-8 py-4">
              Contact Us
            </a>
          </div>
        </motion.div>
      </section>
    </div>
  )
}

export default Home
