import { useState } from 'react'
import { motion } from 'framer-motion'
import { Shirt, Heart, TrendingUp, Calendar, ShoppingBag, Gift, Sparkles, Plus, Search } from 'lucide-react'

const SmartWardrobe = () => {
  const [activeTab, setActiveTab] = useState('intelligent')

  const features = [
    {
      icon: Sparkles,
      title: 'AI Styling',
      description: 'Get personalized outfit recommendations based on your style preferences',
    },
    {
      icon: Calendar,
      title: 'Outfit Planning',
      description: 'Plan your outfits for the week with smart calendar integration',
    },
    {
      icon: TrendingUp,
      title: 'Trend Analysis',
      description: 'Stay updated with the latest fashion trends and suggestions',
    },
    {
      icon: ShoppingBag,
      title: 'Smart Shopping',
      description: 'Get recommendations for pieces that complement your wardrobe',
    },
  ]

  const wardrobeItems = [
    { id: 1, name: 'Blue Denim Jacket', category: 'Outerwear', color: '#4A90E2', season: 'Spring' },
    { id: 2, name: 'White Cotton Shirt', category: 'Tops', color: '#FFFFFF', season: 'All' },
    { id: 3, name: 'Black Slim Jeans', category: 'Bottoms', color: '#1A1A1A', season: 'All' },
    { id: 4, name: 'Red Knit Sweater', category: 'Tops', color: '#E74C3C', season: 'Winter' },
    { id: 5, name: 'Grey Wool Coat', category: 'Outerwear', color: '#95A5A6', season: 'Winter' },
    { id: 6, name: 'Summer Floral Dress', category: 'Dresses', color: '#F39C12', season: 'Summer' },
  ]

  const outfitSuggestions = [
    {
      id: 1,
      name: 'Casual Weekend',
      items: ['Blue Denim Jacket', 'White Cotton Shirt', 'Black Slim Jeans'],
      occasion: 'Casual',
    },
    {
      id: 2,
      name: 'Winter Warmth',
      items: ['Grey Wool Coat', 'Red Knit Sweater', 'Black Slim Jeans'],
      occasion: 'Cold Weather',
    },
    {
      id: 3,
      name: 'Summer Breeze',
      items: ['Summer Floral Dress', 'White Cotton Shirt'],
      occasion: 'Warm Weather',
    },
  ]

  const solidarityPrograms = [
    {
      title: 'Donate Your Clothes',
      description: 'Give your gently used clothes a second life by donating to those in need',
      icon: Gift,
      impact: '1,234 items donated',
    },
    {
      title: 'Solidarity Marketplace',
      description: 'Buy and sell pre-loved fashion items with proceeds supporting charity',
      icon: ShoppingBag,
      impact: '€45,678 raised',
    },
    {
      title: 'Community Closet',
      description: 'Share your wardrobe with your community and borrow from others',
      icon: Heart,
      impact: '567 active members',
    },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-green-900 via-emerald-900 to-tryonyou-black">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-emerald-500/20 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-green-500/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        </div>

        <div className="relative z-10 section-container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-block px-4 py-2 rounded-full glass mb-6">
              <span className="text-emerald-300 font-semibold">Intelligent Wardrobe Management</span>
            </div>
            
            <h1 className="heading-xl mb-6 gradient-text">
              Smart Wardrobe
            </h1>
            
            <p className="text-xl text-white/80 max-w-3xl mx-auto mb-8">
              Intelligent wardrobe management with AI styling recommendations. 
              Organize, style, and share your fashion with purpose.
            </p>

            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <button
                onClick={() => setActiveTab('intelligent')}
                className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                  activeTab === 'intelligent'
                    ? 'bg-tryonyou-blue text-white'
                    : 'glass text-white/80 hover:text-white'
                }`}
              >
                <Shirt className="inline mr-2" size={20} />
                Intelligent Wardrobe
              </button>
              <button
                onClick={() => setActiveTab('solidarity')}
                className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                  activeTab === 'solidarity'
                    ? 'bg-tryonyou-blue text-white'
                    : 'glass text-white/80 hover:text-white'
                }`}
              >
                <Heart className="inline mr-2" size={20} />
                Solidarity Wardrobe
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Intelligent Wardrobe Section */}
      {activeTab === 'intelligent' && (
        <>
          {/* Features */}
          <section className="section-container bg-tryonyou-smoke/30">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="heading-lg mb-12 text-center gradient-text">
                Intelligent Features
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {features.map((feature, index) => (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="text-center"
                  >
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center mx-auto mb-4">
                      <feature.icon size={32} />
                    </div>
                    <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                    <p className="text-white/60">{feature.description}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </section>

          {/* My Wardrobe */}
          <section className="section-container">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <div className="flex items-center justify-between mb-12">
                <h2 className="heading-lg gradient-text">
                  My Wardrobe
                </h2>
                <div className="flex gap-4">
                  <button className="glass px-4 py-2 rounded-lg flex items-center">
                    <Search size={20} className="mr-2" />
                    Search
                  </button>
                  <button className="btn-primary">
                    <Plus size={20} className="mr-2" />
                    Add Item
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {wardrobeItems.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="card group cursor-pointer"
                  >
                    <div
                      className="w-full h-48 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden"
                      style={{
                        backgroundColor: item.color,
                        boxShadow: `0 0 30px ${item.color}30`
                      }}
                    >
                      <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent" />
                      <Shirt size={64} className="relative z-10 text-white/80" />
                    </div>
                    <h3 className="text-lg font-bold mb-2 group-hover:text-tryonyou-blue transition-colors">
                      {item.name}
                    </h3>
                    <div className="flex items-center justify-between text-sm text-white/60">
                      <span>{item.category}</span>
                      <span>{item.season}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </section>

          {/* Outfit Suggestions */}
          <section className="section-container bg-tryonyou-smoke/30">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="heading-lg mb-12 text-center gradient-text">
                AI Outfit Suggestions
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
                {outfitSuggestions.map((outfit, index) => (
                  <motion.div
                    key={outfit.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="card group cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-bold group-hover:text-tryonyou-blue transition-colors">
                        {outfit.name}
                      </h3>
                      <Sparkles size={20} className="text-tryonyou-blue" />
                    </div>
                    <div className="space-y-2 mb-4">
                      {outfit.items.map((item, i) => (
                        <div key={i} className="flex items-center text-sm text-white/60">
                          <div className="w-2 h-2 rounded-full bg-tryonyou-blue mr-2" />
                          {item}
                        </div>
                      ))}
                    </div>
                    <div className="pt-4 border-t border-white/10">
                      <span className="text-xs px-3 py-1 rounded-full bg-tryonyou-blue/20 text-tryonyou-blue">
                        {outfit.occasion}
                      </span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </section>
        </>
      )}

      {/* Solidarity Wardrobe Section */}
      {activeTab === 'solidarity' && (
        <>
          <section className="section-container bg-tryonyou-smoke/30">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto text-center mb-16"
            >
              <h2 className="heading-lg mb-6 gradient-text">
                Fashion with Purpose
              </h2>
              <p className="text-lg text-white/80 leading-relaxed">
                Join our solidarity movement to make fashion more sustainable and accessible. 
                Donate, share, and support communities through your wardrobe choices. 
                Every item shared or donated makes a difference.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {solidarityPrograms.map((program, index) => (
                <motion.div
                  key={program.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="card group cursor-pointer"
                >
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <program.icon size={32} />
                  </div>
                  <h3 className="text-2xl font-bold mb-3 group-hover:text-tryonyou-blue transition-colors">
                    {program.title}
                  </h3>
                  <p className="text-white/60 mb-6">{program.description}</p>
                  <div className="pt-4 border-t border-white/10">
                    <div className="text-sm text-tryonyou-blue font-semibold">
                      {program.impact}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>

          {/* ADBET Integration */}
          <section className="section-container">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="max-w-5xl mx-auto"
            >
              <div className="card bg-gradient-to-br from-pink-900/30 to-rose-900/30 border-pink-500/30">
                <div className="text-center mb-8">
                  <h2 className="heading-lg mb-4 gradient-text">
                    Powered by ADBET Payments
                  </h2>
                  <p className="text-lg text-white/80">
                    Secure, transparent, and instant transactions for all solidarity marketplace activities
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 glass rounded-lg">
                    <div className="text-3xl font-bold text-tryonyou-blue mb-2">100%</div>
                    <div className="text-white/60">Secure Transactions</div>
                  </div>
                  <div className="text-center p-6 glass rounded-lg">
                    <div className="text-3xl font-bold text-tryonyou-blue mb-2">€45K+</div>
                    <div className="text-white/60">Donated to Charity</div>
                  </div>
                  <div className="text-center p-6 glass rounded-lg">
                    <div className="text-3xl font-bold text-tryonyou-blue mb-2">2,500+</div>
                    <div className="text-white/60">Active Donors</div>
                  </div>
                </div>

                <div className="mt-8 text-center">
                  <button className="btn-primary">
                    Start Contributing
                  </button>
                </div>
              </div>
            </motion.div>
          </section>
        </>
      )}

      {/* CTA Section */}
      <section className="section-container bg-gradient-to-br from-green-900/50 to-emerald-900/50">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="heading-lg mb-6 gradient-text">
            Transform Your Wardrobe Today
          </h2>
          <p className="text-lg text-white/80 mb-8">
            Join thousands of users managing their fashion intelligently and sustainably
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="btn-primary">
              Get Started Free
            </button>
            <button className="btn-metallic">
              Learn More
            </button>
          </div>
        </motion.div>
      </section>
    </div>
  )
}

export default SmartWardrobe
