import { useState } from 'react'
import { motion } from 'framer-motion'
import { Zap, Code, Image, Video, FileText, Cpu, Database, Globe, Copy, Check } from 'lucide-react'

const CapSystem = () => {
  const [copiedEndpoint, setCopiedEndpoint] = useState(null)

  const features = [
    {
      icon: Zap,
      title: 'Automated Creation',
      description: 'Generate content automatically with AI-powered workflows',
    },
    {
      icon: Cpu,
      title: 'Smart Processing',
      description: 'Advanced algorithms for intelligent content optimization',
    },
    {
      icon: Database,
      title: 'Scalable Storage',
      description: 'Cloud-based storage with unlimited capacity',
    },
    {
      icon: Globe,
      title: 'Global CDN',
      description: 'Fast delivery worldwide with edge network distribution',
    },
  ]

  const contentTypes = [
    { type: 'Images', icon: Image, count: '12,456', color: 'from-blue-500 to-cyan-500' },
    { type: 'Videos', icon: Video, count: '3,789', color: 'from-purple-500 to-pink-500' },
    { type: 'Documents', icon: FileText, count: '8,234', color: 'from-green-500 to-emerald-500' },
    { type: 'Code', icon: Code, count: '5,678', color: 'from-orange-500 to-red-500' },
  ]

  const endpoints = [
    {
      method: 'POST',
      path: '/api/v1/cap/create',
      description: 'Create new content automatically',
      params: ['type', 'template', 'data'],
    },
    {
      method: 'GET',
      path: '/api/v1/cap/process/:id',
      description: 'Process and optimize existing content',
      params: ['id', 'options'],
    },
    {
      method: 'GET',
      path: '/api/v1/cap/gallery',
      description: 'Retrieve content gallery with filters',
      params: ['type', 'limit', 'offset'],
    },
    {
      method: 'PUT',
      path: '/api/v1/cap/update/:id',
      description: 'Update content metadata and settings',
      params: ['id', 'metadata'],
    },
    {
      method: 'DELETE',
      path: '/api/v1/cap/delete/:id',
      description: 'Delete content from the system',
      params: ['id'],
    },
  ]

  const gallery = [
    { id: 1, title: 'Product Showcase', type: 'image', thumbnail: '#4A90E2' },
    { id: 2, title: 'Brand Video', type: 'video', thumbnail: '#E74C3C' },
    { id: 3, title: 'Marketing Copy', type: 'document', thumbnail: '#2ECC71' },
    { id: 4, title: 'Hero Banner', type: 'image', thumbnail: '#F39C12' },
    { id: 5, title: 'Tutorial Video', type: 'video', thumbnail: '#9B59B6' },
    { id: 6, title: 'Technical Docs', type: 'document', thumbnail: '#1ABC9C' },
    { id: 7, title: 'Social Media Post', type: 'image', thumbnail: '#E67E22' },
    { id: 8, title: 'Demo Reel', type: 'video', thumbnail: '#3498DB' },
  ]

  const workflows = [
    {
      name: 'Image Generation',
      steps: ['Input Parameters', 'AI Processing', 'Quality Check', 'CDN Upload'],
      duration: '2-5 seconds',
    },
    {
      name: 'Video Production',
      steps: ['Script Analysis', 'Scene Generation', 'Rendering', 'Optimization'],
      duration: '30-60 seconds',
    },
    {
      name: 'Document Creation',
      steps: ['Template Selection', 'Content Fill', 'Formatting', 'Export'],
      duration: '5-10 seconds',
    },
  ]

  const copyToClipboard = (text, index) => {
    navigator.clipboard.writeText(text)
    setCopiedEndpoint(index)
    setTimeout(() => setCopiedEndpoint(null), 2000)
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-orange-900 via-red-900 to-tryonyou-black">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-red-500/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        </div>

        <div className="relative z-10 section-container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-block px-4 py-2 rounded-full glass mb-6">
              <span className="text-orange-300 font-semibold">Automated Content Engine</span>
            </div>
            
            <h1 className="heading-xl mb-6 gradient-text">
              CAP System
            </h1>
            
            <p className="text-xl text-white/80 max-w-3xl mx-auto mb-8">
              Content Automation & Processing System. Create, optimize, and distribute 
              content at scale with AI-powered automation.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <button className="btn-primary">
                <Zap className="inline mr-2" size={20} />
                Start Creating
              </button>
              <button className="btn-metallic">
                View Documentation
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-container bg-tryonyou-smoke/30">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Powerful Automation
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center mx-auto mb-4">
                  <feature.icon size={32} />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-white/60">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Content Types Stats */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Content Generated
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contentTypes.map((content, index) => (
              <motion.div
                key={content.type}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="card text-center group cursor-pointer"
              >
                <div className={`w-20 h-20 rounded-full bg-gradient-to-br ${content.color} flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                  <content.icon size={40} />
                </div>
                <div className="text-3xl font-bold gradient-text mb-2">{content.count}</div>
                <div className="text-white/60">{content.type}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* API Endpoints */}
      <section className="section-container bg-tryonyou-smoke/30">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            API Endpoints
          </h2>
          <div className="max-w-5xl mx-auto space-y-4">
            {endpoints.map((endpoint, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="card group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className={`px-3 py-1 rounded text-xs font-bold ${
                        endpoint.method === 'GET' ? 'bg-green-500/20 text-green-400' :
                        endpoint.method === 'POST' ? 'bg-blue-500/20 text-blue-400' :
                        endpoint.method === 'PUT' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>
                        {endpoint.method}
                      </span>
                      <code className="text-tryonyou-blue font-mono text-sm">
                        {endpoint.path}
                      </code>
                    </div>
                    <p className="text-white/60 text-sm mb-3">{endpoint.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {endpoint.params.map((param) => (
                        <span key={param} className="text-xs px-2 py-1 rounded bg-white/5 text-white/60 font-mono">
                          {param}
                        </span>
                      ))}
                    </div>
                  </div>
                  <button
                    onClick={() => copyToClipboard(endpoint.path, index)}
                    className="ml-4 p-2 rounded-lg glass hover:bg-white/20 transition-colors"
                  >
                    {copiedEndpoint === index ? (
                      <Check size={20} className="text-green-400" />
                    ) : (
                      <Copy size={20} />
                    )}
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Workflows */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Automated Workflows
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {workflows.map((workflow, index) => (
              <motion.div
                key={workflow.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="card"
              >
                <h3 className="text-xl font-bold mb-4">{workflow.name}</h3>
                <div className="space-y-3 mb-6">
                  {workflow.steps.map((step, i) => (
                    <div key={i} className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-tryonyou-blue/20 flex items-center justify-center mr-3 flex-shrink-0">
                        <span className="text-sm font-bold text-tryonyou-blue">{i + 1}</span>
                      </div>
                      <span className="text-white/80 text-sm">{step}</span>
                    </div>
                  ))}
                </div>
                <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                  <span className="text-xs text-white/40">Processing Time</span>
                  <span className="text-sm font-semibold text-tryonyou-blue">{workflow.duration}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Gallery */}
      <section className="section-container bg-tryonyou-smoke/30">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Content Gallery
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {gallery.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="card group cursor-pointer overflow-hidden"
              >
                <div
                  className="w-full h-40 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden"
                  style={{
                    backgroundColor: item.thumbnail,
                    boxShadow: `0 0 30px ${item.thumbnail}30`
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent" />
                  {item.type === 'image' && <Image size={48} className="relative z-10 text-white/80" />}
                  {item.type === 'video' && <Video size={48} className="relative z-10 text-white/80" />}
                  {item.type === 'document' && <FileText size={48} className="relative z-10 text-white/80" />}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button className="btn-primary text-sm">
                      View
                    </button>
                  </div>
                </div>
                <h3 className="text-sm font-bold mb-1 group-hover:text-tryonyou-blue transition-colors">
                  {item.title}
                </h3>
                <span className="text-xs text-white/60 capitalize">{item.type}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="heading-lg mb-6 gradient-text">
            Ready to Automate Your Content?
          </h2>
          <p className="text-lg text-white/80 mb-8">
            Start creating, processing, and distributing content at scale today
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="btn-primary">
              <Zap className="inline mr-2" size={20} />
              Get API Access
            </button>
            <button className="btn-metallic">
              View Examples
            </button>
          </div>
        </motion.div>
      </section>
    </div>
  )
}

export default CapSystem
