import { useState } from 'react'
import { motion } from 'framer-motion'
import { Palette, Sparkles, Wand2, Download, Upload, Grid3x3, Layers, Zap } from 'lucide-react'

const AbvetosFactory = () => {
  const [selectedStyle, setSelectedStyle] = useState('casual')
  const [selectedColor, setSelectedColor] = useState('#00A8E8')

  const styles = [
    { id: 'casual', name: 'Casual', icon: '👕' },
    { id: 'formal', name: 'Formal', icon: '👔' },
    { id: 'sport', name: 'Sport', icon: '🏃' },
    { id: 'elegant', name: 'Elegant', icon: '👗' },
    { id: 'streetwear', name: 'Streetwear', icon: '🧥' },
    { id: 'vintage', name: 'Vintage', icon: '🎩' },
  ]

  const colors = [
    '#00A8E8', '#003459', '#D4AF37', '#C0C0C0', '#8B92A0',
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8',
    '#F7DC6F', '#BB8FCE', '#85C1E2', '#F8B739', '#52BE80'
  ]

  const features = [
    {
      icon: Wand2,
      title: 'AI-Powered Design',
      description: 'Advanced algorithms create unique garment designs based on your preferences',
    },
    {
      icon: Palette,
      title: 'Custom Styling',
      description: 'Choose from unlimited color combinations and patterns',
    },
    {
      icon: Layers,
      title: 'Multi-Layer System',
      description: 'Combine multiple design elements for complex creations',
    },
    {
      icon: Zap,
      title: 'Real-Time Preview',
      description: 'See your designs come to life instantly with DSX rendering',
    },
  ]

  const gallery = [
    { id: 1, name: 'Summer Casual Tee', category: 'casual', color: '#4ECDC4' },
    { id: 2, name: 'Business Formal Suit', category: 'formal', color: '#003459' },
    { id: 3, name: 'Athletic Performance Wear', category: 'sport', color: '#FF6B6B' },
    { id: 4, name: 'Evening Gown', category: 'elegant', color: '#D4AF37' },
    { id: 5, name: 'Urban Streetwear Jacket', category: 'streetwear', color: '#8B92A0' },
    { id: 6, name: 'Vintage Denim', category: 'vintage', color: '#45B7D1' },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-900 via-cyan-900 to-tryonyou-black">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        </div>

        <div className="relative z-10 section-container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-block px-4 py-2 rounded-full glass mb-6">
              <span className="text-cyan-300 font-semibold">AI-Powered Garment Creation</span>
            </div>
            
            <h1 className="heading-xl mb-6 gradient-text">
              ABVETOS Factory
            </h1>
            
            <p className="text-xl text-white/80 max-w-3xl mx-auto mb-8">
              Advanced AI-powered garment creation and customization system. 
              Design, customize, and create unique fashion pieces with cutting-edge technology.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <button className="btn-primary">
                <Sparkles className="inline mr-2" size={20} />
                Start Creating
              </button>
              <button className="btn-metallic">
                View Gallery
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-container bg-tryonyou-smoke/30">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Powerful Features
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center mx-auto mb-4">
                  <feature.icon size={32} />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-white/60">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Interactive Design Studio */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Design Studio
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {/* Controls Panel */}
            <div className="lg:col-span-1 space-y-6">
              {/* Style Selection */}
              <div className="card">
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <Grid3x3 className="mr-2" size={20} />
                  Style
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {styles.map((style) => (
                    <button
                      key={style.id}
                      onClick={() => setSelectedStyle(style.id)}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        selectedStyle === style.id
                          ? 'border-tryonyou-blue bg-tryonyou-blue/20'
                          : 'border-white/10 hover:border-white/30'
                      }`}
                    >
                      <div className="text-3xl mb-2">{style.icon}</div>
                      <div className="text-sm font-semibold">{style.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Color Selection */}
              <div className="card">
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <Palette className="mr-2" size={20} />
                  Color
                </h3>
                <div className="grid grid-cols-5 gap-2 mb-4">
                  {colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`w-12 h-12 rounded-lg transition-all ${
                        selectedColor === color
                          ? 'ring-2 ring-white ring-offset-2 ring-offset-tryonyou-black scale-110'
                          : 'hover:scale-105'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
                <input
                  type="color"
                  value={selectedColor}
                  onChange={(e) => setSelectedColor(e.target.value)}
                  className="w-full h-12 rounded-lg cursor-pointer"
                />
              </div>

              {/* Actions */}
              <div className="space-y-3">
                <button className="w-full btn-primary">
                  <Wand2 className="inline mr-2" size={20} />
                  Generate Design
                </button>
                <button className="w-full btn-metallic">
                  <Upload className="inline mr-2" size={20} />
                  Upload Reference
                </button>
                <button className="w-full glass px-6 py-3 rounded-lg font-semibold hover:bg-white/20 transition-colors">
                  <Download className="inline mr-2" size={20} />
                  Export Design
                </button>
              </div>
            </div>

            {/* Preview Canvas */}
            <div className="lg:col-span-2">
              <div className="card h-full min-h-[600px] flex items-center justify-center">
                <div className="text-center">
                  <motion.div
                    animate={{
                      scale: [1, 1.05, 1],
                      rotate: [0, 2, -2, 0],
                    }}
                    transition={{
                      duration: 4,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className="w-64 h-80 mx-auto mb-6 rounded-2xl flex items-center justify-center relative overflow-hidden"
                    style={{
                      backgroundColor: selectedColor,
                      boxShadow: `0 0 40px ${selectedColor}40`
                    }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent" />
                    <div className="relative z-10 text-6xl">
                      {styles.find(s => s.id === selectedStyle)?.icon}
                    </div>
                  </motion.div>
                  <h3 className="text-2xl font-bold mb-2">
                    {styles.find(s => s.id === selectedStyle)?.name} Design
                  </h3>
                  <p className="text-white/60 mb-4">
                    Preview powered by DSX Rendering Engine
                  </p>
                  <div className="inline-block px-4 py-2 rounded-full glass">
                    <span className="text-sm">Color: {selectedColor}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Gallery Section */}
      <section className="section-container bg-tryonyou-smoke/30">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Featured Creations
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {gallery.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="card group cursor-pointer overflow-hidden"
              >
                <div
                  className="w-full h-64 rounded-lg mb-4 flex items-center justify-center text-6xl relative overflow-hidden"
                  style={{
                    backgroundColor: item.color,
                    boxShadow: `0 0 30px ${item.color}30`
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent" />
                  <div className="relative z-10">
                    {styles.find(s => s.id === item.category)?.icon}
                  </div>
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button className="btn-primary">
                      View Details
                    </button>
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2 group-hover:text-tryonyou-blue transition-colors">
                  {item.name}
                </h3>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-white/60 capitalize">{item.category}</span>
                  <div
                    className="w-6 h-6 rounded-full border-2 border-white/30"
                    style={{ backgroundColor: item.color }}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="heading-lg mb-6 gradient-text">
            Ready to Create Your Own Designs?
          </h2>
          <p className="text-lg text-white/80 mb-8">
            Join thousands of designers using ABVETOS Factory to bring their visions to life
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="btn-primary">
              <Sparkles className="inline mr-2" size={20} />
              Start Free Trial
            </button>
            <button className="btn-metallic">
              View Pricing
            </button>
          </div>
        </motion.div>
      </section>
    </div>
  )
}

export default AbvetosFactory
