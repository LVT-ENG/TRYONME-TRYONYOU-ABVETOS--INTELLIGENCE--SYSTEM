import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Brain, MessageCircle, Globe, Sparkles, Mic, Eye, Heart } from 'lucide-react'

const Pau = () => {
  const [activeConversation, setActiveConversation] = useState(0)
  const [isListening, setIsListening] = useState(false)

  const features = [
    {
      icon: Brain,
      title: 'AI Intelligence',
      description: 'Advanced neural networks for natural conversation and understanding',
    },
    {
      icon: Globe,
      title: 'Global Perspective',
      description: '"I am from the world" - Multilingual and culturally aware',
    },
    {
      icon: Eye,
      title: 'Visual Recognition',
      description: 'Analyze fashion items and provide styling recommendations',
    },
    {
      icon: Heart,
      title: 'Empathetic',
      description: 'Understands emotions and responds with genuine care',
    },
  ]

  const conversations = [
    {
      user: "Hi PAU! Can you help me choose an outfit?",
      pau: "Hello! I'd love to help you find the perfect outfit. Tell me about the occasion and your style preferences. I'm from the world, so I understand fashion from every culture!",
    },
    {
      user: "What colors would look good on me?",
      pau: "Based on your profile, I recommend rich jewel tones like emerald and sapphire. They complement your features beautifully. Would you like me to show you some combinations?",
    },
    {
      user: "How do I mix patterns?",
      pau: "Great question! The key is balance. Start with one bold pattern and pair it with a subtle one in a complementary color. I can show you examples from fashion capitals around the world!",
    },
  ]

  const capabilities = [
    { name: 'Fashion Advice', percentage: 98, color: 'from-pink-500 to-rose-500' },
    { name: 'Style Matching', percentage: 95, color: 'from-purple-500 to-indigo-500' },
    { name: 'Trend Analysis', percentage: 92, color: 'from-blue-500 to-cyan-500' },
    { name: 'Color Theory', percentage: 96, color: 'from-green-500 to-emerald-500' },
    { name: 'Cultural Awareness', percentage: 99, color: 'from-orange-500 to-red-500' },
  ]

  const personality = [
    { trait: 'Friendly', icon: '😊' },
    { trait: 'Knowledgeable', icon: '🎓' },
    { trait: 'Creative', icon: '🎨' },
    { trait: 'Empathetic', icon: '💖' },
    { trait: 'Global', icon: '🌍' },
    { trait: 'Innovative', icon: '💡' },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-tryonyou-black">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-pink-500/10 rounded-full blur-3xl animate-pulse" />
        </div>

        <div className="relative z-10 section-container text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Avatar Animation */}
            <motion.div
              className="mb-8 flex justify-center"
              animate={{
                y: [0, -20, 0],
                rotate: [0, 5, -5, 0],
              }}
              transition={{
                duration: 6,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <div className="relative">
                <div className="w-40 h-40 rounded-full bg-gradient-to-br from-purple-500 via-pink-500 to-indigo-500 flex items-center justify-center glow-blue">
                  <motion.div
                    animate={{
                      scale: [1, 1.1, 1],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className="text-7xl"
                  >
                    🤖
                  </motion.div>
                </div>
                <motion.div
                  className="absolute -top-2 -right-2 w-12 h-12 rounded-full bg-green-500 flex items-center justify-center"
                  animate={{
                    scale: [1, 1.2, 1],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <span className="text-2xl">✨</span>
                </motion.div>
              </div>
            </motion.div>

            <div className="inline-block px-4 py-2 rounded-full glass mb-6">
              <span className="text-purple-300 font-semibold">AI-Powered Virtual Assistant</span>
            </div>
            
            <h1 className="heading-xl mb-6 gradient-text">
              Avatar PAU
            </h1>
            
            <p className="text-2xl text-white/90 max-w-3xl mx-auto mb-4 font-semibold">
              &ldquo;I am from the world&rdquo;
            </p>
            
            <p className="text-xl text-white/80 max-w-3xl mx-auto mb-8">
              Your AI fashion companion with a global perspective. 
              PAU understands style, culture, and you.
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <button
                onClick={() => setIsListening(!isListening)}
                className={`btn-primary ${isListening ? 'animate-pulse' : ''}`}
              >
                <Mic className="inline mr-2" size={20} />
                {isListening ? 'Listening...' : 'Start Conversation'}
              </button>
              <button className="btn-metallic">
                <MessageCircle className="inline mr-2" size={20} />
                Chat with PAU
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section-container bg-tryonyou-smoke/30">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Intelligent Capabilities
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center mx-auto mb-4">
                  <feature.icon size={32} />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-white/60">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Personality Section */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            PAU&apos;s Personality
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 max-w-5xl mx-auto">
            {personality.map((item, index) => (
              <motion.div
                key={item.trait}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="card text-center group cursor-pointer"
              >
                <div className="text-5xl mb-3 group-hover:scale-125 transition-transform">
                  {item.icon}
                </div>
                <div className="text-sm font-semibold">{item.trait}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Conversation Demo */}
      <section className="section-container bg-tryonyou-smoke/30">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Chat with PAU
          </h2>
          
          <div className="max-w-4xl mx-auto">
            {/* Conversation Selector */}
            <div className="flex justify-center gap-4 mb-8">
              {conversations.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveConversation(index)}
                  className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                    activeConversation === index
                      ? 'bg-tryonyou-blue text-white'
                      : 'glass text-white/60 hover:text-white'
                  }`}
                >
                  Example {index + 1}
                </button>
              ))}
            </div>

            {/* Chat Interface */}
            <div className="card min-h-[400px] flex flex-col">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeConversation}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                  className="flex-1 space-y-6"
                >
                  {/* User Message */}
                  <div className="flex justify-end">
                    <div className="max-w-[70%] bg-tryonyou-blue/20 rounded-2xl rounded-tr-sm px-6 py-4">
                      <p className="text-white">{conversations[activeConversation].user}</p>
                    </div>
                  </div>

                  {/* PAU Response */}
                  <div className="flex justify-start">
                    <div className="flex gap-3 max-w-[80%]">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                        <span className="text-xl">🤖</span>
                      </div>
                      <div className="glass rounded-2xl rounded-tl-sm px-6 py-4">
                        <p className="text-white/90">{conversations[activeConversation].pau}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Input Area */}
              <div className="mt-6 pt-6 border-t border-white/10">
                <div className="flex gap-3">
                  <input
                    type="text"
                    placeholder="Type your message..."
                    className="flex-1 px-4 py-3 rounded-lg glass focus:outline-none focus:ring-2 focus:ring-tryonyou-blue"
                  />
                  <button className="btn-primary px-6">
                    Send
                  </button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Capabilities Stats */}
      <section className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="heading-lg mb-12 text-center gradient-text">
            Performance Metrics
          </h2>
          <div className="max-w-4xl mx-auto space-y-6">
            {capabilities.map((capability, index) => (
              <motion.div
                key={capability.name}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="card"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="font-semibold">{capability.name}</span>
                  <span className="text-tryonyou-blue font-bold">{capability.percentage}%</span>
                </div>
                <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${capability.percentage}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, delay: index * 0.1 }}
                    className={`h-full bg-gradient-to-r ${capability.color} rounded-full`}
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* CTA Section */}
      <section className="section-container bg-gradient-to-br from-indigo-900/50 to-purple-900/50">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="heading-lg mb-6 gradient-text">
            Meet Your New Fashion Companion
          </h2>
          <p className="text-lg text-white/80 mb-8">
            PAU is ready to help you discover your perfect style, from anywhere in the world
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="btn-primary">
              <Sparkles className="inline mr-2" size={20} />
              Start Chatting
            </button>
            <button className="btn-metallic">
              Learn More
            </button>
          </div>
        </motion.div>
      </section>
    </div>
  )
}

export default Pau
