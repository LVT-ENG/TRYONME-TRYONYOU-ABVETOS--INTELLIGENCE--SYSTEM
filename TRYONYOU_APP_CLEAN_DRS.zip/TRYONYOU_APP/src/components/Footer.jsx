import { Link } from 'react-router-dom'
import { Mail, Github, Linkedin, Twitter } from 'lucide-react'

const Footer = () => {
  const currentYear = new Date().getFullYear()

  const footerLinks = {
    product: [
      { label: 'Station-F', path: '/station-f' },
      { label: 'ABVETOS Factory', path: '/abvetos-factory' },
      { label: 'Smart Wardrobe', path: '/smart-wardrobe' },
      { label: 'CAP System', path: '/cap-system' },
      { label: 'Avatar PAU', path: '/pau' },
    ],
    company: [
      { label: 'About Us', path: '/about' },
      { label: 'Careers', path: '/careers' },
      { label: 'Press Kit', path: '/press' },
      { label: 'Contact', path: '/contact' },
    ],
    legal: [
      { label: 'Privacy Policy', path: '/privacy' },
      { label: 'Terms of Service', path: '/terms' },
      { label: 'Cookie Policy', path: '/cookies' },
    ],
  }

  const socialLinks = [
    { icon: Twitter, href: 'https://twitter.com/tryonyou', label: 'Twitter' },
    { icon: Linkedin, href: 'https://linkedin.com/company/tryonyou', label: 'LinkedIn' },
    { icon: Github, href: 'https://github.com/tryonyou', label: 'GitHub' },
    { icon: Mail, href: 'mailto:hello@tryonyou.app', label: 'Email' },
  ]

  return (
    <footer className="bg-tryonyou-smoke/80 backdrop-blur-lg border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="col-span-1">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-tryonyou-blue to-tryonyou-darkblue flex items-center justify-center">
                <svg viewBox="0 0 40 40" fill="none" className="w-6 h-6">
                  <circle cx="20" cy="20" r="18" fill="url(#footer-logo-gradient)" />
                  <circle cx="20" cy="20" r="6" fill="#D4AF37" />
                  <defs>
                    <radialGradient id="footer-logo-gradient">
                      <stop offset="0%" stopColor="#00A8E8" />
                      <stop offset="100%" stopColor="#003459" />
                    </radialGradient>
                  </defs>
                </svg>
              </div>
              <span className="font-display text-xl font-bold gradient-text">
                TRYONYOU
              </span>
            </div>
            <p className="text-sm text-white/60 mb-4">
              AI-Powered Virtual Try-On Platform. Experience the future of fashion.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-lg glass flex items-center justify-center hover:bg-tryonyou-blue/20 transition-colors"
                  aria-label={social.label}
                >
                  <social.icon size={18} />
                </a>
              ))}
            </div>
          </div>

          {/* Product Links */}
          <div>
            <h3 className="font-semibold text-white mb-4">Product</h3>
            <ul className="space-y-2">
              {footerLinks.product.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-white/60 hover:text-tryonyou-blue transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h3 className="font-semibold text-white mb-4">Company</h3>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-white/60 hover:text-tryonyou-blue transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h3 className="font-semibold text-white mb-4">Legal</h3>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-white/60 hover:text-tryonyou-blue transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-white/60">
              © {currentYear} TRYONYOU. All rights reserved.
            </p>
            <p className="text-sm text-white/60">
              Powered by <span className="text-tryonyou-blue font-semibold">Agent70</span> & <span className="text-tryonyou-blue font-semibold">DSX Technology</span>
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
