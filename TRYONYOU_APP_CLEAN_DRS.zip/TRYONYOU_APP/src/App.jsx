import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'

// Pages
import Home from './pages/home'
import StationF from './pages/stationf'
import AbvetosFactory from './pages/abvetos-factory'
import SmartWardrobe from './pages/wardrobe'
import CapSystem from './pages/cap'
import Pau from './pages/pau'

function App() {
  return (
    <div className="min-h-screen bg-tryonyou-anthracite">
      <Navbar />
      <main className="pt-20">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/station-f" element={<StationF />} />
          <Route path="/abvetos-factory" element={<AbvetosFactory />} />
          <Route path="/smart-wardrobe" element={<SmartWardrobe />} />
          <Route path="/cap-system" element={<CapSystem />} />
          <Route path="/pau" element={<Pau />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}

export default App
