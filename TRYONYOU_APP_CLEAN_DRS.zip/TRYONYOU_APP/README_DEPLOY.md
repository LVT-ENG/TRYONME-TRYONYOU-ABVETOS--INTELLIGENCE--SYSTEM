# TRYONYOU - Deployment Guide

## Deploy Express System

TRYONYOU includes a comprehensive automated deployment system called **Deploy Express** that handles building, testing, Git operations, deployment, and notifications.

## Quick Start

### Option 1: Automated Script (Recommended)

```bash
# Run the Deploy Express script
./deploy-express.sh
```

This single command will:
1. ✅ Build the project
2. ✅ Run quick tests
3. ✅ Commit changes to Git
4. ✅ Deploy to Vercel
5. ✅ Capture screenshots (optional)
6. ✅ Send Telegram notifications

### Option 2: Manual Deployment

```bash
# Build
npm run build

# Deploy
vercel --prod
```

### Option 3: GitHub Actions (Automatic)

Push to the `main` branch and GitHub Actions will automatically deploy.

## Configuration

### Environment Variables

Create a `.env.production` file:

```env
# Vercel Configuration
VERCEL_TOKEN=your_vercel_token
VERCEL_ORG_ID=your_org_id
VERCEL_PROJECT_ID=your_project_id

# Telegram Bot (Optional)
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_CHAT_ID=your_chat_id

# GitHub (Optional)
GITHUB_TOKEN=your_github_token
```

### Vercel Setup

1. Install Vercel CLI:
   ```bash
   npm install -g vercel
   ```

2. Login to Vercel:
   ```bash
   vercel login
   ```

3. Link project:
   ```bash
   vercel link
   ```

4. Get your tokens:
   ```bash
   vercel whoami
   ```

### Telegram Bot Setup (Optional)

1. Create a bot with [@BotFather](https://t.me/botfather)
2. Get your bot token
3. Get your chat ID from [@userinfobot](https://t.me/userinfobot)
4. Add credentials to `.env.production`

### GitHub Actions Setup

Add these secrets to your GitHub repository:

- `VERCEL_TOKEN`
- `VERCEL_ORG_ID`
- `VERCEL_PROJECT_ID`
- `TELEGRAM_BOT_TOKEN` (optional)
- `TELEGRAM_CHAT_ID` (optional)

Go to: Repository → Settings → Secrets and variables → Actions

## Deploy Express Features

### 1. Build & Test
- Installs dependencies
- Runs production build
- Validates critical files
- Checks bundle size

### 2. Git Operations
- Initializes repository if needed
- Stages all changes
- Creates timestamped commit
- Pushes to remote (if configured)

### 3. Deployment
- Deploys to Vercel production
- Uses project alias: `tryonyou-main`
- Configures custom domain
- Optimizes for performance

### 4. Notifications
- Sends deployment status to Telegram
- Includes commit hash
- Includes deployment URL
- Sends error logs on failure

### 5. Screenshots (Optional)
- Desktop: 1920x1080
- Mobile: 375x812
- Sends to Telegram bot

## Project Structure for Deployment

```
TRYONYOU_APP/
├── deploy-express.sh          # Main deployment script
├── .github/
│   └── workflows/
│       └── deploy.yml          # GitHub Actions workflow
├── vercel.json                 # Vercel configuration
├── .env.example                # Environment template
├── .env.production             # Production variables (not in Git)
└── dist/                       # Build output (generated)
```

## Deployment Checklist

Before deploying:

- [ ] All environment variables configured
- [ ] Vercel project linked
- [ ] Git repository initialized
- [ ] Dependencies installed
- [ ] Build succeeds locally
- [ ] No console errors
- [ ] All pages load correctly
- [ ] Mobile responsive
- [ ] Telegram bot configured (optional)

## Troubleshooting

### Build Fails

```bash
# Clear cache and rebuild
rm -rf node_modules dist
npm install
npm run build
```

### Vercel Deployment Fails

```bash
# Check Vercel status
vercel --version
vercel whoami

# Re-link project
vercel link --yes
```

### Git Push Fails

```bash
# Check remote
git remote -v

# Add remote if missing
git remote add origin https://github.com/yourusername/tryonyou-app.git

# Force push (use with caution)
git push -f origin main
```

### Telegram Notifications Not Working

- Verify bot token is correct
- Verify chat ID is correct
- Test bot manually: `https://api.telegram.org/bot<TOKEN>/getMe`
- Check bot has permission to send messages

## Advanced Usage

### Custom Deployment

```bash
# Deploy to preview
vercel

# Deploy to production with specific name
vercel --prod --name tryonyou-main

# Deploy with environment variables
vercel --prod -e API_URL=https://api.tryonyou.app
```

### Rollback

```bash
# List deployments
vercel ls

# Promote a previous deployment
vercel promote <deployment-url>
```

### Monitoring

```bash
# View logs
vercel logs

# View deployment details
vercel inspect <deployment-url>
```

## Performance Optimization

The deployment includes:

- ✅ Code splitting
- ✅ Tree shaking
- ✅ Minification
- ✅ Gzip compression
- ✅ Asset optimization
- ✅ CDN distribution
- ✅ Cache headers

## Security

- Environment variables are never committed
- Secrets are stored in GitHub Secrets
- API tokens are rotated regularly
- HTTPS enforced
- Security headers configured

## Support

For deployment issues:
- Email: hello@tryonyou.app
- Telegram: @abvet_deploy_bot

---

**Deploy Express v1.0.0** - Automated deployment for TRYONYOU
