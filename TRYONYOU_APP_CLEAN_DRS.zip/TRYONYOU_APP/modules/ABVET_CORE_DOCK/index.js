/**
 * ABVET Core Dock - Central Management Hub
 * Orchestrates communication between all TRYONYOU modules
 */

import dsx from '../DSX/index.js'
import qapi from '../QAPI/index.js'
import agent70 from '../AGENT70/index.js'

class ABVETCoreDock {
  constructor() {
    this.version = '3.0.0'
    this.name = 'ABVET Core Dock'
    this.initialized = false
    this.modules = {
      dsx: null,
      qapi: null,
      agent70: null
    }
    this.eventBus = new Map()
    this.state = {
      status: 'idle',
      activeOperations: 0,
      totalOperations: 0
    }
  }

  /**
   * Initialize ABVET Core Dock
   */
  async initialize() {
    console.log(`[ABVET Dock] Initializing v${this.version}...`)
    
    try {
      // Initialize core modules
      await this.initializeModules()
      
      // Setup event system
      this.setupEventBus()
      
      // Register with Agent70
      await this.registerWithSupervisor()
      
      this.initialized = true
      this.state.status = 'ready'
      
      console.log('[ABVET Dock] Initialization complete')
      
      return {
        success: true,
        version: this.version,
        modules: Object.keys(this.modules)
      }
    } catch (error) {
      console.error('[ABVET Dock] Initialization failed:', error)
      this.state.status = 'error'
      throw error
    }
  }

  /**
   * Initialize all core modules
   */
  async initializeModules() {
    console.log('[ABVET Dock] Initializing core modules...')
    
    // Initialize DSX
    try {
      this.modules.dsx = dsx
      await this.modules.dsx.initialize()
      console.log('[ABVET Dock] ✓ DSX Engine ready')
    } catch (error) {
      console.error('[ABVET Dock] ✗ DSX initialization failed:', error)
    }
    
    // Initialize Q-API
    try {
      this.modules.qapi = qapi
      await this.modules.qapi.initialize()
      console.log('[ABVET Dock] ✓ Q-API Manager ready')
    } catch (error) {
      console.error('[ABVET Dock] ✗ Q-API initialization failed:', error)
    }
    
    // Initialize Agent70
    try {
      this.modules.agent70 = agent70
      await this.modules.agent70.initialize()
      console.log('[ABVET Dock] ✓ Agent70 Supervisor ready')
    } catch (error) {
      console.error('[ABVET Dock] ✗ Agent70 initialization failed:', error)
    }
  }

  /**
   * Setup event bus for inter-module communication
   */
  setupEventBus() {
    console.log('[ABVET Dock] Setting up event bus...')
    
    this.eventBus.set('render', [])
    this.eventBus.set('api', [])
    this.eventBus.set('validation', [])
    this.eventBus.set('error', [])
    this.eventBus.set('status', [])
  }

  /**
   * Register with Agent70 supervisor
   */
  async registerWithSupervisor() {
    if (this.modules.agent70) {
      console.log('[ABVET Dock] Registering with Agent70...')
      // Registration handled by Agent70's module registry
    }
  }

  /**
   * Subscribe to events
   */
  on(event, callback) {
    if (!this.eventBus.has(event)) {
      this.eventBus.set(event, [])
    }
    
    this.eventBus.get(event).push(callback)
  }

  /**
   * Emit events
   */
  emit(event, data) {
    if (this.eventBus.has(event)) {
      const callbacks = this.eventBus.get(event)
      callbacks.forEach(callback => callback(data))
    }
  }

  /**
   * Process virtual try-on request
   */
  async processTryOn(request) {
    console.log('[ABVET Dock] Processing try-on request...')
    
    this.state.activeOperations++
    this.state.totalOperations++
    
    try {
      // Validate with Agent70
      const validation = await this.modules.agent70.validate({
        type: 'try-on',
        requiredModules: ['dsx', 'qapi']
      })
      
      if (!validation.valid) {
        throw new Error(`Validation failed: ${validation.errors.join(', ')}`)
      }
      
      // Prepare scene for DSX
      const scene = {
        garment: request.garment,
        model: request.model,
        settings: request.settings || {}
      }
      
      // Render with DSX
      const renderResult = await this.modules.dsx.render(scene)
      
      // Emit render event
      this.emit('render', renderResult)
      
      // Store result via Q-API
      await this.modules.qapi.post('/tryon/results', {
        requestId: request.id,
        result: renderResult
      })
      
      this.state.activeOperations--
      
      return {
        success: true,
        result: renderResult,
        requestId: request.id
      }
    } catch (error) {
      this.state.activeOperations--
      this.emit('error', { type: 'try-on', error: error.message })
      throw error
    }
  }

  /**
   * Process ABVETOS garment creation
   */
  async createGarment(params) {
    console.log('[ABVET Dock] Creating garment...')
    
    this.state.activeOperations++
    this.state.totalOperations++
    
    try {
      // Authorize with Agent70
      const authorization = await this.modules.agent70.authorize({
        type: 'create-garment'
      })
      
      if (!authorization.authorized) {
        throw new Error(`Authorization failed: ${authorization.reason}`)
      }
      
      // Create via Q-API
      const response = await this.modules.qapi.post('/abvetos/create', params)
      
      this.state.activeOperations--
      
      return response.data
    } catch (error) {
      this.state.activeOperations--
      this.emit('error', { type: 'create-garment', error: error.message })
      throw error
    }
  }

  /**
   * Process wardrobe operation
   */
  async processWardrobe(operation) {
    console.log('[ABVET Dock] Processing wardrobe operation...')
    
    this.state.activeOperations++
    this.state.totalOperations++
    
    try {
      const response = await this.modules.qapi.request({
        method: operation.method || 'GET',
        url: `/wardrobe/${operation.action}`,
        data: operation.data
      })
      
      this.state.activeOperations--
      
      return response.data
    } catch (error) {
      this.state.activeOperations--
      this.emit('error', { type: 'wardrobe', error: error.message })
      throw error
    }
  }

  /**
   * Process CAP system operation
   */
  async processCAP(operation) {
    console.log('[ABVET Dock] Processing CAP operation...')
    
    this.state.activeOperations++
    this.state.totalOperations++
    
    try {
      const response = await this.modules.qapi.post('/cap/process', operation)
      
      this.state.activeOperations--
      
      return response.data
    } catch (error) {
      this.state.activeOperations--
      this.emit('error', { type: 'cap', error: error.message })
      throw error
    }
  }

  /**
   * Interact with Avatar PAU
   */
  async chatWithPAU(message) {
    console.log('[ABVET Dock] Chatting with PAU...')
    
    this.state.activeOperations++
    this.state.totalOperations++
    
    try {
      const response = await this.modules.qapi.post('/pau/chat', {
        message,
        timestamp: Date.now()
      })
      
      this.state.activeOperations--
      
      return response.data
    } catch (error) {
      this.state.activeOperations--
      this.emit('error', { type: 'pau-chat', error: error.message })
      throw error
    }
  }

  /**
   * Get system health status
   */
  async getHealth() {
    if (!this.modules.agent70) {
      return { status: 'unknown', message: 'Agent70 not initialized' }
    }
    
    return await this.modules.agent70.performHealthCheck()
  }

  /**
   * Get dock status
   */
  getStatus() {
    const moduleStatus = {}
    
    for (const [name, module] of Object.entries(this.modules)) {
      if (module && typeof module.getStatus === 'function') {
        moduleStatus[name] = module.getStatus()
      } else {
        moduleStatus[name] = module ? 'loaded' : 'not loaded'
      }
    }
    
    return {
      version: this.version,
      initialized: this.initialized,
      state: this.state,
      modules: moduleStatus
    }
  }

  /**
   * Get statistics
   */
  getStats() {
    const stats = {
      dock: {
        totalOperations: this.state.totalOperations,
        activeOperations: this.state.activeOperations
      }
    }
    
    // Collect stats from modules
    if (this.modules.qapi && typeof this.modules.qapi.getStats === 'function') {
      stats.qapi = this.modules.qapi.getStats()
    }
    
    if (this.modules.dsx && typeof this.modules.dsx.getStatus === 'function') {
      stats.dsx = this.modules.dsx.getStatus()
    }
    
    if (this.modules.agent70 && typeof this.modules.agent70.getStatus === 'function') {
      stats.agent70 = this.modules.agent70.getStatus()
    }
    
    return stats
  }

  /**
   * Shutdown dock
   */
  async shutdown() {
    console.log('[ABVET Dock] Shutting down...')
    
    if (this.modules.agent70) {
      await this.modules.agent70.shutdown()
    }
    
    this.initialized = false
    this.state.status = 'shutdown'
  }
}

// Export singleton instance
const abvetDock = new ABVETCoreDock()

export default abvetDock
export { ABVETCoreDock }
