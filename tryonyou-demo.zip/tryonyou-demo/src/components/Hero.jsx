import React from 'react'

export default function Hero() {
  return (
    <section className="hero-section">
      <div className="hero-overlay" />
      <div className="hero-content">
        <h1 className="hero-title">TryOnYou</h1>
        <h2 className="hero-subtitle">La compra que te entiende.</h2>
        <p className="hero-description">
          Avatar 3D, armario inteligente y Pau el Paon recomendando looks según
          cómo te sientes. Sin tallas que no encajan, sin devoluciones eternas.
          Solo prendas que te sientan bien y te hacen sonreír.
        </p>
        <div className="hero-cta">
          <button
            className="btn-primary"
            onClick={() => {
              const el = document.querySelector('.demo-section')
              if (el) el.scrollIntoView({ behavior: 'smooth' })
            }}
          >
            Probar la demo
          </button>
        </div>
      </div>
    </section>
  )
}
