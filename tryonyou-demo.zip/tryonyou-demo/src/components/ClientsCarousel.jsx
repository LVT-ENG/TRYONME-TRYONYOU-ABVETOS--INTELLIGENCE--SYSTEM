import React, { useState } from 'react'

const clientImages = [
  '/assets/client-1.jpg',
  '/assets/client-2.jpg',
  '/assets/client-3.jpg',
  '/assets/client-4.jpg',
]

const testimonials = [
  'Reducimos devoluciones y aumentamos sonrisas en cada compra.',
  'La experiencia es tan divertida que el cliente olvida que está comprando online.',
  'Entiende el cuerpo, el estilo y la emoción del usuario.',
  'Ideal para enseñar el futuro del retail en 3 minutos de demo.',
]

export default function ClientsCarousel() {
  const [index, setIndex] = useState(0)

  const next = () => setIndex((i) => (i + 1) % clientImages.length)
  const prev = () =>
    setIndex((i) => (i - 1 + clientImages.length) % clientImages.length)

  return (
    <section className="clients-carousel-section">
      <h2 className="section-title">Partners & Fashion Tech Lovers</h2>
      <p className="section-subtitle">
        Una demo para retailers, marcas digitales y proyectos de inversión en
        fashion tech.
      </p>

      <div className="carousel-container">
        <div className="carousel-wrapper">
          <button
            type="button"
            className="carousel-button carousel-button-prev"
            onClick={prev}
          >
            ‹
          </button>

          <div className="carousel-content">
            <img
              src={clientImages[index]}
              alt={`Cliente ${index + 1}`}
              className="carousel-image"
            />
          </div>

          <button
            type="button"
            className="carousel-button carousel-button-next"
            onClick={next}
          >
            ›
          </button>
        </div>

        <div className="carousel-indicators">
          {clientImages.map((_, i) => (
            <button
              key={i}
              type="button"
              className={
                'carousel-indicator' + (i === index ? ' active' : '')
              }
              onClick={() => setIndex(i)}
            />
          ))}
        </div>

        <p className="clients-quote">{testimonials[index]}</p>
      </div>
    </section>
  )
}
