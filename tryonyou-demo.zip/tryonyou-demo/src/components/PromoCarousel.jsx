import React, { useState } from 'react'

const promoImages = [
  '/assets/promo-1.jpg',
  '/assets/promo-2.jpg',
  '/assets/promo-3.jpg',
  '/assets/promo-4.jpg',
]

export default function PromoCarousel() {
  const [index, setIndex] = useState(0)

  const next = () => setIndex((i) => (i + 1) % promoImages.length)
  const prev = () =>
    setIndex((i) => (i - 1 + promoImages.length) % promoImages.length)

  return (
    <section className="promo-carousel-section">
      <h2 className="section-title">Experiencia TryOnYou</h2>
      <p className="section-subtitle">
        De la talla correcta a la emoción correcta: así se ve el futuro de la
        compra de ropa.
      </p>

      <div className="carousel-container">
        <div className="carousel-wrapper">
          <button
            type="button"
            className="carousel-button carousel-button-prev"
            onClick={prev}
          >
            ‹
          </button>

          <div className="carousel-content">
            <img
              src={promoImages[index]}
              alt={`Promo ${index + 1}`}
              className="carousel-image"
            />
          </div>

          <button
            type="button"
            className="carousel-button carousel-button-next"
            onClick={next}
          >
            ›
          </button>
        </div>

        <div className="carousel-indicators">
          {promoImages.map((_, i) => (
            <button
              key={i}
              type="button"
              className={
                'carousel-indicator' + (i === index ? ' active' : '')
              }
              onClick={() => setIndex(i)}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
