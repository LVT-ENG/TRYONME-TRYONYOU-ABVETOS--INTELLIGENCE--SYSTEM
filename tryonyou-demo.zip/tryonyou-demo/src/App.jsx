import React, { useState } from 'react'
import Hero from './components/Hero.jsx'
import PromoCarousel from './components/PromoCarousel.jsx'
import ClientsCarousel from './components/ClientsCarousel.jsx'

const STEPS = ['avatar', 'wardrobe', 'look', 'summary']

function DemoFlow() {
  const [stepIndex, setStepIndex] = useState(0)
  const step = STEPS[stepIndex]

  const next = () => {
    setStepIndex((i) => (i + 1 < STEPS.length ? i + 1 : i))
  }
  const prev = () => {
    setStepIndex((i) => (i - 1 >= 0 ? i - 1 : i))
  }

  return (
    <section className="demo-section">
      <div className="demo-header">
        <h2>Demo TryOnYou</h2>
        <p>Avatar → Armario inteligente → Look emocional → AutoDonate.</p>
      </div>

      <div className="demo-steps">
        {STEPS.map((s, i) => (
          <div
            key={s}
            className={
              'demo-step-pill' +
              (i === stepIndex ? ' active' : '') +
              (i < stepIndex ? ' done' : '')
            }
          >
            {i + 1}. {s === 'avatar' && 'Avatar'}
            {s === 'wardrobe' && 'Armario'}
            {s === 'look' && 'Look'}
            {s === 'summary' && 'Resumen'}
          </div>
        ))}
      </div>

      <div className="demo-card">
        {step === 'avatar' && (
          <>
            <h3>1. Avatar</h3>
            <p>
              Aquí irá el módulo real de avatar 3D: medidas, foto y estilo.
              En esta demo mostramos la lógica del paso y explicamos cómo se
              conecta al sistema.
            </p>
            <ul>
              <li>Entrada: datos biométricos y/o foto.</li>
              <li>Salida: avatar coherente con tu cuerpo.</li>
              <li>Uso: comparación visual con prendas.</li>
            </ul>
          </>
        )}
        {step === 'wardrobe' && (
          <>
            <h3>2. Armario inteligente</h3>
            <p>
              El motor cruza tu avatar con la base de datos textil (CSV /
              Shopify) y descarta automáticamente lo que no encaja.
            </p>
            <ul>
              <li>Filtros por tejido, caída y ajuste real.</li>
              <li>Genera una shortlist de prendas que SÍ te sientan bien.</li>
            </ul>
          </>
        )}
        {step === 'look' && (
          <>
            <h3>3. Look emocional con Pau</h3>
            <p>
              Pau el Paon tiene en cuenta cómo te sientes hoy para elegir
              el look correcto, no solo la talla.
            </p>
            <ul>
              <li>Entrada: shortlist del armario + mood del usuario.</li>
              <li>Salida: 3–5 looks priorizados.</li>
              <li>Explicación para inversores/partners.</li>
            </ul>
          </>
        )}
        {step === 'summary' && (
          <>
            <h3>4. Resumen & AutoDonate</h3>
            <p>
              El sistema propone qué prendas se quedan contigo y cuáles se
              envían a AutoDonate de forma automática.
            </p>
            <ul>
              <li>Reduce devoluciones y prendas muertas en el armario.</li>
              <li>Activa un flujo solidario medible.</li>
            </ul>
          </>
        )}

        <div className="demo-nav">
          <button onClick={prev} disabled={stepIndex === 0}>
            Anterior
          </button>
          <button onClick={next} disabled={stepIndex === STEPS.length - 1}>
            Siguiente
          </button>
        </div>
      </div>
    </section>
  )
}

export default function App() {
  return (
    <div>
      <Hero />
      <PromoCarousel />
      <ClientsCarousel />
      <DemoFlow />
    </div>
  )
}
