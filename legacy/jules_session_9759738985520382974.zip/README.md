# Jules en Galeries Lafayette - Smart Mirror AR

## Overview
This project implements a Real-Time Augmented Reality "Smart Mirror" prototype for Galeries Lafayette. It combines a Python backend for physics simulation and a web-based frontend for real-time visualization.

## Protocolo de Lujo Galeries Lafayette
To maintain the "Luxury" standard required by the client, the following technical guidelines must be adhered to:

1.  **Ghost Mannequin Asset (La Prenda):**
    *   Garment assets must be high-quality PNGs with transparent backgrounds.
    *   Photography style: "Ghost Mannequin" (flat lay or mannequin invisible) to ensure the garment appears to float and fit organically over the user.
    *   *Current Implementation:* A placeholder generated asset is provided in `static/assets/blazer.png`. Replace this with a real high-res photo for production.

2.  **Suavizado (Anti-Jitter):**
    *   The MediaPipe configuration uses `smoothLandmarks: true`.
    *   This filter is critical to eliminate "jitter" (trembling) when the user is stationary, differentiating a professional tool from a toy.

3.  **Iluminación (Lighting):**
    *   **User Requirement:** Users must be positioned with clear frontal lighting.
    *   MediaPipe relies on contrast for landmark tracking. Poor lighting will cause the garment to drift or detach from the body.

## Running the Application

### Prerequisites
Install dependencies:
```bash
pip install -r requirements.txt
```

### 1. Web-Based AR Demo (Recommended)
This launches a local web server to run the "Luxury" AR experience in your browser (requires Webcam).

```bash
python server.py
```
*   Open `http://localhost:8000` in your browser.
*   Allow Camera access.
*   You will see the "Gold Blazer" overlay anchored to your shoulders.

### 2. Headless Video Processing (Backend Logic Verification)
This runs the Python-only logic (including Fabric Physics simulation) on a video file.

```bash
python main.py --input path/to/video.mp4 --output result.mp4
```

### 3. Physics Logic Testing
To verify the math behind the fabric simulation (Inertia/Gravity):
```bash
python test_logic.py
```
