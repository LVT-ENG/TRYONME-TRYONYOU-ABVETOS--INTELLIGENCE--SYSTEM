import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { v4 as uuidv4 } from 'uuid';

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Demo in-memory store
const sessions = new Map();

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'avbet-biometrics' });
});

// Enroll a user template (voice + iris placeholders)
app.post('/enroll', (req, res) => {
  const { userId, voiceSample, irisTemplate } = req.body || {};
  if (!userId || !voiceSample || !irisTemplate) {
    return res.status(400).json({ error: 'userId, voiceSample, irisTemplate are required' });
  }
  // Placeholder: In real system you would store biometric templates securely
  sessions.set(userId, { voiceSample, irisTemplate });
  res.json({ ok: true, userId });
});

// Verify endpoint (mocked)
app.post('/verify', (req, res) => {
  const { userId, voiceSample, irisTemplate } = req.body || {};
  if (!userId || !voiceSample || !irisTemplate) {
    return res.status(400).json({ error: 'userId, voiceSample, irisTemplate are required' });
  }
  const stored = sessions.get(userId);
  const match = stored && stored.voiceSample === voiceSample && stored.irisTemplate === irisTemplate;
  res.json({ verified: !!match, userId });
});

// One-time payment intent (mock)
app.post('/payments/intent', (req, res) => {
  const { amount, currency = 'EUR', metadata = {} } = req.body || {};
  if (typeof amount !== 'number') {
    return res.status(400).json({ error: 'amount must be a number' });
  }
  const id = uuidv4();
  res.json({ id, amount, currency, metadata, status: 'requires_biometrics' });
});

// Static
app.use('/', express.static('public'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`[avbet-biometrics] listening on :${PORT}`);
});