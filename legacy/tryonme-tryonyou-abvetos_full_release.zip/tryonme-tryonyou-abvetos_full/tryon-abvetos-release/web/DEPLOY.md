# Guía de despliegue (rápida)

## API (Render/Heroku/Servidor propio)
1. Ve a `api-avbet-biometrics/`
2. `npm install`
3. Define variables (opcional) en `.env` (`PORT=3000` por defecto).
4. Despliega en Render:
   - Runtime: Node 18+
   - Build command: `npm install`
   - Start command: `npm run start`
   - Health check path: `/health`

## Web estática (Wix o Vercel)
- **Wix**: usa esta web como referencia de contenidos y sube los textos/visual al editor (o exporta a Vercel si prefieres).
- **Vercel**: sube `web/` como proyecto estático o transpila a tu framework favorito.

## Shopify
- Importa tu `productos.csv` actualizado (no incluido aquí). El flujo `integrations/make_upload_scenario.json` sirve de base para automatizar subidas vía webhook.

## Make (Integromat)
- Importa `integrations/make_upload_scenario.json` y ajusta la `URL` del servidor (p. ej. Render) y credenciales.

> Este paquete sólo contiene piezas con valor directo para venta y demo. Mantén la patente y la API sincronizadas con la web pública.